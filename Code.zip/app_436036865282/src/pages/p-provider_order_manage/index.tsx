

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';

interface OrderData {
  id: string;
  orderNumber: string;
  ownerName: string;
  ownerPhone: string;
  petName: string;
  petType: string;
  serviceType: string;
  startTime: string;
  endTime: string;
  status: string;
  specialRequests: string;
  deposit: number;
  totalAmount: number;
}

type OrderStatus = 'pending' | 'accepted' | 'ongoing' | 'completed' | 'cancelled';

const ProviderOrderManage: React.FC = () => {
  const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [isOrderDetailDrawerOpen, setIsOrderDetailDrawerOpen] = useState<boolean>(false);
  const [isCompleteConfirmModalOpen, setIsCompleteConfirmModalOpen] = useState<boolean>(false);
  const [isRejectReasonModalOpen, setIsRejectReasonModalOpen] = useState<boolean>(false);
  const [currentOrderId, setCurrentOrderId] = useState<string | null>(null);
  const [selectedRejectReason, setSelectedRejectReason] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // 订单数据模拟
  const [orderData] = useState<Record<string, OrderData>>({
    'ORD001': {
      id: 'ORD001',
      orderNumber: '#20240315001',
      ownerName: '张小明',
      ownerPhone: '138****5678',
      petName: '豆豆',
      petType: '金毛犬',
      serviceType: '日托服务',
      startTime: '2024-03-18 09:00',
      endTime: '2024-03-18 18:00',
      status: '已接单',
      specialRequests: '需要按时喂食，喜欢玩球',
      deposit: 50,
      totalAmount: 120
    },
    'ORD002': {
      id: 'ORD002',
      orderNumber: '#20240314002',
      ownerName: '王小姐',
      ownerPhone: '139****1234',
      petName: '咪咪',
      petType: '布偶猫',
      serviceType: '周托服务',
      startTime: '2024-03-20 09:00',
      endTime: '2024-03-27 18:00',
      status: '服务中',
      specialRequests: '性格温顺，需要安静环境',
      deposit: 200,
      totalAmount: 680
    },
    'ORD003': {
      id: 'ORD003',
      orderNumber: '#20240313003',
      ownerName: '李先生',
      ownerPhone: '136****9876',
      petName: '球球',
      petType: '泰迪犬',
      serviceType: '小时陪遛',
      startTime: '2024-03-19 15:00',
      endTime: '2024-03-19 17:00',
      status: '待接单',
      specialRequests: '活泼好动，喜欢跑步',
      deposit: 20,
      totalAmount: 60
    },
    'ORD004': {
      id: 'ORD004',
      orderNumber: '#20240312001',
      ownerName: '张小明',
      ownerPhone: '138****5678',
      petName: '豆豆',
      petType: '金毛犬',
      serviceType: '日托服务',
      startTime: '2024-03-12 09:00',
      endTime: '2024-03-12 18:00',
      status: '已完成',
      specialRequests: '需要按时喂食，喜欢玩球',
      deposit: 50,
      totalAmount: 120
    }
  });

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 订单管理';
    return () => { document.title = originalTitle; };
  }, []);

  // 获取状态样式类
  const getStatusClass = (status: string): OrderStatus => {
    const statusMap: Record<string, OrderStatus> = {
      '待接单': 'pending',
      '已接单': 'accepted',
      '服务中': 'ongoing',
      '已完成': 'completed',
      '已取消': 'cancelled'
    };
    return statusMap[status] || 'pending';
  };

  // 处理筛选按钮点击
  const handleFilterClick = (filterType: string) => {
    setActiveFilter(filterType);
  };

  // 处理全选复选框
  const handleSelectAllOrders = (checked: boolean) => {
    if (checked) {
      setSelectedOrderIds(new Set(Object.keys(orderData)));
    } else {
      setSelectedOrderIds(new Set());
    }
  };

  // 处理单个订单复选框
  const handleOrderCheckboxChange = (orderId: string, checked: boolean) => {
    const newSelectedOrderIds = new Set(selectedOrderIds);
    if (checked) {
      newSelectedOrderIds.add(orderId);
    } else {
      newSelectedOrderIds.delete(orderId);
    }
    setSelectedOrderIds(newSelectedOrderIds);
  };

  // 查看订单详情
  const handleViewOrderDetail = (orderId: string) => {
    setCurrentOrderId(orderId);
    setIsOrderDetailDrawerOpen(true);
  };

  // 填写日报
  const handleFillReport = (orderId: string) => {
    console.log('填写日报:', orderId);
    alert('跳转到托管日报页面...');
  };

  // 查看日报
  const handleViewReport = (orderId: string) => {
    console.log('查看日报:', orderId);
    alert('查看托管日报...');
  };

  // 确认完成订单
  const handleCompleteOrder = (orderId: string) => {
    setCurrentOrderId(orderId);
    setIsCompleteConfirmModalOpen(true);
  };

  // 接单
  const handleAcceptOrder = (orderId: string) => {
    console.log('接单:', orderId);
    alert('接单成功！');
  };

  // 拒单
  const handleRejectOrder = (orderId: string) => {
    setCurrentOrderId(orderId);
    setIsRejectReasonModalOpen(true);
  };

  // 关闭订单详情抽屉
  const handleCloseOrderDetailDrawer = () => {
    setIsOrderDetailDrawerOpen(false);
    setCurrentOrderId(null);
  };

  // 确认完成订单
  const handleConfirmCompleteOrder = () => {
    if (currentOrderId) {
      console.log('确认完成订单:', currentOrderId);
      alert('订单已完成！');
      setIsCompleteConfirmModalOpen(false);
      setCurrentOrderId(null);
    }
  };

  // 取消完成订单
  const handleCancelCompleteOrder = () => {
    setIsCompleteConfirmModalOpen(false);
    setCurrentOrderId(null);
  };

  // 确认拒单
  const handleConfirmRejectOrder = () => {
    if (selectedRejectReason && currentOrderId) {
      console.log('拒单理由:', selectedRejectReason);
      alert('已拒单');
      setIsRejectReasonModalOpen(false);
      setCurrentOrderId(null);
      setSelectedRejectReason('');
    } else {
      alert('请选择拒单理由');
    }
  };

  // 取消拒单
  const handleCancelRejectOrder = () => {
    setIsRejectReasonModalOpen(false);
    setCurrentOrderId(null);
    setSelectedRejectReason('');
  };

  // 批量确认订单
  const handleBatchConfirmOrders = () => {
    if (selectedOrderIds.size > 0) {
      console.log('批量确认订单:', Array.from(selectedOrderIds));
      alert(`批量确认 ${selectedOrderIds.size} 个订单`);
    } else {
      alert('请选择要确认的订单');
    }
  };

  // 冲突检测
  const handleConflictDetect = () => {
    console.log('检测订单冲突');
    alert('冲突检测完成，未发现时间冲突订单');
  };

  // AI客服
  const handleAiCustomerService = () => {
    console.log('打开AI客服');
    alert('AI客服功能开发中...');
  };

  // 搜索功能
  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      console.log('搜索:', searchTerm);
    }
  };

  // 渲染订单详情内容
  const renderOrderDetailContent = () => {
    const order = currentOrderId ? orderData[currentOrderId] : null;
    if (!order) return null;

    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h4 className="font-medium text-accent mb-2">订单信息</h4>
            <p><strong>订单号：</strong>{order.orderNumber}</p>
            <p><strong>服务类型：</strong>{order.serviceType}</p>
            <p><strong>服务时段：</strong>{order.startTime} - {order.endTime}</p>
            <p>
              <strong>订单状态：</strong>
              <span className={`${styles[`statusBadge${getStatusClass(order.status).charAt(0).toUpperCase() + getStatusClass(order.status).slice(1)}`]} px-2 py-1 text-xs rounded-full`}>
                {order.status}
              </span>
            </p>
          </div>
          <div>
            <h4 className="font-medium text-accent mb-2">费用信息</h4>
            <p><strong>定金：</strong>¥{order.deposit}</p>
            <p><strong>总费用：</strong>¥{order.totalAmount}</p>
          </div>
        </div>
        <div className="border-t border-white/20 pt-4">
          <h4 className="font-medium text-accent mb-2">宠物主人</h4>
          <div className="flex items-center space-x-3">
            <img src="https://s.coze.cn/image/iKASAWcCS7s/" alt={order.ownerName} className="w-10 h-10 rounded-full" />
            <div>
              <p><strong>{order.ownerName}</strong></p>
              <p>{order.ownerPhone}</p>
            </div>
          </div>
        </div>
        <div className="border-t border-white/20 pt-4">
          <h4 className="font-medium text-accent mb-2">宠物信息</h4>
          <div className="flex items-center space-x-3">
            <img src="https://s.coze.cn/image/F_KREA6-iEY/" alt={order.petName} className="w-10 h-10 rounded-full" />
            <div>
              <p><strong>{order.petName} ({order.petType})</strong></p>
              <p><strong>特殊需求：</strong>{order.specialRequests}</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索订单、宠物主人..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={handleSearchKeyPress}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img src="https://s.coze.cn/image/rXkiL980OHo/" alt="用户头像" className="w-8 h-8 rounded-full" />
            <span className="text-text-primary font-medium hidden md:block">李阿姨</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link to="/provider-dashboard" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link to="/qualification-audit" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-certificate text-lg"></i>
              <span className="font-medium">资质审核</span>
            </Link>
            <Link to="/service-publish" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-plus-circle text-lg"></i>
              <span className="font-medium">服务发布</span>
            </Link>
            <Link to="/order-hall" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-bell text-lg"></i>
              <span className="font-medium">接单大厅</span>
            </Link>
            <Link to="/provider-order-manage" className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-list-alt text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <Link to="/withdrawal" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-money-bill-wave text-lg"></i>
              <span className="font-medium">收入提现</span>
            </Link>
            <Link to="/growth-system" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-trophy text-lg"></i>
              <span className="font-medium">成长体系</span>
            </Link>
            <Link to="/user-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">订单管理</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">订单管理</h1>
                <p className="text-text-secondary mt-1">管理您的所有托管订单和托管日报</p>
              </div>
              <div className="flex items-center space-x-3">
                <button onClick={handleBatchConfirmOrders} className={`${styles.btnSecondary} px-4 py-2 rounded-lg text-sm font-medium`}>
                  <i className="fas fa-check mr-2"></i>批量确认
                </button>
                <button onClick={handleConflictDetect} className={`${styles.btnSecondary} px-4 py-2 rounded-lg text-sm font-medium`}>
                  <i className="fas fa-exclamation-triangle mr-2"></i>冲突检测
                </button>
              </div>
            </div>
          </header>

          {/* 订单状态筛选 */}
          <section className={`${styles.glassCard} p-4 rounded-2xl`}>
            <div className="flex flex-wrap gap-3">
              <button 
                onClick={() => handleFilterClick('all')}
                className={`px-4 py-2 rounded-lg text-sm font-medium border border-white/30 transition-all ${
                  activeFilter === 'all' ? styles.filterActive : 'text-text-secondary hover:text-accent'
                }`}
              >
                全部订单 (15)
              </button>
              <button 
                onClick={() => handleFilterClick('pending')}
                className={`px-4 py-2 rounded-lg text-sm font-medium border border-white/30 transition-all ${
                  activeFilter === 'pending' ? styles.filterActive : 'text-text-secondary hover:text-accent'
                }`}
              >
                待接单 (3)
              </button>
              <button 
                onClick={() => handleFilterClick('accepted')}
                className={`px-4 py-2 rounded-lg text-sm font-medium border border-white/30 transition-all ${
                  activeFilter === 'accepted' ? styles.filterActive : 'text-text-secondary hover:text-accent'
                }`}
              >
                已接单 (5)
              </button>
              <button 
                onClick={() => handleFilterClick('ongoing')}
                className={`px-4 py-2 rounded-lg text-sm font-medium border border-white/30 transition-all ${
                  activeFilter === 'ongoing' ? styles.filterActive : 'text-text-secondary hover:text-accent'
                }`}
              >
                服务中 (4)
              </button>
              <button 
                onClick={() => handleFilterClick('completed')}
                className={`px-4 py-2 rounded-lg text-sm font-medium border border-white/30 transition-all ${
                  activeFilter === 'completed' ? styles.filterActive : 'text-text-secondary hover:text-accent'
                }`}
              >
                已完成 (3)
              </button>
              <button 
                onClick={() => handleFilterClick('cancelled')}
                className={`px-4 py-2 rounded-lg text-sm font-medium border border-white/30 transition-all ${
                  activeFilter === 'cancelled' ? styles.filterActive : 'text-text-secondary hover:text-accent'
                }`}
              >
                已取消 (0)
              </button>
            </div>
          </section>

          {/* 订单列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="overflow-x-auto">
              <table className={`w-full ${styles.tableGlass} rounded-xl overflow-hidden`}>
                <thead className="bg-white/10">
                  <tr>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">
                      <input 
                        type="checkbox" 
                        checked={selectedOrderIds.size === Object.keys(orderData).length && Object.keys(orderData).length > 0}
                        onChange={(e) => handleSelectAllOrders(e.target.checked)}
                        className="rounded border-white/30 bg-white/20 text-secondary focus:ring-secondary/50"
                      />
                    </th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">订单号</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">宠物主人</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">宠物信息</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务类型</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务时段</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">订单状态</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.values(orderData).map((order) => (
                    <tr key={order.id} className={`${styles.tableRow} border-b border-white/10`}>
                      <td className="px-4 py-3">
                        <input 
                          type="checkbox" 
                          checked={selectedOrderIds.has(order.id)}
                          onChange={(e) => handleOrderCheckboxChange(order.id, e.target.checked)}
                          className="rounded border-white/30 bg-white/20 text-secondary focus:ring-secondary/50"
                        />
                      </td>
                      <td className="px-4 py-3 text-text-primary font-medium">{order.orderNumber}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <img 
                            src={order.ownerName === '张小明' ? 'https://s.coze.cn/image/-aTSjis-Rnw/' : 
                                 order.ownerName === '王小姐' ? 'https://s.coze.cn/image/ZxohHakwpvw/' :
                                 'https://s.coze.cn/image/g7qYhdhUWQY/'} 
                            alt={order.ownerName} 
                            className="w-8 h-8 rounded-full"
                          />
                          <span className="text-text-primary">{order.ownerName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <img 
                            src={order.petName === '豆豆' ? 'https://s.coze.cn/image/rCKBR4TNL3s/' :
                                 order.petName === '咪咪' ? 'https://s.coze.cn/image/7sCrnj0GvnU/' :
                                 'https://s.coze.cn/image/bBIHF1VpFwM/'} 
                            alt={order.petName} 
                            className="w-8 h-8 rounded-full"
                          />
                          <span className="text-text-primary">{order.petName} ({order.petType})</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-text-secondary">{order.serviceType}</td>
                      <td className="px-4 py-3 text-text-secondary">
                        {order.serviceType === '周托服务' ? '3月20日-27日' : 
                         order.serviceType === '小时陪遛' ? '3月19日 15:00-17:00' :
                         `${order.startTime.split(' ')[0]} ${order.startTime.split(' ')[1]}-${order.endTime.split(' ')[1]}`}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`${styles[`statusBadge${getStatusClass(order.status).charAt(0).toUpperCase() + getStatusClass(order.status).slice(1)}`]} px-2 py-1 text-xs rounded-full`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => handleViewOrderDetail(order.id)}
                            className="text-secondary hover:text-accent text-sm font-medium"
                          >
                            查看
                          </button>
                          {(order.status === '已接单' || order.status === '服务中') && (
                            <button 
                              onClick={() => handleFillReport(order.id)}
                              className="text-green-600 hover:text-green-700 text-sm font-medium"
                            >
                              填写日报
                            </button>
                          )}
                          {order.status === '服务中' && (
                            <button 
                              onClick={() => handleCompleteOrder(order.id)}
                              className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                            >
                              确认完成
                            </button>
                          )}
                          {order.status === '待接单' && (
                            <>
                              <button 
                                onClick={() => handleAcceptOrder(order.id)}
                                className="text-green-600 hover:text-green-700 text-sm font-medium"
                              >
                                接单
                              </button>
                              <button 
                                onClick={() => handleRejectOrder(order.id)}
                                className="text-red-600 hover:text-red-700 text-sm font-medium"
                              >
                                拒单
                              </button>
                            </>
                          )}
                          {order.status === '已完成' && (
                            <button 
                              onClick={() => handleViewReport(order.id)}
                              className="text-purple-600 hover:text-purple-700 text-sm font-medium"
                            >
                              查看日报
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* 分页 */}
            <div className="flex items-center justify-between mt-6">
              <div className="text-sm text-text-muted">
                显示 1-4 条，共 15 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-1 border border-white/30 rounded text-text-secondary hover:text-accent disabled:opacity-50" disabled>
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button className="px-3 py-1 bg-secondary text-white rounded">1</button>
                <button className="px-3 py-1 border border-white/30 rounded text-text-secondary hover:text-accent">2</button>
                <button className="px-3 py-1 border border-white/30 rounded text-text-secondary hover:text-accent">3</button>
                <button className="px-3 py-1 border border-white/30 rounded text-text-secondary hover:text-accent">
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* 订单详情抽屉 */}
      {isOrderDetailDrawerOpen && (
        <div className={`${styles.orderDetailDrawer} ${isOrderDetailDrawerOpen ? styles.open : ''} fixed bottom-0 left-0 right-0 h-96 z-50 rounded-t-2xl p-6`}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-accent">订单详情</h3>
            <button onClick={handleCloseOrderDetailDrawer} className="p-2 text-text-muted hover:text-accent transition-colors">
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>
          
          <div className="space-y-4 overflow-y-auto max-h-72">
            {renderOrderDetailContent()}
          </div>
        </div>
      )}

      {/* 确认完成弹窗 */}
      {isCompleteConfirmModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className={`${styles.glassCard} p-6 rounded-2xl w-96 mx-4`}>
            <h3 className="text-lg font-semibold text-accent mb-4">确认完成服务</h3>
            <p className="text-text-secondary mb-6">确定要完成这个订单吗？完成后将无法修改。</p>
            <div className="flex space-x-3">
              <button onClick={handleCancelCompleteOrder} className={`flex-1 ${styles.btnSecondary} py-2 rounded-lg font-medium`}>
                取消
              </button>
              <button onClick={handleConfirmCompleteOrder} className={`flex-1 ${styles.btnPrimary} py-2 rounded-lg font-medium`}>
                确认完成
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 拒单理由选择弹窗 */}
      {isRejectReasonModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className={`${styles.glassCard} p-6 rounded-2xl w-96 mx-4`}>
            <h3 className="text-lg font-semibold text-accent mb-4">选择拒单理由</h3>
            <div className="space-y-3 mb-6">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="time-conflict" 
                  checked={selectedRejectReason === 'time-conflict'}
                  onChange={(e) => setSelectedRejectReason(e.target.value)}
                  className="text-secondary focus:ring-secondary/50"
                />
                <span className="text-text-primary">时间冲突</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="pet-type" 
                  checked={selectedRejectReason === 'pet-type'}
                  onChange={(e) => setSelectedRejectReason(e.target.value)}
                  className="text-secondary focus:ring-secondary/50"
                />
                <span className="text-text-primary">不接受该宠物类型</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="distance" 
                  checked={selectedRejectReason === 'distance'}
                  onChange={(e) => setSelectedRejectReason(e.target.value)}
                  className="text-secondary focus:ring-secondary/50"
                />
                <span className="text-text-primary">距离太远</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="other" 
                  checked={selectedRejectReason === 'other'}
                  onChange={(e) => setSelectedRejectReason(e.target.value)}
                  className="text-secondary focus:ring-secondary/50"
                />
                <span className="text-text-primary">其他原因</span>
              </label>
            </div>
            <div className="flex space-x-3">
              <button onClick={handleCancelRejectOrder} className={`flex-1 ${styles.btnSecondary} py-2 rounded-lg font-medium`}>
                取消
              </button>
              <button onClick={handleConfirmRejectOrder} className={`flex-1 ${styles.btnDanger} py-2 rounded-lg font-medium`}>
                确认拒单
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI客服悬浮按钮 */}
      <button onClick={handleAiCustomerService} className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50">
        <i className="fas fa-comments text-xl"></i>
      </button>

      {/* 点击背景关闭弹窗 */}
      {(isCompleteConfirmModalOpen || isRejectReasonModalOpen) && (
        <div 
          className="fixed inset-0 z-40"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              if (isCompleteConfirmModalOpen) {
                handleCancelCompleteOrder();
              }
              if (isRejectReasonModalOpen) {
                handleCancelRejectOrder();
              }
            }
          }}
        />
      )}
    </div>
  );
};

export default ProviderOrderManage;

