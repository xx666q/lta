

import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface ChatMessage {
  id: string;
  text: string;
  isUser: boolean;
  isTyping?: boolean;
}

const AICustomerServicePage: React.FC = () => {
  const navigate = useNavigate();
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: '您好！我是宠托帮AI客服，很高兴为您服务。请问有什么可以帮助您的吗？',
      isUser: false
    }
  ]);
  const [messageInputValue, setMessageInputValue] = useState('');
  const [showQuickQuestions, setShowQuickQuestions] = useState(true);
  const [isAiTyping, setIsAiTyping] = useState(false);
  const chatMessagesRef = useRef<HTMLDivElement>(null);
  const messageInputRef = useRef<HTMLTextAreaElement>(null);

  // 模拟AI回复
  const aiResponses: Record<string, string> = {
    '如何预约托管服务？': '预约托管服务非常简单：\n1. 登录宠托帮账号\n2. 点击"寻找服务"浏览附近的托管服务\n3. 选择合适的服务商，查看详情\n4. 选择服务时段和宠物\n5. 填写特殊需求并支付定金\n6. 等待服务商确认接单',
    '托管价格怎么计算？': '托管价格根据以下因素计算：\n• 服务类型（日托/周托/小时陪遛）\n• 宠物类型和数量\n• 服务时长\n• 额外服务（如接送、特殊护理）\n• 服务商定价\n您可以在服务详情页查看具体价格，也可以使用我们的价格计算器。',
    '如何成为托管服务商？': '成为托管服务商需要：\n1. 注册宠托帮账号并选择"托管服务商"身份\n2. 提交资质审核材料：\n   - 身份证正反面照片\n   - 手持身份证自拍\n   - 托管环境照片\n   - 营业执照（如有）\n3. 通过AI+人工审核（1-3个工作日）\n4. 审核通过后即可发布服务',
    '宠物托管期间可以查看吗？': '当然可以！我们提供"云看宠"功能：\n• 托管师会定期上传宠物照片和短视频\n• 部分服务商提供24小时监控摄像头接入\n• 您可以随时查看宠物的实时状态\n• 每天还会收到详细的托管日报',
    '取消订单会退款吗？': '取消订单的退款政策：\n• 服务开始前48小时取消：全额退款\n• 服务开始前24-48小时取消：退款80%\n• 服务开始前24小时内取消：退款50%\n• 服务开始后取消：不予退款\n具体以订单详情页的取消政策为准。',
    '宠物生病了怎么办？': '如果宠物在托管期间生病：\n1. 托管师会立即联系您\n2. 轻微症状会按照您的指示处理\n3. 严重情况会及时送往合作宠物医院\n4. 所有医疗费用由您承担\n建议您提前告知宠物的健康状况和常用药物。',
    '可以托管多只宠物吗？': '可以托管多只宠物，具体数量取决于：\n• 服务商的承接能力\n• 宠物的类型和大小\n• 宠物之间的相处情况\n建议您在预约时注明宠物数量，或提前与服务商沟通确认。'
  };

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - AI客服';
    return () => {
      document.title = originalTitle;
    };
  }, []);

  // 滚动到底部
  const scrollToBottom = () => {
    if (chatMessagesRef.current) {
      chatMessagesRef.current.scrollTop = chatMessagesRef.current.scrollHeight;
    }
  };

  // 发送消息
  const sendMessage = (text: string, isUser: boolean = true) => {
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      text,
      isUser
    };

    setChatMessages(prevMessages => [...prevMessages, newMessage]);
    scrollToBottom();

    // 如果是用户消息，触发AI回复
    if (isUser) {
      setTimeout(() => {
        aiReply(text);
      }, 1000);
    }
  };

  // AI回复
  const aiReply = (userMessage: string) => {
    // 显示正在输入指示器
    setIsAiTyping(true);

    // 查找匹配的回复
    let reply = '抱歉，我暂时无法理解您的问题。您可以尝试重新表述，或者点击"转人工客服"获得帮助。';
    
    // 模糊匹配
    Object.keys(aiResponses).forEach(key => {
      if (userMessage.includes(key.split('？')[0]) || key.includes(userMessage.split('？')[0])) {
        reply = aiResponses[key];
      }
    });

    // 移除正在输入指示器并显示回复
    setTimeout(() => {
      setIsAiTyping(false);
      sendMessage(reply, false);
    }, 2000);
  };

  // 处理发送按钮点击
  const handleSendButtonClick = () => {
    const message = messageInputValue.trim();
    if (message) {
      sendMessage(message);
      setMessageInputValue('');
      if (messageInputRef.current) {
        messageInputRef.current.style.height = 'auto';
        messageInputRef.current.rows = 1;
      }
      setShowQuickQuestions(false);
    }
  };

  // 处理输入框回车
  const handleMessageInputKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendButtonClick();
    }
  };

  // 处理输入框变化
  const handleMessageInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessageInputValue(e.target.value);
    
    // 自动调整高度
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
  };

  // 处理快捷问题点击
  const handleQuickQuestionClick = (question: string) => {
    sendMessage(question);
    setShowQuickQuestions(false);
  };

  // 处理关闭聊天
  const handleCloseChat = () => {
    if (confirm('确定要关闭聊天吗？')) {
      navigate(-1);
    }
  };

  // 处理转人工客服
  const handleTransferToHuman = () => {
    console.log('需要调用第三方接口转接人工客服');
    alert('正在为您转接人工客服，请稍候...');
  };

  // 处理搜索
  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const searchTerm = (e.target as HTMLInputElement).value;
      console.log('搜索:', searchTerm);
    }
  };

  // 处理通知
  const handleNotificationClick = () => {
    console.log('查看通知');
  };

  // 处理悬浮按钮点击
  const handleChatFloatButtonClick = () => {
    console.log('移动端聊天按钮点击');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
                onKeyPress={handleSearchKeyPress}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            className="relative p-2 text-text-secondary hover:text-accent transition-colors"
            onClick={handleNotificationClick}
          >
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <Link to="/user-profile" className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img 
              src="https://s.coze.cn/image/9AQKTfcHfY4/" 
              alt="用户头像" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-text-primary font-medium hidden md:block">张小明</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </Link>
        </div>
      </nav>

      {/* 主内容区 */}
      <main className="pt-16 p-6">
        {/* 页面头部 */}
        <header className="space-y-2 mb-6">
          <div className="text-sm text-text-muted">
            <span>首页</span>
            <i className="fas fa-chevron-right mx-2"></i>
            <span className="text-accent">AI客服</span>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-accent">AI客服</h1>
              <p className="text-text-secondary mt-1">7×24小时为您提供贴心服务</p>
            </div>
            <div className="flex items-center space-x-2 text-text-secondary">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm">在线中</span>
            </div>
          </div>
        </header>

        {/* AI客服聊天界面 */}
        <div className={`${styles.chatContainer} rounded-2xl overflow-hidden h-[600px] max-w-2xl mx-auto`}>
          {/* 聊天头部 */}
          <div className="flex items-center justify-between p-4 bg-white/10 border-b border-white/20">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-secondary to-accent rounded-full flex items-center justify-center">
                <i className="fas fa-robot text-white text-lg"></i>
              </div>
              <div>
                <h3 className="font-semibold text-accent">宠托帮AI客服</h3>
                <p className="text-sm text-text-muted">响应时间 &lt; 1秒</p>
              </div>
            </div>
            <button 
              className="p-2 text-text-muted hover:text-accent transition-colors"
              onClick={handleCloseChat}
            >
              <i className="fas fa-times text-lg"></i>
            </button>
          </div>

          {/* 聊天消息区域 */}
          <div 
            ref={chatMessagesRef}
            className={`flex-1 p-4 space-y-4 overflow-y-auto ${styles.chatScrollbar}`}
            style={{ height: 'calc(100% - 140px)' }}
          >
            {chatMessages.map((message) => (
              <div key={message.id} className={styles.chatMessage}>
                <div className={`${message.isUser ? styles.chatBubbleUser : styles.chatBubbleAi} max-w-xs p-3`}>
                  {!message.isUser && <i className="fas fa-robot text-sm mr-2 text-secondary"></i>}
                  <p className="text-sm whitespace-pre-line">{message.text}</p>
                </div>
              </div>
            ))}

            {/* 正在输入指示器 */}
            {isAiTyping && (
              <div className={styles.chatMessage}>
                <div className={`${styles.chatBubbleAi} max-w-xs p-3`}>
                  <i className="fas fa-robot text-sm mr-2 text-secondary"></i>
                  <div className={styles.typingIndicator}>
                    <div className={styles.typingDot}></div>
                    <div className={styles.typingDot}></div>
                    <div className={styles.typingDot}></div>
                  </div>
                </div>
              </div>
            )}

            {/* 常见问题快捷选项 */}
            {showQuickQuestions && (
              <div className="flex flex-wrap gap-2 justify-center">
                <button 
                  className="px-4 py-2 bg-white/20 border border-white/30 rounded-full text-sm text-text-primary hover:bg-white/30 transition-colors"
                  onClick={() => handleQuickQuestionClick('如何预约托管服务？')}
                >
                  如何预约托管服务？
                </button>
                <button 
                  className="px-4 py-2 bg-white/20 border border-white/30 rounded-full text-sm text-text-primary hover:bg-white/30 transition-colors"
                  onClick={() => handleQuickQuestionClick('托管价格怎么计算？')}
                >
                  托管价格怎么计算？
                </button>
                <button 
                  className="px-4 py-2 bg-white/20 border border-white/30 rounded-full text-sm text-text-primary hover:bg-white/30 transition-colors"
                  onClick={() => handleQuickQuestionClick('如何成为托管服务商？')}
                >
                  如何成为托管服务商？
                </button>
              </div>
            )}
          </div>

          {/* 输入区域 */}
          <div className="p-4 bg-white/10 border-t border-white/20">
            <div className="flex items-end space-x-3">
              <div className="flex-1 relative">
                <textarea 
                  ref={messageInputRef}
                  className={`${styles.chatInput} w-full px-4 py-3 pr-12 rounded-xl resize-none`}
                  rows={1}
                  placeholder="请输入您的问题..."
                  maxLength={500}
                  value={messageInputValue}
                  onChange={handleMessageInputChange}
                  onKeyPress={handleMessageInputKeyPress}
                />
                <button 
                  className="absolute right-3 bottom-3 w-8 h-8 bg-secondary rounded-full flex items-center justify-center text-white hover:bg-accent transition-colors"
                  onClick={handleSendButtonClick}
                >
                  <i className="fas fa-paper-plane text-sm"></i>
                </button>
              </div>
            </div>
            
            {/* 转人工按钮 */}
            <div className="mt-3 text-center">
              <button 
                className={`${styles.btnSecondary} px-6 py-2 rounded-full text-sm font-medium`}
                onClick={handleTransferToHuman}
              >
                <i className="fas fa-user-tie mr-2"></i>转人工客服
              </button>
            </div>
          </div>
        </div>

        {/* 聊天悬浮按钮（移动端） */}
        <button 
          className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50 lg:hidden"
          onClick={handleChatFloatButtonClick}
        >
          <i className="fas fa-comments text-xl"></i>
        </button>
      </main>
    </div>
  );
};

export default AICustomerServicePage;

