

import React, { useState, useEffect } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface ServiceData {
  title: string;
  subtitle: string;
  provider: string;
  rating: number;
  price: number;
  serviceType: string;
  petsAllowed: string[];
  address: string;
  distance: string;
  canPickup: boolean;
  images: string[];
}

const ServiceDetailPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  // 状态管理
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFavorited, setIsFavorited] = useState(false);
  const [selectedStartDate, setSelectedStartDate] = useState<Date | null>(null);
  const [selectedEndDate, setSelectedEndDate] = useState<Date | null>(null);
  const [currentMonth, setCurrentMonth] = useState('2024年3月');
  const [searchInputValue, setSearchInputValue] = useState('');

  // 模拟服务数据
  const mockServices: Record<string, ServiceData> = {
    service1: {
      title: '温馨家庭日托服务',
      subtitle: '专业、贴心的宠物托管服务',
      provider: '李阿姨',
      rating: 4.9,
      price: 88,
      serviceType: '日托服务',
      petsAllowed: ['小型犬', '中型犬', '猫咪'],
      address: '北京市朝阳区三里屯街道工体北路8号院',
      distance: '1.2km',
      canPickup: true,
      images: [
        'https://s.coze.cn/image/bbYf6_ZgivQ/',
        'https://s.coze.cn/image/KQREcBgOJl4/',
        'https://s.coze.cn/image/jX0xwhTIQL4/',
        'https://s.coze.cn/image/ML0H1g-rGRk/'
      ]
    },
    service2: {
      title: '专业宠物酒店服务',
      subtitle: '五星级的宠物住宿体验',
      provider: '王小姐',
      rating: 4.8,
      price: 128,
      serviceType: '周托服务',
      petsAllowed: ['小型犬', '中型犬', '大型犬', '猫咪'],
      address: '北京市海淀区中关村大街27号',
      distance: '2.5km',
      canPickup: false,
      images: [
        'https://s.coze.cn/image/1ts8nSia9LI/',
        'https://s.coze.cn/image/-UhhTzEZzvI/',
        'https://s.coze.cn/image/Z9vUE8XvW3s/',
        'https://s.coze.cn/image/_2PKA3uAoi8/'
      ]
    }
  };

  // 获取当前服务数据
  const serviceId = searchParams.get('serviceId') || 'service1';
  const currentService = mockServices[serviceId] || mockServices.service1;

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 服务详情';
    return () => {
      document.title = originalTitle;
    };
  }, []);

  // 图片轮播功能
  const handleImageThumbClick = (index: number) => {
    setCurrentImageIndex(index);
  };

  const handlePrevImage = () => {
    setCurrentImageIndex(prev => prev > 0 ? prev - 1 : currentService.images.length - 1);
  };

  const handleNextImage = () => {
    setCurrentImageIndex(prev => prev < currentService.images.length - 1 ? prev + 1 : 0);
  };

  // 收藏按钮
  const handleFavoriteToggle = () => {
    setIsFavorited(!isFavorited);
  };

  // 日历天数数据
  const calendarDays = [
    { day: 25, disabled: true },
    { day: 26, disabled: true },
    { day: 27, disabled: true },
    { day: 28, disabled: true },
    { day: 29, disabled: true },
    { day: 1, disabled: true },
    { day: 2, disabled: false },
    { day: 3, disabled: false },
    { day: 4, disabled: false },
    { day: 5, disabled: false },
    { day: 6, disabled: false },
    { day: 7, disabled: false },
    { day: 8, disabled: false },
    { day: 9, disabled: false },
    { day: 10, disabled: false },
    { day: 11, disabled: false },
    { day: 12, disabled: false },
    { day: 13, disabled: false },
    { day: 14, disabled: false },
    { day: 15, disabled: false },
    { day: 16, disabled: false },
    { day: 17, disabled: false },
    { day: 18, disabled: false },
    { day: 19, disabled: false },
    { day: 20, disabled: false },
    { day: 21, disabled: false },
    { day: 22, disabled: false },
    { day: 23, disabled: false },
    { day: 24, disabled: false },
    { day: 25, disabled: false },
    { day: 26, disabled: false },
    { day: 27, disabled: false },
    { day: 28, disabled: false },
    { day: 29, disabled: false },
    { day: 30, disabled: false },
    { day: 31, disabled: false },
    { day: 1, disabled: true },
    { day: 2, disabled: true },
    { day: 3, disabled: true },
    { day: 4, disabled: true },
    { day: 5, disabled: true }
  ];

  // 日历天数点击处理
  const handleCalendarDayClick = (day: number) => {
    const currentDate = new Date();
    const selectedDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    
    // 不能选择过去的日期
    if (selectedDate < new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate())) {
      return;
    }

    if (!selectedStartDate) {
      // 选择开始日期
      setSelectedStartDate(selectedDate);
      setSelectedEndDate(null);
    } else if (!selectedEndDate && selectedDate > selectedStartDate) {
      // 选择结束日期
      setSelectedEndDate(selectedDate);
    } else {
      // 重新选择
      setSelectedStartDate(selectedDate);
      setSelectedEndDate(null);
    }
  };

  // 检查日期是否被选中
  const isDateSelected = (day: number): 'start' | 'end' | 'between' | false => {
    if (!selectedStartDate || !selectedEndDate) {
      if (selectedStartDate && selectedStartDate.getDate() === day) {
        return 'start';
      }
      return false;
    }

    const currentDate = new Date(selectedStartDate.getFullYear(), selectedStartDate.getMonth(), day);
    if (currentDate.getTime() === selectedStartDate.getTime()) {
      return 'start';
    }
    if (currentDate.getTime() === selectedEndDate.getTime()) {
      return 'end';
    }
    if (currentDate > selectedStartDate && currentDate < selectedEndDate) {
      return 'between';
    }
    return false;
  };

  // 计算总天数和总价
  const getTotalDays = (): number => {
    if (!selectedStartDate || !selectedEndDate) return 1;
    return Math.ceil((selectedEndDate.getTime() - selectedStartDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  };

  const getTotalPrice = (): number => {
    return getTotalDays() * currentService.price;
  };

  // 立即预约
  const handleBookNow = () => {
    if (selectedStartDate && selectedEndDate) {
      const bookingParams = new URLSearchParams({
        serviceId: serviceId,
        startDate: selectedStartDate.toISOString().split('T')[0],
        endDate: selectedEndDate.toISOString().split('T')[0],
        totalDays: getTotalDays().toString(),
        totalPrice: getTotalPrice().toString()
      });
      
      alert(`预约确认页面将显示以下信息：\n服务ID: ${serviceId}\n开始日期: ${selectedStartDate.toLocaleDateString()}\n结束日期: ${selectedEndDate.toLocaleDateString()}\n总价: ¥${getTotalPrice()}`);
      
      // 实际项目中应该是：
      // navigate(`/booking-confirm?${bookingParams.toString()}`);
    }
  };

  // 搜索处理
  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      console.log('搜索:', searchInputValue);
      // 这里可以实现搜索功能
    }
  };

  // 月份切换
  const handlePrevMonth = () => {
    console.log('切换到上个月');
    // 这里可以实现月份切换逻辑
  };

  const handleNextMonth = () => {
    console.log('切换到下个月');
    // 这里可以实现月份切换逻辑
  };

  // AI客服
  const handleAiCustomerService = () => {
    console.log('打开AI客服');
    alert('AI客服功能开发中...');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                value={searchInputValue}
                onChange={(e) => setSearchInputValue(e.target.value)}
                onKeyPress={handleSearchKeyPress}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img src="https://s.coze.cn/image/n7ZLyOXrtVM/" 
                 alt="用户头像" className="w-8 h-8 rounded-full" />
            <span className="text-text-primary font-medium hidden md:block">张小明</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link to="/owner-dashboard" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link to="/pet-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-paw text-lg"></i>
              <span className="font-medium">我的宠物</span>
            </Link>
            <Link to="/service-discovery" className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-search text-lg"></i>
              <span className="font-medium">寻找服务</span>
            </Link>
            <Link to="/owner-calendar" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-calendar-alt text-lg"></i>
              <span className="font-medium">托管日历</span>
            </Link>
            <Link to="/cloud-view" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-video text-lg"></i>
              <span className="font-medium">云看宠</span>
            </Link>
            <Link to="/user-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span>寻找服务</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">服务详情</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">{currentService.title}</h1>
                <p className="text-text-secondary mt-1">{currentService.subtitle}</p>
              </div>
              <button 
                onClick={handleFavoriteToggle}
                className={`${styles.btnSecondary} p-3 rounded-xl hover:shadow-lg transition-all`}
              >
                <i className={`${isFavorited ? 'fas' : 'far'} fa-heart text-lg`} 
                   style={isFavorited ? { color: '#F48224' } : {}}></i>
              </button>
            </div>
          </header>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* 左侧服务信息 */}
            <div className="lg:col-span-2 space-y-6">
              {/* 环境照片轮播 */}
              <section className={`${styles.glassCard} p-6 rounded-2xl`}>
                <h2 className="text-lg font-semibold text-accent mb-4">托管环境</h2>
                <div className={styles.imageGallery}>
                  <img 
                    src={currentService.images[currentImageIndex] || 'https://s.coze.cn/image/6qahlBSQqWE/'} 
                    alt="托管环境照片" 
                    className={styles.galleryImage} 
                  />
                  <div className={styles.galleryNav}>
                    <button onClick={handlePrevImage} className={styles.galleryBtn}>
                      <i className="fas fa-chevron-left"></i>
                    </button>
                    <button onClick={handleNextImage} className={styles.galleryBtn}>
                      <i className="fas fa-chevron-right"></i>
                    </button>
                  </div>
                </div>
                <div className="flex space-x-2 mt-4 overflow-x-auto">
                  {currentService.images.map((image, index) => (
                    <img 
                      key={index}
                      src={image} 
                      alt={`缩略图${index + 1}`} 
                      className={`w-16 h-16 object-cover rounded-lg cursor-pointer border-2 ${
                        index === currentImageIndex ? 'border-secondary' : 'border-transparent hover:border-secondary'
                      }`}
                      onClick={() => handleImageThumbClick(index)}
                    />
                  ))}
                </div>
              </section>

              {/* 服务介绍 */}
              <section className={`${styles.glassCard} p-6 rounded-2xl`}>
                <h2 className="text-lg font-semibold text-accent mb-4">服务介绍</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium text-accent mb-2">服务内容</h3>
                    <p className="text-text-secondary leading-relaxed">
                      我们提供专业的宠物日托服务，拥有宽敞的活动空间和丰富的玩具设施。每天定时喂食、遛弯、玩耍，让您的爱宠在温馨的环境中度过快乐的时光。我们有多年的宠物护理经验，能够照顾各种性格的宠物。
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium text-accent mb-2">托管注意事项</h3>
                    <ul className="space-y-2 text-text-secondary">
                      <li className="flex items-start space-x-2">
                        <i className="fas fa-check text-secondary mt-1"></i>
                        <span>请提前告知宠物的特殊习惯和健康状况</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="fas fa-check text-secondary mt-1"></i>
                        <span>建议携带宠物的常用食物，避免肠胃不适</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="fas fa-check text-secondary mt-1"></i>
                        <span>请确保宠物已完成疫苗接种</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="fas fa-check text-secondary mt-1"></i>
                        <span>如宠物有特殊医疗需求，请提前说明</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </section>

              {/* 服务商介绍 */}
              <section className={`${styles.glassCard} p-6 rounded-2xl`}>
                <h2 className="text-lg font-semibold text-accent mb-4">服务商介绍</h2>
                <div className="space-y-4">
                  <div className="flex items-start space-x-4">
                    <img src="https://s.coze.cn/image/Q9CBRbrZkpE/" 
                         alt={`${currentService.provider}头像`} 
                         className="w-16 h-16 rounded-full" />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-semibold text-accent">{currentService.provider}</h3>
                        <div className={styles.ratingStars}>
                          <i className="fas fa-star"></i>
                          <i className="fas fa-star"></i>
                          <i className="fas fa-star"></i>
                          <i className="fas fa-star"></i>
                          <i className="fas fa-star"></i>
                        </div>
                        <span className="text-text-muted text-sm">{currentService.rating}分</span>
                      </div>
                      <p className="text-text-secondary text-sm leading-relaxed">
                        退休教师，热爱小动物，有10年宠物护理经验。家中有宽敞的院子和专业的宠物设施，对待每只宠物都像家人一样用心。已通过平台实名认证和资质审核。
                      </p>
                      <div className="flex flex-wrap mt-3">
                        <span className={styles.tag}>有耐心</span>
                        <span className={styles.tag}>环境好</span>
                        <span className={styles.tag}>经验丰富</span>
                        <span className={styles.tag}>按时喂药</span>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-white/20">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-accent">128</p>
                      <p className="text-text-muted text-sm">完成订单</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-accent">98%</p>
                      <p className="text-text-muted text-sm">好评率</p>
                      <div className={`${styles.ratingStars} text-sm mt-1`}>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                      </div>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-accent">2年</p>
                      <p className="text-text-muted text-sm">服务年限</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-accent">金牌</p>
                      <p className="text-text-muted text-sm">托管师等级</p>
                    </div>
                  </div>
                </div>
              </section>
            </div>

            {/* 右侧预约区域 */}
            <div className="space-y-6">
              {/* 服务基本信息 */}
              <section className={`${styles.glassCard} p-6 rounded-2xl`}>
                <h2 className="text-lg font-semibold text-accent mb-4">服务信息</h2>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary">服务类型</span>
                    <span className="font-medium text-accent">{currentService.serviceType}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary">价格</span>
                    <span className="text-xl font-bold text-secondary">¥{currentService.price}<span className="text-sm font-normal">/天</span></span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary">可托管宠物</span>
                    <div className="flex space-x-2">
                      {currentService.petsAllowed.map((pet, index) => (
                        <span key={index} className={styles.tag}>{pet}</span>
                      ))}
                    </div>
                  </div>
                  <div className="flex justify-between items-start">
                    <span className="text-text-secondary">地址</span>
                    <span className="text-text-accent text-sm">{currentService.address}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary">距离</span>
                    <span className="text-accent font-medium">{currentService.distance}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary">可接送</span>
                    <span className={`${currentService.canPickup ? 'text-green-600' : 'text-text-muted'} font-medium`}>
                      <i className={`fas ${currentService.canPickup ? 'fa-check-circle' : 'fa-times-circle'} mr-1`}></i>
                      {currentService.canPickup ? '是' : '否'}
                    </span>
                  </div>
                </div>
              </section>

              {/* 预约日历 */}
              <section className={`${styles.glassCard} p-6 rounded-2xl`}>
                <h2 className="text-lg font-semibold text-accent mb-4">选择预约时间</h2>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <button onClick={handlePrevMonth} className={`${styles.btnSecondary} p-2 rounded-lg`}>
                      <i className="fas fa-chevron-left"></i>
                    </button>
                    <h3 className="font-medium text-accent">{currentMonth}</h3>
                    <button onClick={handleNextMonth} className={`${styles.btnSecondary} p-2 rounded-lg`}>
                      <i className="fas fa-chevron-right"></i>
                    </button>
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    <div className="text-center text-text-muted text-sm py-2">日</div>
                    <div className="text-center text-text-muted text-sm py-2">一</div>
                    <div className="text-center text-text-muted text-sm py-2">二</div>
                    <div className="text-center text-text-muted text-sm py-2">三</div>
                    <div className="text-center text-text-muted text-sm py-2">四</div>
                    <div className="text-center text-text-muted text-sm py-2">五</div>
                    <div className="text-center text-text-muted text-sm py-2">六</div>
                    
                    {/* 日历天数 */}
                    {calendarDays.map((dayData, index) => {
                      const dateStatus = isDateSelected(dayData.day);
                      let dayClasses = `${styles.calendarDay} ${dayData.disabled ? 'text-text-muted' : ''}`;
                      
                      if (dateStatus === 'start' || dateStatus === 'end') {
                        dayClasses += ` ${styles.selected}`;
                      } else if (dateStatus === 'between') {
                        dayClasses += ' bg-secondary/20';
                      }
                      
                      return (
                        <div
                          key={index}
                          className={dayClasses}
                          onClick={() => !dayData.disabled && handleCalendarDayClick(dayData.day)}
                          style={dayData.disabled ? { cursor: 'not-allowed' } : {}}
                        >
                          {dayData.day}
                        </div>
                      );
                    })}
                  </div>
                  {(selectedStartDate && selectedEndDate) && (
                    <div>
                      <p className="text-sm text-text-muted mb-2">已选择日期：</p>
                      <div className="flex space-x-2">
                        <span className={`${styles.tag} bg-secondary text-white`}>
                          {selectedStartDate.getMonth() + 1}月{selectedStartDate.getDate()}日
                        </span>
                        <span className="text-text-muted">-</span>
                        <span className={`${styles.tag} bg-secondary text-white`}>
                          {selectedEndDate.getMonth() + 1}月{selectedEndDate.getDate()}日
                        </span>
                      </div>
                      <p className="text-sm text-text-muted mt-2">
                        共{getTotalDays()}天，总计：<span className="font-medium text-secondary">¥{getTotalPrice()}</span>
                      </p>
                    </div>
                  )}
                </div>
              </section>

              {/* 立即预约按钮 */}
              <section className={`${styles.glassCard} p-6 rounded-2xl`}>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary">预计费用</span>
                    <span className="text-2xl font-bold text-secondary">¥{getTotalPrice()}</span>
                  </div>
                  <button 
                    onClick={handleBookNow}
                    disabled={!selectedStartDate || !selectedEndDate}
                    className={`${styles.btnPrimary} w-full py-4 rounded-xl text-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    <i className="fas fa-calendar-check mr-2"></i>
                    {selectedStartDate && selectedEndDate ? `立即预约 (${getTotalDays()}天)` : '请先选择预约时间'}
                  </button>
                  <div className="text-center">
                    <p className="text-text-muted text-sm">
                      <i className="fas fa-shield-alt mr-1"></i>
                      支付定金后，订单状态将实时推送给双方
                    </p>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </main>
      </div>

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiCustomerService}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default ServiceDetailPage;

