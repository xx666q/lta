

import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Chart, registerables } from 'chart.js';
import styles from './styles.module.css';

Chart.register(...registerables);

const DataDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState('30d');
  const [region, setRegion] = useState('all');
  const [lastUpdateTime, setLastUpdateTime] = useState('刚刚');
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Chart refs
  const userGrowthChartRef = useRef<HTMLCanvasElement>(null);
  const orderVolumeChartRef = useRef<HTMLCanvasElement>(null);
  const revenueTrendChartRef = useRef<HTMLCanvasElement>(null);
  const regionDistributionChartRef = useRef<HTMLCanvasElement>(null);
  const peakPredictionChartRef = useRef<HTMLCanvasElement>(null);
  
  // Chart instances
  const userGrowthChartInstance = useRef<Chart | null>(null);
  const orderVolumeChartInstance = useRef<Chart | null>(null);
  const revenueTrendChartInstance = useRef<Chart | null>(null);
  const regionDistributionChartInstance = useRef<Chart | null>(null);
  const peakPredictionChartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 数据看板';
    return () => { document.title = originalTitle; };
  }, []);

  useEffect(() => {
    initializeCharts();
    return () => {
      destroyCharts();
    };
  }, []);

  const initializeCharts = () => {
    // 用户增长趋势图
    if (userGrowthChartRef.current) {
      const userGrowthCtx = userGrowthChartRef.current.getContext('2d');
      if (userGrowthCtx) {
        userGrowthChartInstance.current = new Chart(userGrowthCtx, {
          type: 'line',
          data: {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月'],
            datasets: [{
              label: '注册用户',
              data: [5000, 7200, 9500, 11200, 12500, 12847],
              borderColor: '#F48224',
              backgroundColor: 'rgba(244, 130, 36, 0.1)',
              tension: 0.4,
              fill: true
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#4A5568'
                }
              },
              x: {
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#4A5568'
                }
              }
            }
          }
        });
      }
    }

    // 订单量趋势图
    if (orderVolumeChartRef.current) {
      const orderVolumeCtx = orderVolumeChartRef.current.getContext('2d');
      if (orderVolumeCtx) {
        orderVolumeChartInstance.current = new Chart(orderVolumeCtx, {
          type: 'bar',
          data: {
            labels: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
            datasets: [{
              label: '总订单',
              data: [65, 78, 92, 85, 105, 120, 89],
              backgroundColor: 'rgba(244, 130, 36, 0.7)'
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#4A5568'
                }
              },
              x: {
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#4A5568'
                }
              }
            }
          }
        });
      }
    }

    // 收入趋势图
    if (revenueTrendChartRef.current) {
      const revenueTrendCtx = revenueTrendChartRef.current.getContext('2d');
      if (revenueTrendCtx) {
        revenueTrendChartInstance.current = new Chart(revenueTrendCtx, {
          type: 'line',
          data: {
            labels: ['1月', '2月', '3月', '4月', '5月', '6月'],
            datasets: [{
              label: '平台收入',
              data: [15000, 22000, 28000, 35000, 42000, 48000],
              borderColor: '#624731',
              backgroundColor: 'rgba(98, 71, 49, 0.1)',
              tension: 0.4,
              fill: true
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#4A5568'
                }
              },
              x: {
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#4A5568'
                }
              }
            }
          }
        });
      }
    }

    // 热门区域分布图
    if (regionDistributionChartRef.current) {
      const regionDistributionCtx = regionDistributionChartRef.current.getContext('2d');
      if (regionDistributionCtx) {
        regionDistributionChartInstance.current = new Chart(regionDistributionCtx, {
          type: 'doughnut',
          data: {
            labels: ['朝阳区', '海淀区', '西城区', '东城区', '其他'],
            datasets: [{
              data: [35, 28, 15, 12, 10],
              backgroundColor: [
                'rgba(244, 130, 36, 0.8)',
                'rgba(98, 71, 49, 0.8)',
                'rgba(75, 85, 101, 0.8)',
                'rgba(107, 114, 128, 0.8)',
                'rgba(156, 163, 175, 0.8)'
              ],
              borderWidth: 0
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                  color: '#4A5568',
                  padding: 20,
                  usePointStyle: true
                }
              }
            }
          }
        });
      }
    }

    // 峰值预测小图表
    if (peakPredictionChartRef.current) {
      const peakPredictionCtx = peakPredictionChartRef.current.getContext('2d');
      if (peakPredictionCtx) {
        peakPredictionChartInstance.current = new Chart(peakPredictionCtx, {
          type: 'line',
          data: {
            labels: ['今天', '+1天', '+2天', '+3天', '+4天', '+5天', '+6天'],
            datasets: [{
              label: '预测订单数',
              data: [89, 102, 118, 135, 148, 156, 142],
              borderColor: '#F48224',
              backgroundColor: 'rgba(244, 130, 36, 0.1)',
              tension: 0.4,
              fill: true,
              pointBackgroundColor: '#F48224',
              pointBorderColor: '#F48224',
              pointRadius: 4
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false
              }
            },
            scales: {
              y: {
                beginAtZero: false,
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#4A5568',
                  font: {
                    size: 10
                  }
                }
              },
              x: {
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#4A5568',
                  font: {
                    size: 10
                  }
                }
              }
            }
          }
        });
      }
    }
  };

  const destroyCharts = () => {
    if (userGrowthChartInstance.current) {
      userGrowthChartInstance.current.destroy();
      userGrowthChartInstance.current = null;
    }
    if (orderVolumeChartInstance.current) {
      orderVolumeChartInstance.current.destroy();
      orderVolumeChartInstance.current = null;
    }
    if (revenueTrendChartInstance.current) {
      revenueTrendChartInstance.current.destroy();
      revenueTrendChartInstance.current = null;
    }
    if (regionDistributionChartInstance.current) {
      regionDistributionChartInstance.current.destroy();
      regionDistributionChartInstance.current = null;
    }
    if (peakPredictionChartInstance.current) {
      peakPredictionChartInstance.current.destroy();
      peakPredictionChartInstance.current = null;
    }
  };

  const handleTimeRangeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setTimeRange(e.target.value);
    updateChartsWithFilters();
  };

  const handleRegionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setRegion(e.target.value);
    updateChartsWithFilters();
  };

  const handleRefreshData = () => {
    setIsRefreshing(true);
    console.log('刷新所有数据');
    setLastUpdateTime('刚刚刷新');
    
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1000);
  };

  const updateChartsWithFilters = () => {
    console.log('更新图表数据，时间范围:', timeRange, '区域:', region);
    setLastUpdateTime('刚刚更新');
  };

  const handleUserGrowthFilterClick = (filterType: string) => {
    console.log('用户增长趋势图筛选:', filterType);
    // 这里可以更新图表数据
  };

  const handleOrderVolumeFilterClick = (filterType: string) => {
    console.log('订单量趋势图筛选:', filterType);
    // 这里可以更新图表数据
  };

  const handleRevenueTrendFilterClick = (filterType: string) => {
    console.log('收入趋势图筛选:', filterType);
    // 这里可以更新图表数据
  };

  const handleRegionChartToggle = () => {
    if (regionDistributionChartInstance.current) {
      const chart = regionDistributionChartInstance.current;
      
      if (chart.config.type === 'doughnut') {
        chart.config.type = 'bar';
        chart.config.data.datasets[0] = {
          label: '订单数量',
          data: [350, 280, 150, 120, 100],
          backgroundColor: 'rgba(244, 130, 36, 0.7)'
        };
        
        // 确保 options、plugins 和 legend 存在
        if (!chart.config.options) {
          chart.config.options = {};
        }
        if (!chart.config.options.plugins) {
          chart.config.options.plugins = {};
        }
        if (!chart.config.options.plugins.legend) {
          chart.config.options.plugins.legend = {};
        }
        
        chart.config.options.plugins.legend.position = 'top';
      } else {
        chart.config.type = 'doughnut';
        chart.config.data.datasets[0] = {
          data: [35, 28, 15, 12, 10],
          backgroundColor: [
            'rgba(244, 130, 36, 0.8)',
            'rgba(98, 71, 49, 0.8)',
            'rgba(75, 85, 101, 0.8)',
            'rgba(107, 114, 128, 0.8)',
            'rgba(156, 163, 175, 0.8)'
          ],
          borderWidth: 0
        };
        
        // 确保 options、plugins 和 legend 存在
        if (!chart.config.options) {
          chart.config.options = {};
        }
        if (!chart.config.options.plugins) {
          chart.config.options.plugins = {};
        }
        if (!chart.config.options.plugins.legend) {
          chart.config.options.plugins.legend = {};
        }
        
        chart.config.options.plugins.legend.position = 'bottom';
      }
      
      chart.update();
    }
  };

  const handleViewDetailedPrediction = () => {
    alert('详细预测功能开发中...');
  };

  const handleAiCustomerService = () => {
    alert('AI客服功能开发中...');
  };

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const searchTerm = (e.target as HTMLInputElement).value;
      console.log('搜索:', searchTerm);
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索用户、服务..." 
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
                onKeyPress={handleSearchKeyPress}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img src="https://s.coze.cn/image/3-lbWx-FzCs/" 
                 alt="管理员头像" className="w-8 h-8 rounded-full" />
            <span className="text-text-primary font-medium hidden md:block">管理员</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link to="/admin-dashboard" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link to="/user-manage" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-users text-lg"></i>
              <span className="font-medium">用户管理</span>
            </Link>
            <Link to="/service-manage" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-handshake text-lg"></i>
              <span className="font-medium">服务管理</span>
            </Link>
            <Link to="/admin-order-manage" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-shopping-cart text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <Link to="/content-moderation" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-shield-alt text-lg"></i>
              <span className="font-medium">内容巡查</span>
            </Link>
            <Link to="/data-dashboard" className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-chart-bar text-lg"></i>
              <span className="font-medium">数据看板</span>
            </Link>
            <Link to="/system-settings" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-cog text-lg"></i>
              <span className="font-medium">系统设置</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">数据看板</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">数据看板</h1>
                <p className="text-text-secondary mt-1">实时监控平台运营数据，智能分析业务趋势</p>
              </div>
              <div className="flex items-center space-x-2 text-text-muted">
                <i className="fas fa-sync-alt"></i>
                <span className="text-sm">最后更新：{lastUpdateTime}</span>
              </div>
            </div>
          </header>

          {/* 数据筛选器 */}
          <section className={`${styles.glassCard} p-4 rounded-2xl`}>
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-text-secondary">时间范围：</label>
                <select 
                  value={timeRange}
                  onChange={handleTimeRangeChange}
                  className="px-3 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary text-sm focus:outline-none focus:ring-2 focus:ring-secondary/50"
                >
                  <option value="7d">最近7天</option>
                  <option value="30d">最近30天</option>
                  <option value="90d">最近90天</option>
                  <option value="1y">最近1年</option>
                </select>
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-text-secondary">区域：</label>
                <select 
                  value={region}
                  onChange={handleRegionChange}
                  className="px-3 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary text-sm focus:outline-none focus:ring-2 focus:ring-secondary/50"
                >
                  <option value="all">全国</option>
                  <option value="beijing">北京</option>
                  <option value="shanghai">上海</option>
                  <option value="guangzhou">广州</option>
                  <option value="shenzhen">深圳</option>
                </select>
              </div>
              <button 
                onClick={handleRefreshData}
                className={`${styles.btnSecondary} px-4 py-2 rounded-lg text-sm font-medium`}
              >
                <i className={`fas fa-sync-alt mr-2 ${isRefreshing ? 'fa-spin' : ''}`}></i>刷新数据
              </button>
            </div>
          </section>

          {/* 核心指标卡片区 */}
          <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">注册用户数</p>
                  <p className="text-3xl font-bold text-accent mt-2">12,847</p>
                  <p className="text-green-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +12.5% 较上月
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-users text-blue-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">活跃服务商</p>
                  <p className="text-3xl font-bold text-accent mt-2">356</p>
                  <p className="text-green-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +8.2% 较上月
                  </p>
                </div>
                <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-handshake text-secondary text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">今日订单数</p>
                  <p className="text-3xl font-bold text-accent mt-2">89</p>
                  <p className="text-green-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +15.3% 较昨日
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-shopping-cart text-green-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">订单转化率</p>
                  <p className="text-3xl font-bold text-accent mt-2">67.8%</p>
                  <p className="text-green-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +2.1% 较上月
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-chart-line text-purple-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">客单价</p>
                  <p className="text-3xl font-bold text-accent mt-2">¥186</p>
                  <p className="text-green-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +5.7% 较上月
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-yen-sign text-yellow-500 text-xl"></i>
                </div>
              </div>
            </div>
          </section>

          {/* 趋势图区域 */}
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 用户增长趋势 */}
            <div className={`${styles.chartContainer} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-accent">用户增长趋势</h3>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleUserGrowthFilterClick('registered')}
                    className={`${styles.filterButton} ${styles.active} px-3 py-1 rounded-lg text-sm`}
                  >
                    注册用户
                  </button>
                  <button 
                    onClick={() => handleUserGrowthFilterClick('active')}
                    className={`${styles.filterButton} px-3 py-1 rounded-lg text-sm`}
                  >
                    活跃用户
                  </button>
                </div>
              </div>
              <canvas ref={userGrowthChartRef} className="w-full h-64"></canvas>
            </div>

            {/* 订单量趋势 */}
            <div className={`${styles.chartContainer} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-accent">订单量趋势</h3>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleOrderVolumeFilterClick('total')}
                    className={`${styles.filterButton} ${styles.active} px-3 py-1 rounded-lg text-sm`}
                  >
                    总订单
                  </button>
                  <button 
                    onClick={() => handleOrderVolumeFilterClick('completed')}
                    className={`${styles.filterButton} px-3 py-1 rounded-lg text-sm`}
                  >
                    已完成
                  </button>
                  <button 
                    onClick={() => handleOrderVolumeFilterClick('cancelled')}
                    className={`${styles.filterButton} px-3 py-1 rounded-lg text-sm`}
                  >
                    取消订单
                  </button>
                </div>
              </div>
              <canvas ref={orderVolumeChartRef} className="w-full h-64"></canvas>
            </div>
          </section>

          {/* 收入趋势和热门区域 */}
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 收入趋势 */}
            <div className={`${styles.chartContainer} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-accent">收入趋势</h3>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleRevenueTrendFilterClick('platform')}
                    className={`${styles.filterButton} ${styles.active} px-3 py-1 rounded-lg text-sm`}
                  >
                    平台收入
                  </button>
                  <button 
                    onClick={() => handleRevenueTrendFilterClick('provider')}
                    className={`${styles.filterButton} px-3 py-1 rounded-lg text-sm`}
                  >
                    服务商收入
                  </button>
                </div>
              </div>
              <canvas ref={revenueTrendChartRef} className="w-full h-64"></canvas>
            </div>

            {/* 热门区域分布 */}
            <div className={`${styles.chartContainer} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-accent">热门区域分布</h3>
                <button 
                  onClick={handleRegionChartToggle}
                  className={`${styles.filterButton} px-3 py-1 rounded-lg text-sm`}
                >
                  <i className="fas fa-chart-pie mr-1"></i>切换图表
                </button>
              </div>
              <canvas ref={regionDistributionChartRef} className="w-full h-64"></canvas>
            </div>
          </section>

          {/* AI预测概览 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <h3 className="text-lg font-semibold text-accent">AI预测概览</h3>
                <div className="flex items-center space-x-1 text-text-muted">
                  <i className="fas fa-robot"></i>
                  <span className="text-sm">基于机器学习算法预测</span>
                </div>
              </div>
              <button 
                onClick={handleViewDetailedPrediction}
                className={`${styles.btnSecondary} px-4 py-2 rounded-lg text-sm font-medium`}
              >
                查看详细预测
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* 未来7日订单峰值预测 */}
              <div className="bg-gradient-to-r from-secondary/10 to-accent/10 p-4 rounded-xl border border-secondary/20">
                <h4 className="font-medium text-accent mb-3">未来7日订单峰值预测</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">预测峰值日</span>
                    <span className="text-sm font-medium text-accent">3月25日（周一）</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">预测订单数</span>
                    <span className="text-sm font-medium text-accent">156单</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">置信度</span>
                    <span className="text-sm font-medium text-green-600">92%</span>
                  </div>
                </div>
                <div className="mt-4">
                  <canvas ref={peakPredictionChartRef} className="w-full h-32"></canvas>
                </div>
              </div>

              {/* 热门服务类型预测 */}
              <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-4 rounded-xl border border-blue-500/20">
                <h4 className="font-medium text-accent mb-3">热门服务类型预测</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">日托服务</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-blue-500/20 rounded-full overflow-hidden">
                        <div className="w-4/5 h-full bg-blue-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium text-accent">80%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">周托服务</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-purple-500/20 rounded-full overflow-hidden">
                        <div className="w-3/5 h-full bg-purple-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium text-accent">60%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">小时陪遛</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-green-500/20 rounded-full overflow-hidden">
                        <div className="w-2/5 h-full bg-green-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium text-accent">40%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 区域需求热度 */}
              <div className="bg-gradient-to-r from-green-500/10 to-yellow-500/10 p-4 rounded-xl border border-green-500/20">
                <h4 className="font-medium text-accent mb-3">区域需求热度</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <span className="text-sm text-text-secondary">朝阳区</span>
                    </div>
                    <span className="text-sm font-medium text-accent">高需求</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                      <span className="text-sm text-text-secondary">海淀区</span>
                    </div>
                    <span className="text-sm font-medium text-accent">中需求</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-text-secondary">西城区</span>
                    </div>
                    <span className="text-sm font-medium text-accent">低需求</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span className="text-sm text-text-secondary">东城区</span>
                    </div>
                    <span className="text-sm font-medium text-accent">中需求</span>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiCustomerService}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default DataDashboard;

