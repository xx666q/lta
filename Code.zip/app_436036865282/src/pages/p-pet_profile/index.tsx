

import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface PetData {
  id: string;
  name: string;
  breed: string;
  birthday: string;
  gender: 'male' | 'female';
  avatar: string;
  vaccination: string;
  deworming: string;
  allergies: string;
  tags: string[];
}

interface FormData {
  name: string;
  breed: string;
  birthday: string;
  gender: 'male' | 'female' | '';
  vaccination: string;
  deworming: string;
  allergies: string;
  tags: string[];
  avatar: string | null;
}

const PetProfilePage: React.FC = () => {
  const navigate = useNavigate();
  
  // 宠物数据状态
  const [petsData, setPetsData] = useState<Record<string, PetData>>({
    pet1: {
      id: 'pet1',
      name: '豆豆',
      breed: '金毛寻回犬',
      birthday: '2017-05-15',
      gender: 'male',
      avatar: 'https://s.coze.cn/image/rjgn0RPWIfU/',
      vaccination: '狂犬疫苗：2024-01-15\n六联疫苗：2024-01-15',
      deworming: '体内驱虫：2024-02-20\n体外驱虫：2024-02-20',
      allergies: '无已知过敏史',
      tags: ['温顺', '友善', '聪明']
    },
    pet2: {
      id: 'pet2',
      name: '咪咪',
      breed: '布偶猫',
      birthday: '2020-08-22',
      gender: 'female',
      avatar: 'https://s.coze.cn/image/xcCWQT1CLHI/',
      vaccination: '猫三联疫苗：2024-01-20\n狂犬疫苗：2024-01-20',
      deworming: '体内驱虫：2024-02-25\n体外驱虫：2024-02-25',
      allergies: '无已知过敏史',
      tags: ['温顺', '粘人', '独立']
    }
  });

  // 模态弹窗状态
  const [showPetModal, setShowPetModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [currentEditingPetId, setCurrentEditingPetId] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  // 表单数据状态
  const [formData, setFormData] = useState<FormData>({
    name: '',
    breed: '',
    birthday: '',
    gender: '',
    vaccination: '',
    deworming: '',
    allergies: '',
    tags: [],
    avatar: null
  });

  // 删除确认状态
  const [deletePetName, setDeletePetName] = useState('');

  // 文件输入引用
  const avatarInputRef = useRef<HTMLInputElement>(null);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 我的宠物';
    return () => { document.title = originalTitle; };
  }, []);

  // 计算宠物年龄
  const calculateAge = (birthday: string): string => {
    if (!birthday) return '未知';
    
    const birthDate = new Date(birthday);
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      return (age - 1) + '岁';
    }
    return age + '岁';
  };

  // 打开添加宠物模态弹窗
  const handleOpenAddPetModal = () => {
    setIsEditing(false);
    setCurrentEditingPetId(null);
    resetForm();
    setShowPetModal(true);
  };

  // 打开编辑宠物模态弹窗
  const handleOpenEditPetModal = (petId: string) => {
    setIsEditing(true);
    setCurrentEditingPetId(petId);
    const pet = petsData[petId];
    if (pet) {
      setFormData({
        name: pet.name,
        breed: pet.breed,
        birthday: pet.birthday,
        gender: pet.gender,
        vaccination: pet.vaccination,
        deworming: pet.deworming,
        allergies: pet.allergies,
        tags: [...pet.tags],
        avatar: pet.avatar
      });
    }
    setShowPetModal(true);
  };

  // 打开删除确认模态弹窗
  const handleOpenDeleteModal = (petId: string) => {
    setCurrentEditingPetId(petId);
    const pet = petsData[petId];
    setDeletePetName(pet.name);
    setShowDeleteModal(true);
  };

  // 关闭宠物模态弹窗
  const handleClosePetModal = () => {
    setShowPetModal(false);
    setCurrentEditingPetId(null);
    resetForm();
  };

  // 关闭删除确认模态弹窗
  const handleCloseDeleteModal = () => {
    setShowDeleteModal(false);
    setCurrentEditingPetId(null);
  };

  // 重置表单
  const resetForm = () => {
    setFormData({
      name: '',
      breed: '',
      birthday: '',
      gender: '',
      vaccination: '',
      deworming: '',
      allergies: '',
      tags: [],
      avatar: null
    });
    if (avatarInputRef.current) {
      avatarInputRef.current.value = '';
    }
  };

  // 处理表单输入变化
  const handleFormChange = (field: keyof FormData, value: string | string[] | null) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // 处理性别选择
  const handleGenderChange = (gender: 'male' | 'female') => {
    setFormData(prev => ({
      ...prev,
      gender
    }));
  };

  // 处理性格标签选择
  const handleTagToggle = (tag: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.includes(tag) 
        ? prev.tags.filter(t => t !== tag)
        : [...prev.tags, tag]
    }));
  };

  // 处理头像上传
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setFormData(prev => ({
          ...prev,
          avatar: result
        }));
        simulateAIIdentification();
      };
      reader.readAsDataURL(file);
    }
  };

  // 模拟AI识别
  const simulateAIIdentification = () => {
    setTimeout(() => {
      const breeds = ['金毛寻回犬', '拉布拉多犬', '哈士奇', '布偶猫', '英短猫', '橘猫'];
      const randomBreed = breeds[Math.floor(Math.random() * breeds.length)];
      
      setFormData(prev => ({
        ...prev,
        breed: randomBreed
      }));
      
      alert(`AI识别完成：这是一只${randomBreed}！`);
    }, 2000);
  };

  // 处理表单提交
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isEditing && currentEditingPetId) {
      // 更新宠物
      setPetsData(prev => ({
        ...prev,
        [currentEditingPetId]: {
          ...prev[currentEditingPetId],
          ...formData,
          id: currentEditingPetId
        }
      }));
    } else {
      // 添加新宠物
      const newPetId = 'pet' + (Object.keys(petsData).length + 1);
      const newPet: PetData = {
        id: newPetId,
        ...formData,
        avatar: formData.avatar || 'https://s.coze.cn/image/eWvjreUE0t8/'
      };
      
      setPetsData(prev => ({
        ...prev,
        [newPetId]: newPet
      }));
    }
    
    handleClosePetModal();
    alert('宠物档案保存成功！');
  };

  // 处理删除确认
  const handleConfirmDelete = () => {
    if (currentEditingPetId) {
      setPetsData(prev => {
        const newData = { ...prev };
        delete newData[currentEditingPetId];
        return newData;
      });
      
      handleCloseDeleteModal();
      alert('宠物档案删除成功！');
    }
  };

  // 处理AI客服按钮点击
  const handleAICustomerService = () => {
    console.log('打开AI客服');
  };

  const personalityTags = ['温顺', '活泼', '粘人', '独立', '友善', '胆小', '聪明', '贪吃'];

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img 
              src="https://s.coze.cn/image/aNPfbNklAtI/" 
              alt="用户头像" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-text-primary font-medium hidden md:block">张小明</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link 
              to="/owner-dashboard" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link 
              to="/pet-profile" 
              className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}
            >
              <i className="fas fa-paw text-lg"></i>
              <span className="font-medium">我的宠物</span>
            </Link>
            <Link 
              to="/service-discovery" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-search text-lg"></i>
              <span className="font-medium">寻找服务</span>
            </Link>
            <Link 
              to="/owner-calendar" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-calendar-alt text-lg"></i>
              <span className="font-medium">托管日历</span>
            </Link>
            <Link 
              to="/cloud-view" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-video text-lg"></i>
              <span className="font-medium">云看宠</span>
            </Link>
            <Link 
              to="/user-profile" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">我的宠物</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">我的宠物</h1>
                <p className="text-text-secondary mt-1">管理您的爱宠档案，让托管更安心</p>
              </div>
              <button 
                onClick={handleOpenAddPetModal}
                className={`${styles.btnPrimary} px-6 py-3 rounded-xl text-white font-medium hover:shadow-lg transition-all`}
              >
                <i className="fas fa-plus mr-2"></i>
                添加宠物
              </button>
            </div>
          </header>

          {/* 宠物列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">宠物档案</h2>
              <div className="text-text-muted text-sm">
                共 <span className="font-medium text-accent">{Object.keys(petsData).length}</span> 只宠物
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className={`w-full ${styles.tableGlass} rounded-xl overflow-hidden`}>
                <thead className="bg-white/10">
                  <tr>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">头像</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">宠物名称</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">品种</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">生日</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">性别</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">年龄</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">状态</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(petsData).map(([petId, pet], index) => (
                    <tr 
                      key={petId} 
                      className={`${styles.tableRow} ${index < Object.keys(petsData).length - 1 ? 'border-b border-white/10' : ''}`}
                    >
                      <td className="px-4 py-3">
                        <img 
                          src={pet.avatar} 
                          alt={pet.name} 
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      </td>
                      <td className="px-4 py-3 text-text-primary font-medium">{pet.name}</td>
                      <td className="px-4 py-3 text-text-secondary">{pet.breed}</td>
                      <td className="px-4 py-3 text-text-secondary">{pet.birthday}</td>
                      <td className="px-4 py-3 text-text-secondary">{pet.gender === 'male' ? '公' : '母'}</td>
                      <td className="px-4 py-3 text-text-secondary">{calculateAge(pet.birthday)}</td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-1 bg-green-500/20 text-green-600 text-xs rounded-full">健康</span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => handleOpenEditPetModal(petId)}
                            className="text-secondary hover:text-accent text-sm font-medium"
                          >
                            <i className="fas fa-edit mr-1"></i>编辑
                          </button>
                          <button 
                            onClick={() => handleOpenDeleteModal(petId)}
                            className="text-red-500 hover:text-red-600 text-sm font-medium"
                          >
                            <i className="fas fa-trash mr-1"></i>删除
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* AI识别功能介绍 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
                <i className="fas fa-robot text-secondary"></i>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-accent">AI智能识别</h2>
                <p className="text-text-muted text-sm">上传宠物照片，AI自动识别品种并完善档案</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gradient-to-r from-secondary/10 to-accent/10 p-4 rounded-xl border border-secondary/20">
                <div className="flex items-center space-x-2 mb-2">
                  <i className="fas fa-eye text-secondary"></i>
                  <span className="font-medium text-accent text-sm">品种识别</span>
                </div>
                <p className="text-text-muted text-xs">自动识别宠物品种，准确率达95%以上</p>
              </div>
              <div className="bg-gradient-to-r from-secondary/10 to-accent/10 p-4 rounded-xl border border-secondary/20">
                <div className="flex items-center space-x-2 mb-2">
                  <i className="fas fa-calculator text-secondary"></i>
                  <span className="font-medium text-accent text-sm">年龄估算</span>
                </div>
                <p className="text-text-muted text-xs">根据面部特征估算宠物年龄</p>
              </div>
              <div className="bg-gradient-to-r from-secondary/10 to-accent/10 p-4 rounded-xl border border-secondary/20">
                <div className="flex items-center space-x-2 mb-2">
                  <i className="fas fa-magic text-secondary"></i>
                  <span className="font-medium text-accent text-sm">信息补全</span>
                </div>
                <p className="text-text-muted text-xs">自动补全体型、毛长等详细信息</p>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* 添加/编辑宠物模态弹窗 */}
      {showPetModal && (
        <div 
          className={`${styles.modalOverlay} fixed inset-0 z-50 flex items-center justify-center`}
          onClick={(e) => e.target === e.currentTarget && handleClosePetModal()}
        >
          <div className={`${styles.modalContent} w-full max-w-2xl mx-4 rounded-2xl overflow-hidden`}>
            <div className="flex items-center justify-between p-6 border-b border-white/20">
              <h3 className="text-xl font-semibold text-accent">
                {isEditing ? '编辑宠物' : '添加宠物'}
              </h3>
              <button 
                onClick={handleClosePetModal}
                className="text-text-muted hover:text-accent transition-colors"
              >
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            
            <form onSubmit={handleFormSubmit} className="p-6 space-y-6">
              {/* 基本信息 */}
              <div className="space-y-4">
                <h4 className="text-lg font-medium text-accent mb-4">基本信息</h4>
                
                {/* 宠物头像上传 */}
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-text-primary">宠物头像</label>
                  {!formData.avatar ? (
                    <div 
                      onClick={() => avatarInputRef.current?.click()}
                      className={`${styles.uploadArea} w-full h-48 rounded-xl flex flex-col items-center justify-center cursor-pointer`}
                    >
                      <i className="fas fa-camera text-4xl text-secondary mb-2"></i>
                      <p className="text-text-secondary text-sm">点击上传宠物照片</p>
                      <p className="text-text-muted text-xs mt-1">支持JPG、PNG格式，最大5MB</p>
                      <input 
                        ref={avatarInputRef}
                        type="file" 
                        accept="image/*" 
                        onChange={handleAvatarUpload}
                        className="hidden"
                      />
                    </div>
                  ) : (
                    <div>
                      <img 
                        src={formData.avatar} 
                        alt="宠物头像预览" 
                        className="w-24 h-24 rounded-full object-cover"
                      />
                    </div>
                  )}
                </div>
                
                {/* 宠物名称 */}
                <div className="space-y-2">
                  <label htmlFor="pet-name" className="block text-sm font-medium text-text-primary">
                    宠物名称 *
                  </label>
                  <input 
                    type="text" 
                    id="pet-name" 
                    value={formData.name}
                    onChange={(e) => handleFormChange('name', e.target.value)}
                    className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请输入宠物名称" 
                    required 
                  />
                </div>
                
                {/* 品种 */}
                <div className="space-y-2">
                  <label htmlFor="pet-breed" className="block text-sm font-medium text-text-primary">
                    品种
                  </label>
                  <input 
                    type="text" 
                    id="pet-breed" 
                    value={formData.breed}
                    onChange={(e) => handleFormChange('breed', e.target.value)}
                    className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="如：金毛寻回犬、布偶猫等"
                  />
                  <p className="text-text-muted text-xs">上传照片后AI将自动识别品种</p>
                </div>
                
                {/* 生日 */}
                <div className="space-y-2">
                  <label htmlFor="pet-birthday" className="block text-sm font-medium text-text-primary">
                    生日
                  </label>
                  <input 
                    type="date" 
                    id="pet-birthday" 
                    value={formData.birthday}
                    onChange={(e) => handleFormChange('birthday', e.target.value)}
                    className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary`}
                  />
                </div>
                
                {/* 性别 */}
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-text-primary">性别</label>
                  <div className="flex space-x-4">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="pet-gender" 
                        value="male" 
                        checked={formData.gender === 'male'}
                        onChange={() => handleGenderChange('male')}
                        className="text-secondary focus:ring-secondary"
                      />
                      <span className="text-text-primary">公</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="pet-gender" 
                        value="female" 
                        checked={formData.gender === 'female'}
                        onChange={() => handleGenderChange('female')}
                        className="text-secondary focus:ring-secondary"
                      />
                      <span className="text-text-primary">母</span>
                    </label>
                  </div>
                </div>
              </div>
              
              {/* 健康信息 */}
              <div className="space-y-4">
                <h4 className="text-lg font-medium text-accent mb-4">健康信息</h4>
                
                {/* 疫苗记录 */}
                <div className="space-y-2">
                  <label htmlFor="vaccination-records" className="block text-sm font-medium text-text-primary">
                    疫苗记录
                  </label>
                  <textarea 
                    id="vaccination-records" 
                    rows={3}
                    value={formData.vaccination}
                    onChange={(e) => handleFormChange('vaccination', e.target.value)}
                    className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted resize-none`}
                    placeholder="请记录宠物的疫苗接种情况，如：狂犬疫苗、六联疫苗等"
                  />
                </div>
                
                {/* 驱虫记录 */}
                <div className="space-y-2">
                  <label htmlFor="deworming-records" className="block text-sm font-medium text-text-primary">
                    驱虫记录
                  </label>
                  <textarea 
                    id="deworming-records" 
                    rows={3}
                    value={formData.deworming}
                    onChange={(e) => handleFormChange('deworming', e.target.value)}
                    className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted resize-none`}
                    placeholder="请记录宠物的驱虫情况，如：体内驱虫、体外驱虫等"
                  />
                </div>
                
                {/* 过敏史 */}
                <div className="space-y-2">
                  <label htmlFor="allergies" className="block text-sm font-medium text-text-primary">
                    过敏史
                  </label>
                  <textarea 
                    id="allergies" 
                    rows={3}
                    value={formData.allergies}
                    onChange={(e) => handleFormChange('allergies', e.target.value)}
                    className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted resize-none`}
                    placeholder="请记录宠物的过敏情况，如：食物过敏、药物过敏等"
                  />
                </div>
              </div>
              
              {/* 性格标签 */}
              <div className="space-y-4">
                <h4 className="text-lg font-medium text-accent mb-4">性格标签</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {personalityTags.map((tag) => (
                    <button 
                      key={tag}
                      type="button" 
                      onClick={() => handleTagToggle(tag)}
                      className={`${styles.tagItem} ${formData.tags.includes(tag) ? styles.selected : ''} px-4 py-2 rounded-lg text-sm font-medium transition-all`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* 表单操作 */}
              <div className="flex items-center justify-end space-x-4 pt-6 border-t border-white/20">
                <button 
                  type="button" 
                  onClick={handleClosePetModal}
                  className={`${styles.btnSecondary} px-6 py-3 rounded-xl font-medium`}
                >
                  取消
                </button>
                <button 
                  type="submit" 
                  className={`${styles.btnPrimary} px-6 py-3 rounded-xl text-white font-medium`}
                >
                  保存
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 删除确认模态弹窗 */}
      {showDeleteModal && (
        <div 
          className={`${styles.modalOverlay} fixed inset-0 z-50 flex items-center justify-center`}
          onClick={(e) => e.target === e.currentTarget && handleCloseDeleteModal()}
        >
          <div className={`${styles.modalContent} w-full max-w-md mx-4 rounded-2xl overflow-hidden`}>
            <div className="flex items-center justify-between p-6 border-b border-white/20">
              <h3 className="text-xl font-semibold text-accent">确认删除</h3>
              <button 
                onClick={handleCloseDeleteModal}
                className="text-text-muted hover:text-accent transition-colors"
              >
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            
            <div className="p-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-exclamation-triangle text-red-500 text-2xl"></i>
                </div>
                <h4 className="text-lg font-medium text-accent mb-2">删除宠物档案</h4>
                <p className="text-text-secondary mb-6">
                  确定要删除 <span className="font-medium text-accent">{deletePetName}</span> 的档案吗？此操作不可撤销。
                </p>
                
                <div className="flex space-x-3">
                  <button 
                    onClick={handleCloseDeleteModal}
                    className={`${styles.btnSecondary} flex-1 py-3 rounded-xl font-medium`}
                  >
                    取消
                  </button>
                  <button 
                    onClick={handleConfirmDelete}
                    className={`${styles.btnDanger} flex-1 py-3 rounded-xl font-medium`}
                  >
                    删除
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAICustomerService}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default PetProfilePage;

