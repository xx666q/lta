

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';

interface ServiceData {
  id: string;
  name: string;
  type: 'daycare' | 'weekcare' | 'walking';
  price: string;
  maxPets: string;
  address: string;
  description: string;
  notes: string;
  petTypes: string[];
  status: 'online' | 'offline';
}

interface FormData {
  serviceName: string;
  serviceType: string;
  servicePrice: string;
  maxPets: string;
  serviceAddress: string;
  serviceDescription: string;
  serviceNotes: string;
  petTypes: string[];
}

const ServicePublishPage: React.FC = () => {
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [currentEditingServiceId, setCurrentEditingServiceId] = useState<string | null>(null);
  const [serviceToDelete, setServiceToDelete] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);

  const [formData, setFormData] = useState<FormData>({
    serviceName: '',
    serviceType: '',
    servicePrice: '',
    maxPets: '3',
    serviceAddress: '',
    serviceDescription: '',
    serviceNotes: '',
    petTypes: []
  });

  const [servicesData, setServicesData] = useState<ServiceData[]>([
    {
      id: 'service1',
      name: '温馨家庭日托',
      type: 'daycare',
      price: '80',
      maxPets: '3',
      address: '北京市朝阳区三里屯街道工体北路8号',
      description: '温馨舒适的家庭环境，专业的宠物护理经验',
      notes: '• 请提前告知宠物的饮食习惯和特殊需求\n• 建议携带宠物的常用用品',
      petTypes: ['dog', 'cat'],
      status: 'online'
    },
    {
      id: 'service2',
      name: '专业宠物陪遛',
      type: 'walking',
      price: '30',
      maxPets: '2',
      address: '北京市朝阳区朝阳公园附近',
      description: '专业的宠物陪遛服务，确保宠物的安全和健康',
      notes: '• 请告知宠物的性格特点和运动量需求\n• 我们会选择安全的路线进行遛弯',
      petTypes: ['large-dog'],
      status: 'offline'
    },
    {
      id: 'service3',
      name: '长期周托服务',
      type: 'weekcare',
      price: '400',
      maxPets: '4',
      address: '北京市海淀区中关村大街27号',
      description: '专业的长期托管服务，让您安心出差旅行',
      notes: '• 请提供宠物的完整疫苗记录\n• 建议准备足够的宠物食品和用品',
      petTypes: ['dog', 'cat', 'other'],
      status: 'online'
    }
  ]);

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 服务发布';
    return () => { document.title = originalTitle; };
  }, []);

  const getPriceUnit = (serviceType: string): string => {
    switch(serviceType) {
      case 'daycare':
        return '¥/天';
      case 'weekcare':
        return '¥/周';
      case 'walking':
        return '¥/小时';
      default:
        return '¥/天';
    }
  };

  const generateServiceNotes = (serviceType: string, petTypes: string[]): string => {
    if (!serviceType) {
      return '';
    }

    const notes: Record<string, string> = {
      'daycare': '• 请提前告知宠物的饮食习惯和特殊需求\n• 建议携带宠物的常用用品（如餐具、玩具）\n• 我们将提供舒适的休息环境和适量运动\n• 每日会发送宠物的照片和视频',
      'weekcare': '• 请提供宠物的完整疫苗记录\n• 建议准备足够的宠物食品和用品\n• 我们提供24小时监护和专业护理\n• 每周至少3次户外活动\n• 每日健康报告和照片更新',
      'walking': '• 请告知宠物的性格特点和运动量需求\n• 我们会选择安全的路线进行遛弯\n• 每次遛弯时间保证充足\n• 遛弯过程中会注意宠物的安全'
    };

    let generatedNotes = notes[serviceType];
    
    if (petTypes.length > 0) {
      generatedNotes += '\n\n特殊注意事项：';
      if (petTypes.includes('cat')) {
        generatedNotes += '\n• 猫咪需要安静的环境，避免过度打扰';
      }
      if (petTypes.includes('large-dog')) {
        generatedNotes += '\n• 大型犬需要更多的运动空间和关注';
      }
    }

    return generatedNotes;
  };

  const handleServiceTypeChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      serviceType: value
    }));
    
    // 触发AI生成注意事项
    const newNotes = generateServiceNotes(value, formData.petTypes);
    setFormData(prev => ({
      ...prev,
      serviceNotes: newNotes
    }));
  };

  const handlePetTypeChange = (value: string, checked: boolean) => {
    const newPetTypes = checked 
      ? [...formData.petTypes, value]
      : formData.petTypes.filter(type => type !== value);
    
    setFormData(prev => ({
      ...prev,
      petTypes: newPetTypes
    }));
    
    // 更新注意事项
    const newNotes = generateServiceNotes(formData.serviceType, newPetTypes);
    setFormData(prev => ({
      ...prev,
      serviceNotes: newNotes
    }));
  };

  const handleGenerateNotes = () => {
    const newNotes = generateServiceNotes(formData.serviceType, formData.petTypes);
    setFormData(prev => ({
      ...prev,
      serviceNotes: newNotes
    }));
  };

  const handleAddService = () => {
    setCurrentEditingServiceId(null);
    setFormData({
      serviceName: '',
      serviceType: '',
      servicePrice: '',
      maxPets: '3',
      serviceAddress: '',
      serviceDescription: '',
      serviceNotes: '',
      petTypes: []
    });
    setUploadedPhotos([]);
    setShowServiceModal(true);
  };

  const handleEditService = (serviceId: string) => {
    setCurrentEditingServiceId(serviceId);
    const service = servicesData.find(s => s.id === serviceId);
    
    if (service) {
      setFormData({
        serviceName: service.name,
        serviceType: service.type,
        servicePrice: service.price,
        maxPets: service.maxPets,
        serviceAddress: service.address,
        serviceDescription: service.description,
        serviceNotes: service.notes,
        petTypes: service.petTypes
      });
    }
    
    setUploadedPhotos([]);
    setShowServiceModal(true);
  };

  const handleCloseModal = () => {
    setShowServiceModal(false);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // 验证表单
    if (!formData.serviceName || !formData.serviceType || !formData.servicePrice || !formData.serviceAddress || formData.petTypes.length === 0) {
      alert('请填写所有必填项');
      return;
    }
    
    // 模拟保存服务
    if (currentEditingServiceId) {
      setServicesData(prev => prev.map(service => 
        service.id === currentEditingServiceId 
          ? {
              ...service,
              name: formData.serviceName,
              type: formData.serviceType as 'daycare' | 'weekcare' | 'walking',
              price: formData.servicePrice,
              maxPets: formData.maxPets,
              address: formData.serviceAddress,
              description: formData.serviceDescription,
              notes: formData.serviceNotes,
              petTypes: formData.petTypes
            }
          : service
      ));
    } else {
      const newService: ServiceData = {
        id: `service${Date.now()}`,
        name: formData.serviceName,
        type: formData.serviceType as 'daycare' | 'weekcare' | 'walking',
        price: formData.servicePrice,
        maxPets: formData.maxPets,
        address: formData.serviceAddress,
        description: formData.serviceDescription,
        notes: formData.serviceNotes,
        petTypes: formData.petTypes,
        status: 'online'
      };
      setServicesData(prev => [...prev, newService]);
    }
    
    setShowServiceModal(false);
    alert('服务保存成功！');
  };

  const handleToggleService = (serviceId: string) => {
    setServicesData(prev => prev.map(service =>
      service.id === serviceId
        ? { ...service, status: service.status === 'online' ? 'offline' : 'online' }
        : service
    ));
  };

  const handleDeleteService = (serviceId: string) => {
    setServiceToDelete(serviceId);
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = () => {
    if (serviceToDelete) {
      setServicesData(prev => prev.filter(service => service.id !== serviceToDelete));
    }
    setShowDeleteModal(false);
    setServiceToDelete(null);
  };

  const handleCancelDelete = () => {
    setShowDeleteModal(false);
    setServiceToDelete(null);
  };

  const handlePhotoUpload = (index: number, file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const newPhotos = [...uploadedPhotos];
      newPhotos[index] = e.target?.result as string;
      setUploadedPhotos(newPhotos);
    };
    reader.readAsDataURL(file);
  };

  const handlePhotoRemove = (index: number) => {
    const newPhotos = [...uploadedPhotos];
    newPhotos[index] = '';
    setUploadedPhotos(newPhotos);
  };

  const handleSearchKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      console.log('搜索:', searchInput);
    }
  };

  const getFilteredServices = () => {
    if (!statusFilter) {
      return servicesData;
    }
    return servicesData.filter(service => service.status === statusFilter);
  };

  const getServiceTypeDisplay = (type: string): string => {
    switch(type) {
      case 'daycare':
        return '日托服务';
      case 'weekcare':
        return '周托服务';
      case 'walking':
        return '小时陪遛';
      default:
        return type;
    }
  };

  const getPetTypesDisplay = (petTypes: string[]): string => {
    const mapping: Record<string, string> = {
      'dog': '小型犬',
      'large-dog': '中大型犬',
      'cat': '猫',
      'other': '其他'
    };
    return petTypes.map(type => mapping[type] || type).join('、');
  };

  const getPriceDisplay = (price: string, type: string): string => {
    const unit = getPriceUnit(type);
    return `¥${price}${unit.replace('¥', '')}`;
  };

  const filteredServices = getFilteredServices();

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                onKeyPress={handleSearchKeyPress}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img src="https://s.coze.cn/image/TVipG03otgQ/" 
                 alt="用户头像" className="w-8 h-8 rounded-full" />
            <span className="text-text-primary font-medium hidden md:block">李阿姨</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link to="/provider-dashboard" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link to="/qualification-audit" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-certificate text-lg"></i>
              <span className="font-medium">资质审核</span>
            </Link>
            <Link to="/service-publish" className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-plus-circle text-lg"></i>
              <span className="font-medium">服务发布</span>
            </Link>
            <Link to="/order-hall" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-inbox text-lg"></i>
              <span className="font-medium">接单大厅</span>
            </Link>
            <Link to="/provider-order-manage" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-list-alt text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <Link to="/withdrawal" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-money-bill-wave text-lg"></i>
              <span className="font-medium">收入提现</span>
            </Link>
            <Link to="/growth-system" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-trophy text-lg"></i>
              <span className="font-medium">成长体系</span>
            </Link>
            <Link to="/user-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">服务发布</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">服务发布</h1>
                <p className="text-text-secondary mt-1">发布和管理您的托管服务</p>
              </div>
              <button 
                onClick={handleAddService}
                className={`${styles.btnPrimary} px-6 py-3 rounded-xl font-medium hover:shadow-lg transition-all`}
              >
                <i className="fas fa-plus mr-2"></i>
                新增服务
              </button>
            </div>
          </header>

          {/* 已发布服务列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">我的服务</h2>
              <div className="flex items-center space-x-2">
                <select 
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className={`${styles.formInput} px-3 py-1 rounded-lg text-sm`}
                >
                  <option value="">全部状态</option>
                  <option value="online">上架中</option>
                  <option value="offline">已下架</option>
                </select>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className={`w-full ${styles.tableGlass} rounded-xl overflow-hidden`}>
                <thead className="bg-white/10">
                  <tr>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务名称</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务类型</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">价格</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">可托管宠物</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">状态</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredServices.map((service) => (
                    <tr key={service.id} className={`${styles.tableRow} border-b border-white/10`}>
                      <td className="px-4 py-3 text-text-primary font-medium">{service.name}</td>
                      <td className="px-4 py-3 text-text-secondary">{getServiceTypeDisplay(service.type)}</td>
                      <td className="px-4 py-3 text-accent font-medium">{getPriceDisplay(service.price, service.type)}</td>
                      <td className="px-4 py-3 text-text-secondary">{getPetTypesDisplay(service.petTypes)}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          service.status === 'online' 
                            ? 'bg-green-500/20 text-green-600' 
                            : 'bg-yellow-500/20 text-yellow-600'
                        }`}>
                          {service.status === 'online' ? '上架中' : '已下架'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => handleEditService(service.id)}
                            className="text-secondary hover:text-accent text-sm font-medium"
                          >
                            编辑
                          </button>
                          <button 
                            onClick={() => handleToggleService(service.id)}
                            className="text-text-muted hover:text-accent text-sm font-medium"
                          >
                            {service.status === 'online' ? '下架' : '上架'}
                          </button>
                          <button 
                            onClick={() => handleDeleteService(service.id)}
                            className="text-red-500 hover:text-red-600 text-sm font-medium"
                          >
                            删除
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </main>
      </div>

      {/* 新增/编辑服务模态弹窗 */}
      {showServiceModal && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalOverlay} onClick={handleCloseModal}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl`}>
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-accent">
                    {currentEditingServiceId ? '编辑服务' : '新增服务'}
                  </h2>
                  <button 
                    onClick={handleCloseModal}
                    className="text-text-muted hover:text-accent text-xl transition-colors"
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </div>
                
                <form onSubmit={handleFormSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* 基本信息 */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-accent border-b border-white/20 pb-2">基本信息</h3>
                      
                      <div className="space-y-2">
                        <label htmlFor="service-name" className="block text-sm font-medium text-text-primary">服务名称 *</label>
                        <input 
                          type="text" 
                          id="service-name"
                          value={formData.serviceName}
                          onChange={(e) => setFormData(prev => ({ ...prev, serviceName: e.target.value }))}
                          className={`${styles.formInput} w-full px-4 py-2 rounded-lg text-text-primary placeholder-text-muted`}
                          placeholder="请输入服务名称" 
                          required 
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="service-type" className="block text-sm font-medium text-text-primary">服务类型 *</label>
                        <select 
                          id="service-type"
                          value={formData.serviceType}
                          onChange={(e) => handleServiceTypeChange(e.target.value)}
                          className={`${styles.formInput} w-full px-4 py-2 rounded-lg text-text-primary`}
                          required
                        >
                          <option value="">请选择服务类型</option>
                          <option value="daycare">日托服务</option>
                          <option value="weekcare">周托服务</option>
                          <option value="walking">小时陪遛</option>
                        </select>
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="service-price" className="block text-sm font-medium text-text-primary">服务价格 *</label>
                        <div className="relative">
                          <input 
                            type="number" 
                            id="service-price"
                            value={formData.servicePrice}
                            onChange={(e) => setFormData(prev => ({ ...prev, servicePrice: e.target.value }))}
                            className={`${styles.formInput} w-full px-4 py-2 pr-12 rounded-lg text-text-primary placeholder-text-muted`}
                            placeholder="请输入价格" 
                            min="0" 
                            step="0.01" 
                            required 
                          />
                          <span className="absolute right-4 top-1/2 transform -translate-y-1/2 text-text-muted">
                            {getPriceUnit(formData.serviceType)}
                          </span>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="max-pets" className="block text-sm font-medium text-text-primary">最大托管数量</label>
                        <input 
                          type="number" 
                          id="max-pets"
                          value={formData.maxPets}
                          onChange={(e) => setFormData(prev => ({ ...prev, maxPets: e.target.value }))}
                          className={`${styles.formInput} w-full px-4 py-2 rounded-lg text-text-primary placeholder-text-muted`}
                          placeholder="请输入最大托管数量" 
                          min="1" 
                        />
                      </div>
                    </div>
                    
                    {/* 宠物类型和地址 */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-accent border-b border-white/20 pb-2">服务详情</h3>
                      
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-text-primary">可托管宠物类型 *</label>
                        <div className="space-y-2">
                          <label className="flex items-center space-x-2">
                            <input 
                              type="checkbox" 
                              value="dog"
                              checked={formData.petTypes.includes('dog')}
                              onChange={(e) => handlePetTypeChange('dog', e.target.checked)}
                              className="w-4 h-4 text-secondary bg-white/20 border-white/30 rounded focus:ring-secondary" 
                            />
                            <span className="text-text-primary">小型犬</span>
                          </label>
                          <label className="flex items-center space-x-2">
                            <input 
                              type="checkbox" 
                              value="large-dog"
                              checked={formData.petTypes.includes('large-dog')}
                              onChange={(e) => handlePetTypeChange('large-dog', e.target.checked)}
                              className="w-4 h-4 text-secondary bg-white/20 border-white/30 rounded focus:ring-secondary" 
                            />
                            <span className="text-text-primary">中大型犬</span>
                          </label>
                          <label className="flex items-center space-x-2">
                            <input 
                              type="checkbox" 
                              value="cat"
                              checked={formData.petTypes.includes('cat')}
                              onChange={(e) => handlePetTypeChange('cat', e.target.checked)}
                              className="w-4 h-4 text-secondary bg-white/20 border-white/30 rounded focus:ring-secondary" 
                            />
                            <span className="text-text-primary">猫</span>
                          </label>
                          <label className="flex items-center space-x-2">
                            <input 
                              type="checkbox" 
                              value="other"
                              checked={formData.petTypes.includes('other')}
                              onChange={(e) => handlePetTypeChange('other', e.target.checked)}
                              className="w-4 h-4 text-secondary bg-white/20 border-white/30 rounded focus:ring-secondary" 
                            />
                            <span className="text-text-primary">其他宠物</span>
                          </label>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="service-address" className="block text-sm font-medium text-text-primary">服务地址 *</label>
                        <input 
                          type="text" 
                          id="service-address"
                          value={formData.serviceAddress}
                          onChange={(e) => setFormData(prev => ({ ...prev, serviceAddress: e.target.value }))}
                          className={`${styles.formInput} w-full px-4 py-2 rounded-lg text-text-primary placeholder-text-muted`}
                          placeholder="请输入详细地址" 
                          required 
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="service-description" className="block text-sm font-medium text-text-primary">服务描述</label>
                        <textarea 
                          id="service-description"
                          value={formData.serviceDescription}
                          onChange={(e) => setFormData(prev => ({ ...prev, serviceDescription: e.target.value }))}
                          rows={3}
                          className={`${styles.formInput} w-full px-4 py-2 rounded-lg text-text-primary placeholder-text-muted resize-none`}
                          placeholder="请简要描述您的服务特色"
                        ></textarea>
                      </div>
                    </div>
                  </div>
                  
                  {/* 环境照片上传 */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-accent border-b border-white/20 pb-2">环境照片</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[0, 1, 2].map((index) => (
                        <div key={index} className="relative">
                          {uploadedPhotos[index] ? (
                            <div className="aspect-video rounded-xl relative">
                              <img src={uploadedPhotos[index]} alt="预览图" className="w-full h-full object-cover rounded-xl" />
                              <button 
                                type="button"
                                onClick={() => handlePhotoRemove(index)}
                                className="absolute top-2 right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs"
                              >
                                <i className="fas fa-times"></i>
                              </button>
                            </div>
                          ) : (
                            <div 
                              className={`${styles.uploadArea} aspect-video rounded-xl flex flex-col items-center justify-center cursor-pointer`}
                              onClick={() => document.getElementById(`photo-${index}`)?.click()}
                            >
                              <i className="fas fa-camera text-3xl text-text-muted mb-2"></i>
                              <span className="text-text-muted text-sm">点击上传照片</span>
                              <input 
                                type="file" 
                                id={`photo-${index}`}
                                accept="image/*" 
                                className="hidden"
                                onChange={(e) => e.target.files?.[0] && handlePhotoUpload(index, e.target.files[0])}
                              />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                    <p className="text-text-muted text-sm">最多上传3张照片，每张不超过5MB</p>
                  </div>
                  
                  {/* AI生成注意事项 */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-accent border-b border-white/20 pb-2">托管注意事项</h3>
                    <div className="space-y-2">
                      <label htmlFor="service-notes" className="block text-sm font-medium text-text-primary">
                        AI智能生成（可编辑）
                        <button 
                          type="button" 
                          onClick={handleGenerateNotes}
                          className="ml-2 text-secondary hover:text-accent text-sm"
                        >
                          <i className="fas fa-magic mr-1"></i>重新生成
                        </button>
                      </label>
                      <textarea 
                        id="service-notes"
                        value={formData.serviceNotes}
                        onChange={(e) => setFormData(prev => ({ ...prev, serviceNotes: e.target.value }))}
                        rows={4}
                        className={`${styles.formInput} w-full px-4 py-2 rounded-lg text-text-primary placeholder-text-muted resize-none`}
                        placeholder="AI将根据您的服务类型生成托管注意事项..."
                      ></textarea>
                    </div>
                  </div>
                  
                  {/* 表单操作按钮 */}
                  <div className="flex items-center justify-end space-x-4 pt-6 border-t border-white/20">
                    <button 
                      type="button" 
                      onClick={handleCloseModal}
                      className={`${styles.btnSecondary} px-6 py-3 rounded-xl font-medium`}
                    >
                      取消
                    </button>
                    <button 
                      type="submit"
                      className={`${styles.btnPrimary} px-6 py-3 rounded-xl font-medium`}
                    >
                      保存服务
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 删除确认模态弹窗 */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalOverlay} onClick={handleCancelDelete}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} w-full max-w-md rounded-2xl`}>
              <div className="p-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-trash text-red-500 text-2xl"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-accent mb-2">确认删除</h3>
                  <p className="text-text-secondary mb-6">删除后将无法恢复，确定要删除这个服务吗？</p>
                  <div className="flex space-x-3">
                    <button 
                      onClick={handleCancelDelete}
                      className={`${styles.btnSecondary} flex-1 py-3 rounded-xl font-medium`}
                    >
                      取消
                    </button>
                    <button 
                      onClick={handleConfirmDelete}
                      className={`${styles.btnDanger} flex-1 py-3 rounded-xl font-medium`}
                    >
                      确认删除
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI客服悬浮按钮 */}
      <button className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50">
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default ServicePublishPage;

