

import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

const ProviderDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [searchInputValue, setSearchInputValue] = useState('');

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 托管服务商工作台';
    return () => { document.title = originalTitle; };
  }, []);

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      console.log('搜索:', searchInputValue);
      // 这里可以实现搜索功能
    }
  };

  const handleNotificationClick = () => {
    console.log('查看通知');
    // 这里可以显示通知列表
  };

  const handleUserMenuClick = () => {
    console.log('打开用户菜单');
    // 这里可以显示用户菜单下拉
  };

  const handleAiCustomerServiceClick = () => {
    console.log('打开AI客服');
    // 这里可以打开AI客服弹窗
    alert('AI客服功能开发中...');
  };

  const handleOrderRowClick = (orderId: string) => {
    navigate(`/provider-order-manage?orderId=${orderId}`);
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索订单、宠物主人..." 
                value={searchInputValue}
                onChange={(e) => setSearchInputValue(e.target.value)}
                onKeyPress={handleSearchKeyPress}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            onClick={handleNotificationClick}
            className="relative p-2 text-text-secondary hover:text-accent transition-colors"
          >
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div 
            onClick={handleUserMenuClick}
            className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors"
          >
            <img 
              src="https://s.coze.cn/image/LDLeUp6OAUY/" 
              alt="李阿姨头像" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-text-primary font-medium hidden md:block">李阿姨</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link 
              to="/provider-dashboard" 
              className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}
            >
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link 
              to="/qualification-audit" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-certificate text-lg"></i>
              <span className="font-medium">资质审核</span>
            </Link>
            <Link 
              to="/service-publish" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-plus-circle text-lg"></i>
              <span className="font-medium">服务发布</span>
            </Link>
            <Link 
              to="/order-hall" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-bell text-lg"></i>
              <span className="font-medium">接单大厅</span>
            </Link>
            <Link 
              to="/provider-order-manage" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-list-alt text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <Link 
              to="/withdrawal" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-money-bill-wave text-lg"></i>
              <span className="font-medium">收入提现</span>
            </Link>
            <Link 
              to="/growth-system" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-trophy text-lg"></i>
              <span className="font-medium">成长体系</span>
            </Link>
            <Link 
              to="/user-profile" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">工作台</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">欢迎回来，李阿姨！</h1>
                <p className="text-text-secondary mt-1">今天是美好的一天，让我们看看您的托管业务情况</p>
              </div>
              <div className="hidden lg:flex items-center space-x-2 text-text-secondary">
                <i className="fas fa-sun text-secondary"></i>
                <span>晴天 22°C</span>
              </div>
            </div>
          </header>

          {/* 数据概览区 */}
          <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">待处理订单</p>
                  <p className="text-3xl font-bold text-accent mt-2">5</p>
                  <p className="text-secondary text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +2 较昨日
                  </p>
                </div>
                <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-clock text-secondary text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">进行中订单</p>
                  <p className="text-3xl font-bold text-accent mt-2">8</p>
                  <p className="text-blue-600 text-sm mt-1">
                    <i className="fas fa-running"></i> 服务中
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-play-circle text-blue-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">可提现余额</p>
                  <p className="text-3xl font-bold text-accent mt-2">¥2,856</p>
                  <p className="text-green-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +¥420 今日收入
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-wallet text-green-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">综合评分</p>
                  <p className="text-3xl font-bold text-accent mt-2">4.8</p>
                  <p className="text-yellow-600 text-sm mt-1">
                    <i className="fas fa-star"></i> 金牌托管师
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-trophy text-yellow-500 text-xl"></i>
                </div>
              </div>
            </div>
          </section>

          {/* 快捷操作区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-4">快捷操作</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Link 
                to="/service-publish"
                className={`${styles.btnPrimary} p-4 rounded-xl text-left hover:shadow-lg transition-all block`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-plus text-white text-lg"></i>
                  </div>
                  <div>
                    <p className="font-medium text-white">发布服务</p>
                    <p className="text-white/80 text-sm">创建新的托管服务</p>
                  </div>
                </div>
              </Link>

              <Link 
                to="/order-hall"
                className={`${styles.btnSecondary} p-4 rounded-xl text-left hover:shadow-lg transition-all block`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-bell text-accent text-lg"></i>
                  </div>
                  <div>
                    <p className="font-medium text-accent">查看接单大厅</p>
                    <p className="text-text-muted text-sm">处理新的订单推送</p>
                  </div>
                </div>
              </Link>

              <Link 
                to="/provider-order-manage"
                className={`${styles.btnSecondary} p-4 rounded-xl text-left hover:shadow-lg transition-all block`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-list-alt text-accent text-lg"></i>
                  </div>
                  <div>
                    <p className="font-medium text-accent">管理订单</p>
                    <p className="text-text-muted text-sm">查看和处理所有订单</p>
                  </div>
                </div>
              </Link>
            </div>
          </section>

          {/* 最近订单列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">最近订单</h2>
              <Link 
                to="/provider-order-manage" 
                className="text-secondary hover:text-accent text-sm font-medium transition-colors"
              >
                查看全部 <i className="fas fa-arrow-right ml-1"></i>
              </Link>
            </div>
            
            <div className="overflow-x-auto">
              <table className={`w-full ${styles.tableGlass} rounded-xl overflow-hidden`}>
                <thead className="bg-white/10">
                  <tr>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">订单号</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务类型</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">宠物</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务时间</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">宠物主人</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">状态</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">操作</th>
                  </tr>
                </thead>
                <tbody>
                  <tr 
                    className={`${styles.tableRow} border-b border-white/10 cursor-pointer`}
                    onClick={() => handleOrderRowClick('#20240315001')}
                  >
                    <td className="px-4 py-3 text-text-primary font-medium">#20240315001</td>
                    <td className="px-4 py-3 text-text-secondary">日托服务</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <img 
                          src="https://s.coze.cn/image/msus50ccC6A/" 
                          alt="金毛犬" 
                          className="w-8 h-8 rounded-full"
                        />
                        <span className="text-text-primary">豆豆</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-text-secondary">3月18日 09:00-18:00</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <img 
                          src="https://s.coze.cn/image/04Bw3dHS2GY/" 
                          alt="张小明" 
                          className="w-8 h-8 rounded-full"
                        />
                        <span className="text-text-primary">张小明</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-1 bg-yellow-500/20 text-yellow-600 text-xs rounded-full">待接单</span>
                    </td>
                    <td className="px-4 py-3">
                      <button className="text-secondary hover:text-accent text-sm font-medium">查看</button>
                    </td>
                  </tr>
                  <tr 
                    className={`${styles.tableRow} border-b border-white/10 cursor-pointer`}
                    onClick={() => handleOrderRowClick('#20240314002')}
                  >
                    <td className="px-4 py-3 text-text-primary font-medium">#20240314002</td>
                    <td className="px-4 py-3 text-text-secondary">周托服务</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <img 
                          src="https://s.coze.cn/image/YoJunQORRgs/" 
                          alt="布偶猫" 
                          className="w-8 h-8 rounded-full"
                        />
                        <span className="text-text-primary">咪咪</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-text-secondary">3月20日-27日</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <img 
                          src="https://s.coze.cn/image/mCa9QB52Yss/" 
                          alt="王小姐" 
                          className="w-8 h-8 rounded-full"
                        />
                        <span className="text-text-primary">王小姐</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-1 bg-blue-500/20 text-blue-600 text-xs rounded-full">服务中</span>
                    </td>
                    <td className="px-4 py-3">
                      <button className="text-secondary hover:text-accent text-sm font-medium">填写日报</button>
                    </td>
                  </tr>
                  <tr 
                    className={`${styles.tableRow} cursor-pointer`}
                    onClick={() => handleOrderRowClick('#20240312001')}
                  >
                    <td className="px-4 py-3 text-text-primary font-medium">#20240312001</td>
                    <td className="px-4 py-3 text-text-secondary">小时陪遛</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <img 
                          src="https://s.coze.cn/image/8o7JdbAFZoU/" 
                          alt="金毛犬" 
                          className="w-8 h-8 rounded-full"
                        />
                        <span className="text-text-primary">豆豆</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-text-secondary">3月12日 15:00-17:00</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <img 
                          src="https://s.coze.cn/image/7QYWmgfW3hI/" 
                          alt="张小明" 
                          className="w-8 h-8 rounded-full"
                        />
                        <span className="text-text-primary">张小明</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-1 bg-green-500/20 text-green-600 text-xs rounded-full">已完成</span>
                    </td>
                    <td className="px-4 py-3">
                      <button className="text-secondary hover:text-accent text-sm font-medium">查看</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* 成长体系概览 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">成长体系概览</h2>
              <Link 
                to="/growth-system" 
                className="text-secondary hover:text-accent text-sm font-medium transition-colors"
              >
                查看详情 <i className="fas fa-arrow-right ml-1"></i>
              </Link>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* 当前等级和徽章 */}
              <div className="lg:col-span-1">
                <div className="text-center">
                  <div className={`w-24 h-24 mx-auto mb-4 ${styles.badgeGold} rounded-full flex items-center justify-center`}>
                    <i className="fas fa-crown text-3xl"></i>
                  </div>
                  <h3 className="text-xl font-bold text-accent mb-2">金牌托管师</h3>
                  <p className="text-text-secondary text-sm">连续30天无违规，服务质量优秀</p>
                </div>
              </div>

              {/* 成长进度 */}
              <div className="lg:col-span-2">
                <h3 className="font-medium text-accent mb-4">距离下一等级还需：</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-text-secondary">好评率 (当前 98%)</span>
                      <span className="text-text-muted">还需 2%</span>
                    </div>
                    <div className="w-full bg-white/20 rounded-full h-2">
                      <div className={`${styles.progressBar} w-48/50`}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-text-secondary">接单量 (当前 156单)</span>
                      <span className="text-text-muted">还需 44单</span>
                    </div>
                    <div className="w-full bg-white/20 rounded-full h-2">
                      <div className={`${styles.progressBar} w-39/50`}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-text-secondary">响应速度 (当前 95%)</span>
                      <span className="text-text-muted">还需 5%</span>
                    </div>
                    <div className="w-full bg-white/20 rounded-full h-2">
                      <div className={`${styles.progressBar} w-47/50`}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 提升建议 */}
            <div className="mt-6 p-4 bg-gradient-to-r from-secondary/10 to-accent/10 rounded-xl border border-secondary/20">
              <h4 className="font-medium text-accent mb-3 flex items-center">
                <i className="fas fa-lightbulb text-secondary mr-2"></i>
                个性化提升建议
              </h4>
              <ul className="space-y-2 text-text-secondary text-sm">
                <li className="flex items-start space-x-2">
                  <i className="fas fa-check text-green-500 text-xs mt-1"></i>
                  <span>继续保持高质量服务，您的好评率非常优秀</span>
                </li>
                <li className="flex items-start space-x-2">
                  <i className="fas fa-check text-green-500 text-xs mt-1"></i>
                  <span>建议增加接单量，距离钻石托管师只差44单</span>
                </li>
                <li className="flex items-start space-x-2">
                  <i className="fas fa-check text-green-500 text-xs mt-1"></i>
                  <span>响应速度可以进一步提升，建议设置接单提醒</span>
                </li>
              </ul>
            </div>
          </section>
        </main>
      </div>

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiCustomerServiceClick}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default ProviderDashboard;

