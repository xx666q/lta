

import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface ServiceDetails {
  name: string;
  provider: string;
  providerAvatar: string;
  rating: string;
  type: string;
  price: string;
}

interface PetOption {
  id: string;
  name: string;
  type: string;
  age: number;
  avatar: string;
}

interface PaymentMethod {
  id: string;
  name: string;
  icon: string;
  bgColor: string;
}

const BookingConfirmPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  const [selectedPetId, setSelectedPetId] = useState<string>('pet1');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('wechat');
  const [specialRequests, setSpecialRequests] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showSuccessModal, setShowSuccessModal] = useState<boolean>(false);
  const [serviceDetails, setServiceDetails] = useState<ServiceDetails>({
    name: '李阿姨的日托服务',
    provider: '李阿姨',
    providerAvatar: 'https://s.coze.cn/image/Wt0jgS_Fxqg/',
    rating: '4.9',
    type: '日托服务',
    price: '120.00'
  });
  const [serviceTime, setServiceTime] = useState<string>('2024年3月18日 09:00-18:00');

  const petOptions: PetOption[] = [
    {
      id: 'pet1',
      name: '豆豆',
      type: '金毛犬',
      age: 7,
      avatar: 'https://s.coze.cn/image/G5awruC0-rU/'
    },
    {
      id: 'pet2',
      name: '咪咪',
      type: '布偶猫',
      age: 3,
      avatar: 'https://s.coze.cn/image/3bHX5Fp-2mc/'
    }
  ];

  const paymentMethods: PaymentMethod[] = [
    {
      id: 'wechat',
      name: '微信支付',
      icon: 'fab fa-weixin',
      bgColor: 'bg-green-500'
    },
    {
      id: 'alipay',
      name: '支付宝',
      icon: 'fab fa-alipay',
      bgColor: 'bg-blue-500'
    }
  ];

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 预约确认';
    return () => {
      document.title = originalTitle;
    };
  }, []);

  // 解析URL参数并更新页面内容
  useEffect(() => {
    const serviceId = searchParams.get('serviceId');
    const startTime = searchParams.get('startTime');
    const endTime = searchParams.get('endTime');

    if (serviceId) {
      loadServiceDetails(serviceId);
    }
    if (startTime && endTime) {
      updateServiceTime(startTime, endTime);
    }
  }, [searchParams]);

  // 模拟加载服务详情
  const loadServiceDetails = (serviceId: string) => {
    const mockServices: Record<string, ServiceDetails> = {
      'service1': {
        name: '李阿姨的日托服务',
        provider: '李阿姨',
        providerAvatar: 'https://s.coze.cn/image/dZ6735PIJYM/',
        rating: '4.9',
        type: '日托服务',
        price: '120.00'
      },
      'service2': {
        name: '王小姐的周托服务',
        provider: '王小姐',
        providerAvatar: 'https://s.coze.cn/image/FKaSCjuMNlE/',
        rating: '4.8',
        type: '周托服务',
        price: '600.00'
      }
    };

    const service = mockServices[serviceId] || mockServices['service1'];
    setServiceDetails(service);
  };

  // 更新服务时间
  const updateServiceTime = (startTime: string, endTime: string) => {
    setServiceTime(`${startTime} - ${endTime}`);
  };

  // 计算定金金额
  const calculateDeposit = (price: string): string => {
    return (parseFloat(price) * 0.5).toFixed(2);
  };

  // 检查表单有效性
  const isFormValid = (): boolean => {
    return selectedPetId !== '' && selectedPaymentMethod !== '';
  };

  // 处理宠物选择
  const handlePetSelection = (petId: string) => {
    setSelectedPetId(petId);
  };

  // 处理支付方式选择
  const handlePaymentMethodSelection = (paymentId: string) => {
    setSelectedPaymentMethod(paymentId);
  };

  // 处理特殊需求输入
  const handleSpecialRequestsChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setSpecialRequests(e.target.value);
  };

  // 处理订单提交
  const handleSubmitOrder = async () => {
    if (!isFormValid() || isSubmitting) return;

    setIsSubmitting(true);

    // 模拟支付处理
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setShowSuccessModal(true);
    } catch (error) {
      console.error('支付处理失败:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // 处理取消订单
  const handleCancelOrder = () => {
    navigate('/service-detail');
  };

  // 处理关闭弹窗
  const handleCloseModal = () => {
    navigate('/service-detail');
  };

  // 处理遮罩层点击
  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      navigate('/service-detail');
    }
  };

  // 处理查看托管日历
  const handleViewCalendar = () => {
    navigate('/owner-calendar');
  };

  // 处理ESC键
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        navigate('/service-detail');
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate]);

  const depositAmount = calculateDeposit(serviceDetails.price);

  return (
    <div className={styles.pageWrapper}>
      {/* 模态弹窗遮罩层 */}
      <div 
        className={`${styles.modalOverlay} fixed inset-0 z-50 flex items-center justify-center p-4`}
        onClick={handleOverlayClick}
      >
        {/* 预约确认弹窗 */}
        <div className={`${styles.glassCard} ${styles.fadeIn} w-full max-w-2xl rounded-2xl p-6`}>
          {/* 弹窗头部 */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-accent">确认订单</h2>
            <button 
              onClick={handleCloseModal}
              className="text-text-muted hover:text-accent transition-colors"
            >
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>

          {/* 订单详情 */}
          <div className="space-y-6">
            {/* 服务信息 */}
            <div className="bg-white/10 rounded-xl p-4">
              <h3 className="font-semibold text-accent mb-3">服务信息</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-text-secondary">服务名称：</span>
                  <span className="text-text-primary font-medium">{serviceDetails.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">服务商：</span>
                  <div className="flex items-center space-x-2">
                    <img 
                      src={serviceDetails.providerAvatar}
                      alt={serviceDetails.provider}
                      className="w-6 h-6 rounded-full"
                    />
                    <span className="text-text-primary">{serviceDetails.provider}</span>
                    <div className="flex items-center space-x-1">
                      <i className="fas fa-star text-yellow-500 text-xs"></i>
                      <span className="text-text-primary text-sm">{serviceDetails.rating}</span>
                    </div>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">服务类型：</span>
                  <span className="text-text-primary">{serviceDetails.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">服务时段：</span>
                  <span className="text-text-primary">{serviceTime}</span>
                </div>
              </div>
            </div>

            {/* 宠物选择 */}
            <div className="space-y-3">
              <h3 className="font-semibold text-accent">选择宠物</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {petOptions.map((pet) => (
                  <div
                    key={pet.id}
                    className={`${styles.petOption} ${selectedPetId === pet.id ? styles.selected : ''} p-3 rounded-xl cursor-pointer`}
                    onClick={() => handlePetSelection(pet.id)}
                  >
                    <div className="flex items-center space-x-3">
                      <img 
                        src={pet.avatar}
                        alt={pet.name}
                        className="w-12 h-12 rounded-full"
                      />
                      <div>
                        <p className="font-medium text-accent">{pet.name}</p>
                        <p className="text-sm text-text-secondary">{pet.type} · {pet.age}岁</p>
                      </div>
                      <div className="ml-auto">
                        <i className={`fas fa-check text-secondary text-lg ${selectedPetId === pet.id ? '' : 'hidden'}`}></i>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 特殊需求 */}
            <div className="space-y-3">
              <label htmlFor="special-requests-input" className="block font-semibold text-accent">
                特殊需求
              </label>
              <textarea
                id="special-requests-input"
                className={`${styles.formInput} w-full px-4 py-3 rounded-xl text-text-primary placeholder-text-muted resize-none`}
                rows={4}
                placeholder="请描述您的宠物的特殊需求，例如：饮食习惯、医疗状况、行为特点等。我们会将这些信息传达给服务商。"
                value={specialRequests}
                onChange={handleSpecialRequestsChange}
              />
              <p className="text-sm text-text-muted">
                <i className="fas fa-info-circle mr-1"></i>
                详细的特殊需求有助于服务商更好地照顾您的宠物
              </p>
            </div>

            {/* 费用明细 */}
            <div className="bg-white/10 rounded-xl p-4">
              <h3 className="font-semibold text-accent mb-3">费用明细</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-text-secondary">服务费用：</span>
                  <span className="text-text-primary">¥{serviceDetails.price}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">定金（50%）：</span>
                  <span className="text-text-primary font-medium text-secondary">¥{depositAmount}</span>
                </div>
                <div className="border-t border-white/20 pt-2">
                  <div className="flex justify-between">
                    <span className="font-semibold text-accent">需支付定金：</span>
                    <span className="font-bold text-xl text-accent">¥{depositAmount}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 支付方式 */}
            <div className="space-y-3">
              <h3 className="font-semibold text-accent">支付方式</h3>
              <div className="space-y-2">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className={`${styles.paymentOption} ${selectedPaymentMethod === method.id ? styles.selected : ''} p-3 rounded-xl cursor-pointer`}
                    onClick={() => handlePaymentMethodSelection(method.id)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 ${method.bgColor} rounded-lg flex items-center justify-center`}>
                        <i className={`${method.icon} text-white text-lg`}></i>
                      </div>
                      <span className="font-medium text-accent">{method.name}</span>
                      <div className="ml-auto">
                        <i className={`fas fa-check text-secondary text-lg ${selectedPaymentMethod === method.id ? '' : 'hidden'}`}></i>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 操作按钮 */}
          <div className="flex space-x-4 mt-8 pt-6 border-t border-white/20">
            <button 
              onClick={handleCancelOrder}
              className={`${styles.btnSecondary} flex-1 py-3 px-4 rounded-xl font-medium`}
            >
              取消
            </button>
            <button 
              onClick={handleSubmitOrder}
              disabled={!isFormValid() || isSubmitting}
              className={`${styles.btnPrimary} flex-1 py-3 px-4 rounded-xl font-medium disabled:opacity-50`}
            >
              {isSubmitting ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  处理中...
                </>
              ) : (
                <>
                  <i className="fas fa-lock mr-2"></i>
                  提交订单并支付定金
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 支付成功提示弹窗 */}
      {showSuccessModal && (
        <div className={`${styles.modalOverlay} fixed inset-0 z-60 flex items-center justify-center p-4`}>
          <div className={`${styles.glassCard} w-full max-w-md rounded-2xl p-6 text-center`}>
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-check text-green-500 text-2xl"></i>
            </div>
            <h3 className="text-lg font-bold text-accent mb-2">支付成功！</h3>
            <p className="text-text-secondary mb-6">您的订单已提交，我们将尽快为您安排服务。</p>
            <button 
              onClick={handleViewCalendar}
              className={`${styles.btnPrimary} w-full py-3 px-4 rounded-xl font-medium`}
            >
              查看托管日历
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default BookingConfirmPage;

