

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';
import { Order, CalendarDay } from './types';

const OwnerCalendarPage: React.FC = () => {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState<number>(15);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [confirmTitle, setConfirmTitle] = useState<string>('确认操作');
  const [confirmMessage, setConfirmMessage] = useState<string>('您确定要执行此操作吗？');
  const [currentOrderId, setCurrentOrderId] = useState<string | null>(null);
  const [currentAction, setCurrentAction] = useState<string | null>(null);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 托管日历';
    return () => { document.title = originalTitle; };
  }, []);

  // 模拟订单数据
  const orders: Order[] = [
    {
      id: 'order1',
      orderNumber: '#20240315001',
      serviceType: '日托服务',
      pet: {
        name: '豆豆',
        avatar: 'https://s.coze.cn/image/Aivqb-4wP9s/'
      },
      serviceTime: '3月18日 09:00-18:00',
      provider: {
        name: '李阿姨',
        avatar: 'https://s.coze.cn/image/b5rYSCSegXg/'
      },
      status: 'pending'
    },
    {
      id: 'order2',
      orderNumber: '#20240314002',
      serviceType: '周托服务',
      pet: {
        name: '咪咪',
        avatar: 'https://s.coze.cn/image/ckO4zW2IwXo/'
      },
      serviceTime: '3月20日-27日',
      provider: {
        name: '王小姐',
        avatar: 'https://s.coze.cn/image/mwFAYZ86oRU/'
      },
      status: 'accepted'
    },
    {
      id: 'order3',
      orderNumber: '#20240313001',
      serviceType: '小时陪遛',
      pet: {
        name: '豆豆',
        avatar: 'https://s.coze.cn/image/-s84EJCDPx4/'
      },
      serviceTime: '3月13日 15:00-17:00',
      provider: {
        name: '张先生',
        avatar: 'https://s.coze.cn/image/oPwYck9luyg/'
      },
      status: 'active'
    },
    {
      id: 'order4',
      orderNumber: '#20240312001',
      serviceType: '日托服务',
      pet: {
        name: '豆豆',
        avatar: 'https://s.coze.cn/image/7YZ8qfe5pK8/'
      },
      serviceTime: '3月12日 09:00-18:00',
      provider: {
        name: '李阿姨',
        avatar: 'https://s.coze.cn/image/AhlT5dWdNYc/'
      },
      status: 'completed'
    },
    {
      id: 'order5',
      orderNumber: '#20240310001',
      serviceType: '周托服务',
      pet: {
        name: '咪咪',
        avatar: 'https://s.coze.cn/image/NFbuDetux-Q/'
      },
      serviceTime: '3月1日-7日',
      provider: {
        name: '王小姐',
        avatar: 'https://s.coze.cn/image/TOqrpnxDhVQ/'
      },
      status: 'cancelled'
    }
  ];

  // 日历数据
  const calendarDays: CalendarDay[] = [
    { day: 25, hasOrders: false, isCurrentMonth: false },
    { day: 26, hasOrders: false, isCurrentMonth: false },
    { day: 27, hasOrders: false, isCurrentMonth: false },
    { day: 28, hasOrders: false, isCurrentMonth: false },
    { day: 29, hasOrders: false, isCurrentMonth: false },
    { day: 1, hasOrders: false, isCurrentMonth: true },
    { day: 2, hasOrders: false, isCurrentMonth: true },
    { day: 3, hasOrders: false, isCurrentMonth: true },
    { day: 4, hasOrders: false, isCurrentMonth: true },
    { day: 5, hasOrders: false, isCurrentMonth: true },
    { day: 6, hasOrders: false, isCurrentMonth: true },
    { day: 7, hasOrders: false, isCurrentMonth: true },
    { day: 8, hasOrders: false, isCurrentMonth: true },
    { day: 9, hasOrders: false, isCurrentMonth: true },
    { day: 10, hasOrders: false, isCurrentMonth: true },
    { day: 11, hasOrders: false, isCurrentMonth: true },
    { day: 12, hasOrders: false, isCurrentMonth: true },
    { day: 13, hasOrders: true, isCurrentMonth: true },
    { day: 14, hasOrders: false, isCurrentMonth: true },
    { day: 15, hasOrders: true, isCurrentMonth: true },
    { day: 16, hasOrders: false, isCurrentMonth: true },
    { day: 17, hasOrders: false, isCurrentMonth: true },
    { day: 18, hasOrders: true, isCurrentMonth: true },
    { day: 19, hasOrders: false, isCurrentMonth: true },
    { day: 20, hasOrders: true, isCurrentMonth: true },
    { day: 21, hasOrders: false, isCurrentMonth: true },
    { day: 22, hasOrders: false, isCurrentMonth: true },
    { day: 23, hasOrders: false, isCurrentMonth: true },
    { day: 24, hasOrders: false, isCurrentMonth: true },
    { day: 25, hasOrders: false, isCurrentMonth: true },
    { day: 26, hasOrders: false, isCurrentMonth: true },
    { day: 27, hasOrders: false, isCurrentMonth: true },
    { day: 28, hasOrders: false, isCurrentMonth: true },
    { day: 29, hasOrders: false, isCurrentMonth: true },
    { day: 30, hasOrders: false, isCurrentMonth: true },
    { day: 31, hasOrders: false, isCurrentMonth: true },
    { day: 1, hasOrders: false, isCurrentMonth: false },
    { day: 2, hasOrders: false, isCurrentMonth: false },
    { day: 3, hasOrders: false, isCurrentMonth: false },
    { day: 4, hasOrders: false, isCurrentMonth: false },
    { day: 5, hasOrders: false, isCurrentMonth: false }
  ];

  // 筛选数据
  const filterData = [
    { id: 'all', label: '全部', count: 12 },
    { id: 'pending', label: '待接单', count: 3 },
    { id: 'accepted', label: '已接单', count: 2 },
    { id: 'active', label: '服务中', count: 1 },
    { id: 'completed', label: '已完成', count: 5 },
    { id: 'cancelled', label: '已取消', count: 1 }
  ];

  // 处理日历日期点击
  const handleDateClick = (day: number) => {
    setSelectedDate(day);
  };

  // 处理筛选点击
  const handleFilterClick = (filterId: string) => {
    setActiveFilter(filterId);
  };

  // 处理订单操作
  const handleOrderAction = (orderId: string, action: string) => {
    setCurrentOrderId(orderId);
    setCurrentAction(action);

    switch (action) {
      case 'cancel':
        setConfirmTitle('取消订单');
        setConfirmMessage('取消订单可能需要支付一定的手续费，确定要取消吗？');
        break;
      case 'reschedule':
        setConfirmTitle('改期订单');
        setConfirmMessage('改期可能需要与服务商协商，确定要申请改期吗？');
        break;
      case 'refund':
        setConfirmTitle('申请退款');
        setConfirmMessage('退款将根据服务条款处理，确定要申请退款吗？');
        break;
      case 'tip':
        setConfirmTitle('追加小费');
        setConfirmMessage('感谢您的慷慨！确定要追加小费吗？');
        break;
      case 'cloud-view':
        navigate('/cloud-view');
        return;
      case 'rate':
        alert(`打开评价弹窗，订单ID: ${orderId}`);
        return;
      case 'view':
        console.log('查看订单详情:', orderId);
        return;
      default:
        return;
    }

    setShowConfirmModal(true);
  };

  // 处理确认操作
  const handleConfirmOk = () => {
    console.log('执行操作:', currentAction, '订单ID:', currentOrderId);
    alert('操作已提交，请等待处理结果');
    setShowConfirmModal(false);
    setCurrentOrderId(null);
    setCurrentAction(null);
  };

  // 处理取消操作
  const handleConfirmCancel = () => {
    setShowConfirmModal(false);
    setCurrentOrderId(null);
    setCurrentAction(null);
  };

  // 处理弹窗外部点击
  const handleModalOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleConfirmCancel();
    }
  };

  // 获取状态徽章样式
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'pending':
        return styles.statusBadgePending;
      case 'accepted':
        return styles.statusBadgeAccepted;
      case 'active':
        return styles.statusBadgeActive;
      case 'completed':
        return styles.statusBadgeCompleted;
      case 'cancelled':
        return styles.statusBadgeCancelled;
      case 'refunding':
        return styles.statusBadgeRefunding;
      default:
        return '';
    }
  };

  // 获取状态文本
  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return '待接单';
      case 'accepted':
        return '已接单';
      case 'active':
        return '服务中';
      case 'completed':
        return '已完成';
      case 'cancelled':
        return '已取消';
      case 'refunding':
        return '退款中';
      default:
        return '';
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
                onKeyPress={(e) => e.key === 'Enter' && console.log('搜索:', e.currentTarget.value)}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img 
              src="https://s.coze.cn/image/UJQUiFxAcB4/" 
              alt="用户头像" 
              className="w-8 h-8 rounded-full" 
            />
            <span className="text-text-primary font-medium hidden md:block">张小明</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link to="/owner-dashboard" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link to="/pet-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-paw text-lg"></i>
              <span className="font-medium">我的宠物</span>
            </Link>
            <Link to="/service-discovery" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-search text-lg"></i>
              <span className="font-medium">寻找服务</span>
            </Link>
            <Link to="/owner-calendar" className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-calendar-alt text-lg"></i>
              <span className="font-medium">托管日历</span>
            </Link>
            <Link to="/cloud-view" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-video text-lg"></i>
              <span className="font-medium">云看宠</span>
            </Link>
            <Link to="/user-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">托管日历</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">托管日历</h1>
                <p className="text-text-secondary mt-1">管理您的所有托管订单</p>
              </div>
              <Link to="/service-discovery" className={`${styles.btnPrimary} px-6 py-2 rounded-lg text-sm font-medium hover:shadow-lg transition-all`}>
                <i className="fas fa-plus mr-2"></i>
                预约新服务
              </Link>
            </div>
          </header>

          {/* 日历和筛选区域 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* 日历视图 */}
            <div className={`${styles.glassCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-accent">2024年3月</h2>
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-text-secondary hover:text-accent transition-colors" onClick={() => console.log('切换到上个月')}>
                    <i className="fas fa-chevron-left"></i>
                  </button>
                  <button className="p-2 text-text-secondary hover:text-accent transition-colors" onClick={() => console.log('切换到下个月')}>
                    <i className="fas fa-chevron-right"></i>
                  </button>
                </div>
              </div>
              
              {/* 日历网格 */}
              <div className="grid grid-cols-7 gap-1">
                {/* 星期标题 */}
                {['日', '一', '二', '三', '四', '五', '六'].map((day) => (
                  <div key={day} className="text-center text-text-muted text-sm font-medium py-2">{day}</div>
                ))}
                
                {/* 日期 */}
                {calendarDays.map((calendarDay, index) => (
                  <div
                    key={index}
                    className={`${styles.calendarDay} ${
                      calendarDay.hasOrders ? styles.calendarDayHasOrders : ''
                    } ${
                      selectedDate === calendarDay.day && calendarDay.isCurrentMonth ? styles.calendarDaySelected : ''
                    } text-center py-3 rounded-lg ${
                      calendarDay.isCurrentMonth ? '' : 'text-text-muted'
                    }`}
                    onClick={() => calendarDay.isCurrentMonth && handleDateClick(calendarDay.day)}
                  >
                    {calendarDay.day}
                  </div>
                ))}
              </div>
              
              {/* 图例 */}
              <div className="mt-4 space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <div className="w-3 h-3 bg-secondary/20 border-2 border-secondary rounded"></div>
                  <span className="text-text-secondary">有订单</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <div className="w-3 h-3 bg-accent/30 border-2 border-accent rounded"></div>
                  <span className="text-text-secondary">已选择</span>
                </div>
              </div>
            </div>

            {/* 筛选和统计 */}
            <div className="lg:col-span-2 space-y-6">
              {/* 订单状态筛选 */}
              <div className={`${styles.glassCard} p-6 rounded-2xl`}>
                <h3 className="text-lg font-semibold text-accent mb-4">订单筛选</h3>
                <div className="flex flex-wrap gap-2">
                  {filterData.map((filter) => (
                    <button
                      key={filter.id}
                      className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${
                        activeFilter === filter.id
                          ? styles.filterActive
                          : 'border-white/30 text-text-secondary hover:border-secondary/50'
                      }`}
                      onClick={() => handleFilterClick(filter.id)}
                    >
                      {filter.label} ({filter.count})
                    </button>
                  ))}
                </div>
              </div>

              {/* 订单统计 */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className={`${styles.glassCard} p-4 rounded-xl text-center`}>
                  <div className="text-2xl font-bold text-accent">12</div>
                  <div className="text-text-muted text-sm">总订单</div>
                </div>
                <div className={`${styles.glassCard} p-4 rounded-xl text-center`}>
                  <div className="text-2xl font-bold text-secondary">3</div>
                  <div className="text-text-muted text-sm">待处理</div>
                </div>
                <div className={`${styles.glassCard} p-4 rounded-xl text-center`}>
                  <div className="text-2xl font-bold text-green-600">5</div>
                  <div className="text-text-muted text-sm">已完成</div>
                </div>
              </div>
            </div>
          </div>

          {/* 订单列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">订单列表</h2>
              <div className="text-text-muted text-sm">
                <i className="fas fa-calendar mr-2"></i>
                显示 2024年3月{selectedDate}日 及之后的订单
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className={`w-full ${styles.tableGlass} rounded-xl overflow-hidden`}>
                <thead className="bg-white/10">
                  <tr>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">订单号</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务类型</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">宠物</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务时间</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务商</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">状态</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order, index) => (
                    <tr key={order.id} className={`${styles.tableRow} ${index < orders.length - 1 ? 'border-b border-white/10' : ''}`}>
                      <td className="px-4 py-3 text-text-primary font-medium">{order.orderNumber}</td>
                      <td className="px-4 py-3 text-text-secondary">{order.serviceType}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <img 
                            src={order.pet.avatar} 
                            alt={`${order.pet.name}头像`} 
                            className="w-8 h-8 rounded-full" 
                          />
                          <span className="text-text-primary">{order.pet.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-text-secondary">{order.serviceTime}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <img 
                            src={order.provider.avatar} 
                            alt={`${order.provider.name}头像`} 
                            className="w-8 h-8 rounded-full" 
                          />
                          <span className="text-text-primary">{order.provider.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`${getStatusBadgeClass(order.status)} px-2 py-1 text-xs rounded-full`}>
                          {getStatusText(order.status)}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex space-x-2">
                          {order.status === 'pending' && (
                            <>
                              <button 
                                className="text-danger hover:text-red-600 text-sm font-medium"
                                onClick={() => handleOrderAction(order.id, 'cancel')}
                              >
                                取消
                              </button>
                              <button 
                                className="text-secondary hover:text-accent text-sm font-medium"
                                onClick={() => handleOrderAction(order.id, 'reschedule')}
                              >
                                改期
                              </button>
                            </>
                          )}
                          {order.status === 'accepted' && (
                            <>
                              <button 
                                className="text-secondary hover:text-accent text-sm font-medium"
                                onClick={() => handleOrderAction(order.id, 'reschedule')}
                              >
                                改期
                              </button>
                              <button 
                                className="text-green-600 hover:text-green-700 text-sm font-medium"
                                onClick={() => handleOrderAction(order.id, 'tip')}
                              >
                                追加小费
                              </button>
                            </>
                          )}
                          {order.status === 'active' && (
                            <>
                              <button 
                                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                                onClick={() => handleOrderAction(order.id, 'cloud-view')}
                              >
                                云看宠
                              </button>
                              <button 
                                className="text-danger hover:text-red-600 text-sm font-medium"
                                onClick={() => handleOrderAction(order.id, 'refund')}
                              >
                                申请退款
                              </button>
                            </>
                          )}
                          {order.status === 'completed' && (
                            <>
                              <button 
                                className="text-secondary hover:text-accent text-sm font-medium"
                                onClick={() => handleOrderAction(order.id, 'rate')}
                              >
                                评价
                              </button>
                              <button 
                                className="text-green-600 hover:text-green-700 text-sm font-medium"
                                onClick={() => handleOrderAction(order.id, 'tip')}
                              >
                                追加小费
                              </button>
                            </>
                          )}
                          {order.status === 'cancelled' && (
                            <button 
                              className="text-text-muted text-sm font-medium"
                              onClick={() => handleOrderAction(order.id, 'view')}
                            >
                              查看
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </main>
      </div>

      {/* 确认对话框 */}
      {showConfirmModal && (
        <div 
          className={`${styles.modalOverlay} fixed inset-0 z-50 flex items-center justify-center`}
          onClick={handleModalOverlayClick}
        >
          <div className={`${styles.modalContent} w-full max-w-md mx-4 p-6 rounded-2xl`}>
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-exclamation-triangle text-red-500 text-2xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-accent mb-2">{confirmTitle}</h3>
              <p className="text-text-secondary mb-6">{confirmMessage}</p>
              <div className="flex space-x-3">
                <button 
                  className={`flex-1 ${styles.btnSecondary} py-2 rounded-lg text-sm font-medium`}
                  onClick={handleConfirmCancel}
                >
                  取消
                </button>
                <button 
                  className={`flex-1 ${styles.btnDanger} py-2 rounded-lg text-sm font-medium`}
                  onClick={handleConfirmOk}
                >
                  确认
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI客服悬浮按钮 */}
      <button 
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
        onClick={() => alert('AI客服功能开发中...')}
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default OwnerCalendarPage;

