

export interface Order {
  id: string;
  orderNumber: string;
  serviceType: string;
  pet: {
    name: string;
    avatar: string;
  };
  serviceTime: string;
  provider: {
    name: string;
    avatar: string;
  };
  status: 'pending' | 'accepted' | 'active' | 'completed' | 'cancelled' | 'refunding';
}

export interface CalendarDay {
  day: number;
  hasOrders: boolean;
  isCurrentMonth: boolean;
}

