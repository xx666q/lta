

import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface FormData {
  idCardFront: FileWithUrl | null;
  idCardBack: FileWithUrl | null;
  idCardSelfie: FileWithUrl | null;
  environmentPhotos: FileWithUrl[];
  businessLicense: FileWithUrl | null;
}

interface FileWithUrl {
  file: File;
  url: string;
}

const QualificationAuditPage: React.FC = () => {
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState<FormData>({
    idCardFront: null,
    idCardBack: null,
    idCardSelfie: null,
    environmentPhotos: [],
    businessLicense: null
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDraftSaved, setIsDraftSaved] = useState(false);
  const [progressPercentage, setProgressPercentage] = useState(30);

  const idCardFrontInputRef = useRef<HTMLInputElement>(null);
  const idCardBackInputRef = useRef<HTMLInputElement>(null);
  const idCardSelfieInputRef = useRef<HTMLInputElement>(null);
  const environmentPhotosInputRef = useRef<HTMLInputElement>(null);
  const businessLicenseInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 资质审核';
    return () => { document.title = originalTitle; };
  }, []);

  useEffect(() => {
    updateProgress();
  }, [formData]);

  const updateProgress = () => {
    let completed = 0;
    
    if (formData.idCardFront) completed++;
    if (formData.idCardBack) completed++;
    if (formData.idCardSelfie) completed++;
    if (formData.environmentPhotos.length >= 3) completed++;
    
    const progress = Math.round((completed / 4) * 100);
    setProgressPercentage(progress);
  };

  const isFormComplete = () => {
    return formData.idCardFront && 
           formData.idCardBack && 
           formData.idCardSelfie && 
           formData.environmentPhotos.length >= 3;
  };

  const handleFileUpload = (
    file: File, 
    field: keyof FormData, 
    multiple: boolean = false
  ) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const fileWithUrl: FileWithUrl = {
        file: file,
        url: e.target?.result as string
      };

      if (multiple && field === 'environmentPhotos') {
        setFormData(prev => ({
          ...prev,
          environmentPhotos: [...prev.environmentPhotos, fileWithUrl].slice(0, 6) // 限制最多6张
        }));
      } else {
        setFormData(prev => ({
          ...prev,
          [field]: fileWithUrl
        }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileRemove = (field: keyof FormData, index?: number) => {
    if (field === 'environmentPhotos' && typeof index === 'number') {
      setFormData(prev => ({
        ...prev,
        environmentPhotos: prev.environmentPhotos.filter((_, i) => i !== index)
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: null
      }));
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement>, 
    field: keyof FormData, 
    multiple: boolean = false
  ) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      if (multiple) {
        files.forEach(file => handleFileUpload(file, field, true));
      } else {
        handleFileUpload(files[0], field);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isFormComplete()) return;
    
    setIsSubmitting(true);
    
    // 模拟提交过程
    setTimeout(() => {
      alert('资质审核已提交，我们将在1-3个工作日内完成审核，请耐心等待！');
      navigate('/service-publish');
    }, 2000);
  };

  const handleSaveDraft = () => {
    setIsDraftSaved(true);
    setTimeout(() => {
      setIsDraftSaved(false);
    }, 2000);
  };

  const handleAiServiceClick = () => {
    alert('AI客服功能开发中...');
  };

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      console.log('搜索:', (e.target as HTMLInputElement).value);
    }
  };

  const renderFilePreview = (
    fileData: FileWithUrl | null, 
    field: keyof FormData, 
    altText: string,
    heightClass: string = 'h-48'
  ) => {
    if (!fileData) return null;

    return (
      <div>
        <img 
          src={fileData.url} 
          alt={altText} 
          className={`max-w-full ${heightClass} object-contain rounded-lg mx-auto`}
        />
        <button 
          type="button" 
          onClick={() => handleFileRemove(field)}
          className="mt-2 text-red-500 text-sm hover:underline"
        >
          移除
        </button>
      </div>
    );
  };

  const renderEnvironmentPhotos = () => {
    if (formData.environmentPhotos.length === 0) return null;

    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
        {formData.environmentPhotos.map((photo, index) => (
          <div key={index} className={styles.uploadedImage}>
            <img 
              src={photo.url} 
              alt={`环境照片 ${index + 1}`} 
              className="w-full h-32 object-cover rounded-lg"
            />
            <button 
              type="button" 
              className={styles.removeBtn}
              onClick={() => handleFileRemove('environmentPhotos', index)}
            >
              <i className="fas fa-times text-sm"></i>
            </button>
          </div>
        ))}
      </div>
    );
  };

  const renderUploadArea = (
    fileData: FileWithUrl | null,
    field: keyof FormData,
    icon: string,
    title: string,
    description: string,
    inputRef: React.RefObject<HTMLInputElement>,
    multiple: boolean = false,
    heightClass: string = 'h-48'
  ) => {
    const hasFiles = field === 'environmentPhotos' ? formData.environmentPhotos.length > 0 : fileData;

    return (
      <div className={`${styles.uploadArea} p-6 rounded-xl text-center cursor-pointer`}>
        <input 
          type="file" 
          ref={inputRef}
          accept="image/*" 
          multiple={multiple}
          onChange={(e) => handleInputChange(e, field, multiple)}
          className="hidden"
        />
        {!hasFiles ? (
          <div className="space-y-2">
            <i className={`${icon} text-3xl text-text-muted`}></i>
            <p className="text-text-secondary">{title}</p>
            <p className="text-xs text-text-muted">{description}</p>
          </div>
        ) : field === 'environmentPhotos' ? (
          renderEnvironmentPhotos()
        ) : (
          renderFilePreview(fileData, field, title, heightClass)
        )}
      </div>
    );
  };

  const getDocumentStatusIcon = (isCompleted: boolean) => {
    return isCompleted ? 'fas fa-check text-green-500' : 'fas fa-circle text-text-muted';
  };

  const getDocumentStatusTextClass = (isCompleted: boolean) => {
    return isCompleted ? 'text-text-primary' : 'text-text-secondary';
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                onKeyPress={handleSearchKeyPress}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img 
              src="https://s.coze.cn/image/6DUvqOHVN2M/" 
              alt="用户头像" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-text-primary font-medium hidden md:block">李阿姨</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link 
              to="/provider-dashboard" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link 
              to="/qualification-audit" 
              className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}
            >
              <i className="fas fa-certificate text-lg"></i>
              <span className="font-medium">资质审核</span>
            </Link>
            <Link 
              to="/service-publish" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-plus-circle text-lg"></i>
              <span className="font-medium">服务发布</span>
            </Link>
            <Link 
              to="/order-hall" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-bell text-lg"></i>
              <span className="font-medium">接单大厅</span>
            </Link>
            <Link 
              to="/provider-order-manage" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-list-alt text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <Link 
              to="/withdrawal" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-money-bill-wave text-lg"></i>
              <span className="font-medium">收入提现</span>
            </Link>
            <Link 
              to="/growth-system" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-star text-lg"></i>
              <span className="font-medium">成长体系</span>
            </Link>
            <Link 
              to="/user-profile" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">资质审核</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">资质审核</h1>
                <p className="text-text-secondary mt-1">提交您的托管服务资质，通过审核后即可开始提供托管服务</p>
              </div>
            </div>
          </header>

          {/* 审核状态显示 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center">
                <i className="fas fa-clock text-yellow-500 text-xl"></i>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-accent">审核状态</h2>
                <p className="text-text-secondary text-sm">您的资质正在审核中，预计1-3个工作日完成</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className={`inline-flex items-center px-4 py-2 ${styles.statusPending} rounded-full text-sm font-medium`}>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                待审核
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-text-secondary">审核进度</span>
                  <span className="text-accent font-medium">{progressPercentage}%</span>
                </div>
                <div className={`${styles.progressBar} h-2`}>
                  <div 
                    className={styles.progressFill}
                    style={{ width: `${progressPercentage}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-text-secondary">需要提交的材料：</p>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 text-sm">
                    <i className={getDocumentStatusIcon(!!formData.idCardFront)}></i>
                    <span className={getDocumentStatusTextClass(!!formData.idCardFront)}>身份证正面照片</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <i className={getDocumentStatusIcon(!!formData.idCardBack)}></i>
                    <span className={getDocumentStatusTextClass(!!formData.idCardBack)}>身份证反面照片</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <i className={getDocumentStatusIcon(!!formData.idCardSelfie)}></i>
                    <span className={getDocumentStatusTextClass(!!formData.idCardSelfie)}>手持身份证自拍</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <i className={getDocumentStatusIcon(formData.environmentPhotos.length >= 3)}></i>
                    <span className={getDocumentStatusTextClass(formData.environmentPhotos.length >= 3)}>托管环境照片 (3张)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <i className={getDocumentStatusIcon(!!formData.businessLicense)}></i>
                    <span className={getDocumentStatusTextClass(!!formData.businessLicense)}>营业执照 (可选)</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* 资质提交表单 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-6">提交资质材料</h2>
            
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* 身份证正面 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-accent">身份证正面照片 *</label>
                <div 
                  onClick={() => idCardFrontInputRef.current?.click()}
                  className="cursor-pointer"
                >
                  {renderUploadArea(
                    formData.idCardFront,
                    'idCardFront',
                    'fas fa-camera',
                    '点击上传身份证正面照片',
                    '支持 JPG、PNG 格式，文件大小不超过 5MB',
                    idCardFrontInputRef
                  )}
                </div>
              </div>

              {/* 身份证反面 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-accent">身份证反面照片 *</label>
                <div 
                  onClick={() => idCardBackInputRef.current?.click()}
                  className="cursor-pointer"
                >
                  {renderUploadArea(
                    formData.idCardBack,
                    'idCardBack',
                    'fas fa-camera',
                    '点击上传身份证反面照片',
                    '支持 JPG、PNG 格式，文件大小不超过 5MB',
                    idCardBackInputRef
                  )}
                </div>
              </div>

              {/* 手持身份证自拍 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-accent">手持身份证自拍 *</label>
                <div 
                  onClick={() => idCardSelfieInputRef.current?.click()}
                  className="cursor-pointer"
                >
                  {renderUploadArea(
                    formData.idCardSelfie,
                    'idCardSelfie',
                    'fas fa-camera',
                    '点击上传手持身份证自拍照片',
                    '确保面部清晰，身份证信息完整可见',
                    idCardSelfieInputRef,
                    false,
                    'h-64'
                  )}
                </div>
              </div>

              {/* 托管环境照片 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-accent">托管环境照片 * (至少3张)</label>
                <div 
                  onClick={() => environmentPhotosInputRef.current?.click()}
                  className="cursor-pointer"
                >
                  {renderUploadArea(
                    null,
                    'environmentPhotos',
                    'fas fa-images',
                    '点击上传托管环境照片',
                    '请展示托管场所的整体环境、活动空间等',
                    environmentPhotosInputRef,
                    true
                  )}
                </div>
              </div>

              {/* 营业执照 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-accent">
                  营业执照 <span className="text-text-muted">(可选)</span>
                </label>
                <div 
                  onClick={() => businessLicenseInputRef.current?.click()}
                  className="cursor-pointer"
                >
                  {renderUploadArea(
                    formData.businessLicense,
                    'businessLicense',
                    'fas fa-file-alt',
                    '点击上传营业执照照片',
                    '个体工商户或企业用户请提供',
                    businessLicenseInputRef,
                    false,
                    'h-64'
                  )}
                </div>
              </div>

              {/* 提交按钮 */}
              <div className="flex justify-end space-x-4 pt-6">
                <button 
                  type="button" 
                  onClick={handleSaveDraft}
                  className={`${styles.btnSecondary} px-6 py-3 rounded-lg font-medium`}
                >
                  {isDraftSaved ? (
                    <>
                      <i className="fas fa-check mr-2"></i>
                      已保存
                    </>
                  ) : (
                    '保存草稿'
                  )}
                </button>
                <button 
                  type="submit" 
                  disabled={!isFormComplete() || isSubmitting}
                  className={`${styles.btnPrimary} px-8 py-3 rounded-lg font-medium`}
                >
                  {isSubmitting ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      提交中...
                    </>
                  ) : (
                    '提交审核'
                  )}
                </button>
              </div>
            </form>
          </section>

          {/* 审核指南 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-4">审核指南</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="font-medium text-accent">材料要求</h3>
                <ul className="space-y-2 text-sm text-text-secondary">
                  <li className="flex items-start space-x-2">
                    <i className="fas fa-check text-green-500 mt-1 text-xs"></i>
                    <span>身份证照片清晰，信息完整可读</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="fas fa-check text-green-500 mt-1 text-xs"></i>
                    <span>手持身份证自拍需面部清晰</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="fas fa-check text-green-500 mt-1 text-xs"></i>
                    <span>环境照片需展示真实托管条件</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="fas fa-check text-green-500 mt-1 text-xs"></i>
                    <span>所有照片格式为JPG或PNG</span>
                  </li>
                </ul>
              </div>
              <div className="space-y-3">
                <h3 className="font-medium text-accent">审核流程</h3>
                <ul className="space-y-2 text-sm text-text-secondary">
                  <li className="flex items-start space-x-2">
                    <span className="w-6 h-6 bg-secondary text-white text-xs rounded-full flex items-center justify-center mt-0.5">1</span>
                    <span>提交材料后进入待审核状态</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="w-6 h-6 bg-secondary text-white text-xs rounded-full flex items-center justify-center mt-0.5">2</span>
                    <span>AI+人工双重审核（1-3个工作日）</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="w-6 h-6 bg-secondary text-white text-xs rounded-full flex items-center justify-center mt-0.5">3</span>
                    <span>审核通过后可发布托管服务</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="w-6 h-6 bg-secondary text-white text-xs rounded-full flex items-center justify-center mt-0.5">4</span>
                    <span>审核不通过可修改后重新提交</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiServiceClick}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default QualificationAuditPage;

