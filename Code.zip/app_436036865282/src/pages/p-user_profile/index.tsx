

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';

interface UserProfile {
  nickname: string;
  phone: string;
  address: string;
  avatar: string;
}

interface NotificationSettings {
  orderNotification: boolean;
  cloudViewNotification: boolean;
  ratingNotification: boolean;
  emailNotification: boolean;
}

const UserProfilePage: React.FC = () => {
  const [isEditProfileModalVisible, setIsEditProfileModalVisible] = useState(false);
  const [isChangePasswordModalVisible, setIsChangePasswordModalVisible] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    nickname: '张小明',
    phone: '138****8888',
    address: '北京市朝阳区三里屯街道',
    avatar: 'https://s.coze.cn/image/LcbOcbJ9n-c/'
  });
  const [editProfileForm, setEditProfileForm] = useState({
    nickname: userProfile.nickname,
    phone: '13812348888',
    address: userProfile.address
  });
  const [changePasswordForm, setChangePasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    orderNotification: true,
    cloudViewNotification: true,
    ratingNotification: true,
    emailNotification: false
  });
  const [searchInputValue, setSearchInputValue] = useState('');

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 个人中心';
    return () => { document.title = originalTitle; };
  }, []);

  const handleEditProfile = () => {
    setEditProfileForm({
      nickname: userProfile.nickname,
      phone: '13812348888',
      address: userProfile.address
    });
    setIsEditProfileModalVisible(true);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setUserProfile({
      ...userProfile,
      nickname: editProfileForm.nickname,
      address: editProfileForm.address
    });
    setIsEditProfileModalVisible(false);
    alert('个人信息修改成功！');
  };

  const handleChangePassword = () => {
    setIsChangePasswordModalVisible(true);
  };

  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault();
    const { currentPassword, newPassword, confirmPassword } = changePasswordForm;
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      alert('请填写完整的密码信息');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      alert('新密码和确认密码不一致');
      return;
    }
    
    if (newPassword.length < 6) {
      alert('新密码长度不能少于6位');
      return;
    }
    
    setIsChangePasswordModalVisible(false);
    setChangePasswordForm({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
    alert('密码修改成功！');
  };

  const handleAvatarUpload = () => {
    console.log('需要调用第三方接口实现头像上传功能');
    alert('头像上传功能开发中...');
  };

  const handleThirdPartyBind = (platform: string, action: string) => {
    if (platform === 'wechat' && action === 'bind') {
      alert('微信已绑定，如需解绑请联系客服');
    } else {
      console.log(`需要调用第三方接口实现${platform}绑定功能`);
      alert(`${platform === 'wechat' ? '微信' : platform === 'qq' ? 'QQ' : 'Apple ID'}绑定功能开发中...`);
    }
  };

  const handleNotificationToggle = (key: keyof NotificationSettings) => {
    setNotificationSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleAiCustomerService = () => {
    console.log('需要调用第三方接口实现AI客服功能');
    alert('AI客服功能开发中...');
  };

  const handleSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      console.log('搜索:', searchInputValue);
    }
  };

  const handleNotificationClick = () => {
    alert('您有3条新消息');
  };

  const handleUserMenuClick = () => {
    alert('用户菜单功能开发中...');
  };

  const closeModal = (modalSetter: React.Dispatch<React.SetStateAction<boolean>>) => {
    modalSetter(false);
  };

  const handleModalOverlayClick = (e: React.MouseEvent, modalSetter: React.Dispatch<React.SetStateAction<boolean>>) => {
    if (e.target === e.currentTarget) {
      modalSetter(false);
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                value={searchInputValue}
                onChange={(e) => setSearchInputValue(e.target.value)}
                onKeyPress={handleSearch}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            onClick={handleNotificationClick}
            className="relative p-2 text-text-secondary hover:text-accent transition-colors"
          >
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div 
            onClick={handleUserMenuClick}
            className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors"
          >
            <img 
              src="https://s.coze.cn/image/-NUHau0aUkI/" 
              alt="用户头像" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-text-primary font-medium hidden md:block">张小明</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link 
              to="/owner-dashboard" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link 
              to="/pet-profile" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-paw text-lg"></i>
              <span className="font-medium">我的宠物</span>
            </Link>
            <Link 
              to="/service-discovery" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-search text-lg"></i>
              <span className="font-medium">寻找服务</span>
            </Link>
            <Link 
              to="/owner-calendar" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-calendar-alt text-lg"></i>
              <span className="font-medium">托管日历</span>
            </Link>
            <Link 
              to="/cloud-view" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-video text-lg"></i>
              <span className="font-medium">云看宠</span>
            </Link>
            <Link 
              to="/user-profile" 
              className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}
            >
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">个人中心</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">个人中心</h1>
                <p className="text-text-secondary mt-1">管理您的个人信息和账户设置</p>
              </div>
            </div>
          </header>

          {/* 个人信息展示区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-accent">个人信息</h2>
              <button 
                onClick={handleEditProfile}
                className={`${styles.btnPrimary} px-4 py-2 rounded-lg text-sm font-medium hover:shadow-lg transition-all`}
              >
                <i className="fas fa-edit mr-2"></i>编辑资料
              </button>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* 头像和基本信息 */}
              <div className="space-y-6">
                <div className="flex flex-col items-center">
                  <div 
                    onClick={handleAvatarUpload}
                    className={`${styles.avatarUpload} relative w-24 h-24 rounded-full overflow-hidden`}
                  >
                    <img 
                      src={userProfile.avatar}
                      alt="用户头像" 
                      className="w-full h-full object-cover"
                    />
                    <div className={`${styles.avatarOverlay} text-center text-sm`}>
                      <i className="fas fa-camera mr-1"></i>更换头像
                    </div>
                  </div>
                  <p className="text-text-muted text-sm mt-2">点击头像更换</p>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-user text-secondary"></i>
                    </div>
                    <div>
                      <p className="text-text-muted text-sm">昵称</p>
                      <p className="text-text-primary font-medium">{userProfile.nickname}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-phone text-blue-500"></i>
                    </div>
                    <div>
                      <p className="text-text-muted text-sm">手机号</p>
                      <p className="text-text-primary font-medium">{userProfile.phone}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-map-marker-alt text-green-500"></i>
                    </div>
                    <div>
                      <p className="text-text-muted text-sm">地址</p>
                      <p className="text-text-primary font-medium">{userProfile.address}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* 账户统计信息 */}
              <div className="space-y-6">
                <h3 className="text-md font-semibold text-accent">账户统计</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className={`${styles.settingItem} p-4 rounded-xl text-center`}>
                    <p className="text-2xl font-bold text-accent">28</p>
                    <p className="text-text-muted text-sm">已完成订单</p>
                  </div>
                  
                  <div className={`${styles.settingItem} p-4 rounded-xl text-center`}>
                    <p className="text-2xl font-bold text-accent">4.8</p>
                    <p className="text-text-muted text-sm">平均评分</p>
                  </div>
                  
                  <div className={`${styles.settingItem} p-4 rounded-xl text-center`}>
                    <p className="text-2xl font-bold text-accent">2</p>
                    <p className="text-text-muted text-sm">宠物数量</p>
                  </div>
                  
                  <div className={`${styles.settingItem} p-4 rounded-xl text-center`}>
                    <p className="text-2xl font-bold text-accent">12</p>
                    <p className="text-text-muted text-sm">收藏服务商</p>
                  </div>
                </div>
                
                <div className={`${styles.settingItem} p-4 rounded-xl`}>
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-crown text-yellow-500 text-xl"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">普通会员</p>
                      <p className="text-text-muted text-sm">完成50个订单可升级为金牌会员</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* 账户安全设置 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-6">账户安全</h2>
            
            <div className="space-y-4">
              <div 
                onClick={handleChangePassword}
                className={`${styles.settingItem} p-4 rounded-xl cursor-pointer hover:shadow-lg transition-all`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-lock text-red-500"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">修改密码</p>
                      <p className="text-text-muted text-sm">定期更换密码，保护账户安全</p>
                    </div>
                  </div>
                  <i className="fas fa-chevron-right text-text-muted"></i>
                </div>
              </div>
              
              <div 
                onClick={() => handleThirdPartyBind('wechat', 'bind')}
                className={`${styles.settingItem} p-4 rounded-xl cursor-pointer hover:shadow-lg transition-all`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <i className="fab fa-weixin text-green-500"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">绑定微信</p>
                      <p className="text-text-muted text-sm">已绑定：wx_happy****</p>
                    </div>
                  </div>
                  <span className="px-2 py-1 bg-green-500/20 text-green-600 text-xs rounded-full">已绑定</span>
                </div>
              </div>
              
              <div 
                onClick={() => handleThirdPartyBind('qq', 'bind')}
                className={`${styles.settingItem} p-4 rounded-xl cursor-pointer hover:shadow-lg transition-all`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <i className="fab fa-qq text-blue-500"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">绑定QQ</p>
                      <p className="text-text-muted text-sm">绑定QQ，快捷登录</p>
                    </div>
                  </div>
                  <span className="px-2 py-1 bg-gray-500/20 text-gray-600 text-xs rounded-full">未绑定</span>
                </div>
              </div>
              
              <div 
                onClick={() => handleThirdPartyBind('apple', 'bind')}
                className={`${styles.settingItem} p-4 rounded-xl cursor-pointer hover:shadow-lg transition-all`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gray-500/20 rounded-lg flex items-center justify-center">
                      <i className="fab fa-apple text-gray-700"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">绑定Apple ID</p>
                      <p className="text-text-muted text-sm">绑定Apple ID，快捷登录</p>
                    </div>
                  </div>
                  <span className="px-2 py-1 bg-gray-500/20 text-gray-600 text-xs rounded-full">未绑定</span>
                </div>
              </div>
            </div>
          </section>

          {/* 通知设置 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-6">通知设置</h2>
            
            <div className="space-y-4">
              <div className={`${styles.settingItem} p-4 rounded-xl`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-bell text-blue-500"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">订单状态通知</p>
                      <p className="text-text-muted text-sm">接收订单状态变更通知</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={notificationSettings.orderNotification}
                      onChange={() => handleNotificationToggle('orderNotification')}
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
                  </label>
                </div>
              </div>
              
              <div className={`${styles.settingItem} p-4 rounded-xl`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-video text-green-500"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">云看宠提醒</p>
                      <p className="text-text-muted text-sm">宠物有新的照片或视频时通知</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={notificationSettings.cloudViewNotification}
                      onChange={() => handleNotificationToggle('cloudViewNotification')}
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
                  </label>
                </div>
              </div>
              
              <div className={`${styles.settingItem} p-4 rounded-xl`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-star text-yellow-500"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">评价提醒</p>
                      <p className="text-text-muted text-sm">服务完成后提醒评价</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={notificationSettings.ratingNotification}
                      onChange={() => handleNotificationToggle('ratingNotification')}
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
                  </label>
                </div>
              </div>
              
              <div className={`${styles.settingItem} p-4 rounded-xl`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                      <i className="fas fa-envelope text-purple-500"></i>
                    </div>
                    <div>
                      <p className="text-text-primary font-medium">邮件通知</p>
                      <p className="text-text-muted text-sm">接收重要事项邮件通知</p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={notificationSettings.emailNotification}
                      onChange={() => handleNotificationToggle('emailNotification')}
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
                  </label>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiCustomerService}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>

      {/* 编辑资料模态框 */}
      {isEditProfileModalVisible && (
        <div className="fixed inset-0 z-50">
          <div 
            className={`${styles.modalOverlay} absolute inset-0`}
            onClick={(e) => handleModalOverlayClick(e, setIsEditProfileModalVisible)}
          ></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} w-full max-w-md p-6 rounded-2xl`}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-accent">编辑资料</h3>
                <button 
                  onClick={() => closeModal(setIsEditProfileModalVisible)}
                  className="text-text-muted hover:text-accent transition-colors"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div>
                  <label htmlFor="edit-nickname" className="block text-sm font-medium text-text-primary mb-2">昵称</label>
                  <input 
                    type="text" 
                    id="edit-nickname" 
                    name="nickname" 
                    value={editProfileForm.nickname}
                    onChange={(e) => setEditProfileForm(prev => ({ ...prev, nickname: e.target.value }))}
                    className={`w-full px-4 py-3 ${styles.formInput} rounded-lg text-text-primary placeholder-text-muted`}
                  />
                </div>
                
                <div>
                  <label htmlFor="edit-phone" className="block text-sm font-medium text-text-primary mb-2">手机号</label>
                  <input 
                    type="tel" 
                    id="edit-phone" 
                    name="phone" 
                    value={editProfileForm.phone}
                    readOnly
                    className={`w-full px-4 py-3 ${styles.formInput} rounded-lg text-text-primary placeholder-text-muted`}
                  />
                  <p className="text-text-muted text-xs mt-1">手机号不可修改</p>
                </div>
                
                <div>
                  <label htmlFor="edit-address" className="block text-sm font-medium text-text-primary mb-2">地址</label>
                  <input 
                    type="text" 
                    id="edit-address" 
                    name="address" 
                    value={editProfileForm.address}
                    onChange={(e) => setEditProfileForm(prev => ({ ...prev, address: e.target.value }))}
                    className={`w-full px-4 py-3 ${styles.formInput} rounded-lg text-text-primary placeholder-text-muted`}
                  />
                </div>
                
                <div className="flex space-x-3 pt-4">
                  <button 
                    type="button" 
                    onClick={() => closeModal(setIsEditProfileModalVisible)}
                    className={`flex-1 ${styles.btnSecondary} py-3 rounded-lg font-medium`}
                  >
                    取消
                  </button>
                  <button 
                    type="submit" 
                    className={`flex-1 ${styles.btnPrimary} py-3 rounded-lg font-medium`}
                  >
                    保存
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* 修改密码模态框 */}
      {isChangePasswordModalVisible && (
        <div className="fixed inset-0 z-50">
          <div 
            className={`${styles.modalOverlay} absolute inset-0`}
            onClick={(e) => handleModalOverlayClick(e, setIsChangePasswordModalVisible)}
          ></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.modalContent} w-full max-w-md p-6 rounded-2xl`}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-accent">修改密码</h3>
                <button 
                  onClick={() => closeModal(setIsChangePasswordModalVisible)}
                  className="text-text-muted hover:text-accent transition-colors"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              
              <form onSubmit={handleSavePassword} className="space-y-4">
                <div>
                  <label htmlFor="current-password" className="block text-sm font-medium text-text-primary mb-2">当前密码</label>
                  <input 
                    type="password" 
                    id="current-password" 
                    name="currentPassword" 
                    value={changePasswordForm.currentPassword}
                    onChange={(e) => setChangePasswordForm(prev => ({ ...prev, currentPassword: e.target.value }))}
                    className={`w-full px-4 py-3 ${styles.formInput} rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请输入当前密码"
                  />
                </div>
                
                <div>
                  <label htmlFor="new-password" className="block text-sm font-medium text-text-primary mb-2">新密码</label>
                  <input 
                    type="password" 
                    id="new-password" 
                    name="newPassword" 
                    value={changePasswordForm.newPassword}
                    onChange={(e) => setChangePasswordForm(prev => ({ ...prev, newPassword: e.target.value }))}
                    className={`w-full px-4 py-3 ${styles.formInput} rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请输入新密码"
                  />
                </div>
                
                <div>
                  <label htmlFor="confirm-password" className="block text-sm font-medium text-text-primary mb-2">确认新密码</label>
                  <input 
                    type="password" 
                    id="confirm-password" 
                    name="confirmPassword" 
                    value={changePasswordForm.confirmPassword}
                    onChange={(e) => setChangePasswordForm(prev => ({ ...prev, confirmPassword: e.target.value }))}
                    className={`w-full px-4 py-3 ${styles.formInput} rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请再次输入新密码"
                  />
                </div>
                
                <div className="flex space-x-3 pt-4">
                  <button 
                    type="button" 
                    onClick={() => closeModal(setIsChangePasswordModalVisible)}
                    className={`flex-1 ${styles.btnSecondary} py-3 rounded-lg font-medium`}
                  >
                    取消
                  </button>
                  <button 
                    type="submit" 
                    className={`flex-1 ${styles.btnPrimary} py-3 rounded-lg font-medium`}
                  >
                    修改密码
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserProfilePage;

