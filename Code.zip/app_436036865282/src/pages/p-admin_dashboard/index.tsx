

import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface TaskItem {
  id: string;
  type: 'qualification' | 'content';
  user: {
    name: string;
    avatar: string;
  };
  submitTime: string;
  priority: 'high' | 'medium';
}

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [searchInputValue, setSearchInputValue] = useState('');

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 管理员工作台';
    return () => { document.title = originalTitle; };
  }, []);

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      console.log('搜索:', searchInputValue);
      // 这里可以实现搜索功能
    }
  };

  const handleNotificationClick = () => {
    console.log('查看通知');
    // 这里可以显示通知列表
  };

  const handleUserMenuClick = () => {
    console.log('用户菜单');
    // 这里可以显示用户菜单下拉
  };

  const handleTaskRowClick = (task: TaskItem) => {
    if (task.type === 'qualification') {
      // 资质审核任务，跳转到资质审核页面
      navigate(`/qualification-audit?taskId=${task.id}`);
    } else if (task.type === 'content') {
      // 内容巡查任务，跳转到内容巡查页面
      navigate(`/content-moderation?taskId=${task.id}`);
    }
  };

  const handleAiCustomerServiceClick = () => {
    // 这里可以打开AI客服弹窗
    alert('AI客服功能开发中...');
  };

  const pendingTasks: TaskItem[] = [
    {
      id: 'T001',
      type: 'qualification',
      user: {
        name: '李阿姨',
        avatar: 'https://s.coze.cn/image/0WkHDADkFxg/'
      },
      submitTime: '2024-03-15 14:30',
      priority: 'high'
    },
    {
      id: 'T002',
      type: 'qualification',
      user: {
        name: '王小姐',
        avatar: 'https://s.coze.cn/image/8q9Y0ikYqL4/'
      },
      submitTime: '2024-03-15 11:20',
      priority: 'medium'
    },
    {
      id: 'T003',
      type: 'content',
      user: {
        name: '张先生',
        avatar: 'https://s.coze.cn/image/gmjjpZKafgs/'
      },
      submitTime: '2024-03-15 09:15',
      priority: 'high'
    },
    {
      id: 'T004',
      type: 'content',
      user: {
        name: '刘先生',
        avatar: 'https://s.coze.cn/image/sInIHjHtqIw/'
      },
      submitTime: '2024-03-14 16:45',
      priority: 'medium'
    }
  ];

  const getPriorityLabel = (priority: 'high' | 'medium') => {
    return priority === 'high' ? (
      <span className="px-2 py-1 bg-red-500/20 text-red-600 text-xs rounded-full">高</span>
    ) : (
      <span className="px-2 py-1 bg-yellow-500/20 text-yellow-600 text-xs rounded-full">中</span>
    );
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索用户、服务、订单..." 
                value={searchInputValue}
                onChange={(e) => setSearchInputValue(e.target.value)}
                onKeyPress={handleSearchKeyPress}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            onClick={handleNotificationClick}
            className="relative p-2 text-text-secondary hover:text-accent transition-colors"
          >
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
          </button>
          <div 
            onClick={handleUserMenuClick}
            className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors"
          >
            <img 
              src="https://s.coze.cn/image/7QTUDqbN3zM/" 
              alt="管理员头像" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-text-primary font-medium hidden md:block">管理员</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link 
              to="/admin-dashboard" 
              className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}
            >
              <i className="fas fa-tachometer-alt text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link 
              to="/user-manage" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-users text-lg"></i>
              <span className="font-medium">用户管理</span>
            </Link>
            <Link 
              to="/service-manage" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-handshake text-lg"></i>
              <span className="font-medium">服务管理</span>
            </Link>
            <Link 
              to="/admin-order-manage" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-clipboard-list text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <Link 
              to="/content-moderation" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-shield-alt text-lg"></i>
              <span className="font-medium">内容巡查</span>
            </Link>
            <Link 
              to="/data-dashboard" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-chart-bar text-lg"></i>
              <span className="font-medium">数据看板</span>
            </Link>
            <Link 
              to="/system-settings" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-cog text-lg"></i>
              <span className="font-medium">系统设置</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">管理员工作台</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">欢迎回来，管理员！</h1>
                <p className="text-text-secondary mt-1">今天是平台运营的重要一天，让我们查看最新数据</p>
              </div>
              <div className="hidden lg:flex items-center space-x-2 text-text-secondary">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>系统运行正常</span>
              </div>
            </div>
          </header>

          {/* 数据概览区 */}
          <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">总注册用户数</p>
                  <p className="text-3xl font-bold text-accent mt-2">1,248</p>
                  <p className="text-secondary text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +12% 较上月
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-users text-blue-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">活跃服务商数</p>
                  <p className="text-3xl font-bold text-accent mt-2">89</p>
                  <p className="text-green-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +8% 较上月
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-store text-green-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">今日订单数</p>
                  <p className="text-3xl font-bold text-accent mt-2">23</p>
                  <p className="text-purple-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +15% 较昨日
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-shopping-cart text-purple-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">待处理审核</p>
                  <p className="text-3xl font-bold text-accent mt-2">7</p>
                  <p className="text-red-600 text-sm mt-1">
                    <i className="fas fa-exclamation-triangle"></i> 需要处理
                  </p>
                </div>
                <div className="w-12 h-12 bg-red-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-tasks text-red-500 text-xl"></i>
                </div>
              </div>
            </div>
          </section>

          {/* 快捷操作区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-4">快捷操作</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Link 
                to="/user-manage"
                className={`${styles.btnPrimary} p-4 rounded-xl text-left hover:shadow-lg transition-all block`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-users text-white text-lg"></i>
                  </div>
                  <div>
                    <p className="font-medium text-white">用户管理</p>
                    <p className="text-white/80 text-sm">管理平台用户账户</p>
                  </div>
                </div>
              </Link>

              <Link 
                to="/service-manage"
                className={`${styles.btnSecondary} p-4 rounded-xl text-left hover:shadow-lg transition-all block`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-handshake text-accent text-lg"></i>
                  </div>
                  <div>
                    <p className="font-medium text-accent">服务管理</p>
                    <p className="text-text-muted text-sm">管理托管服务内容</p>
                  </div>
                </div>
              </Link>

              <Link 
                to="/content-moderation"
                className={`${styles.btnSecondary} p-4 rounded-xl text-left hover:shadow-lg transition-all block`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-shield-alt text-accent text-lg"></i>
                  </div>
                  <div>
                    <p className="font-medium text-accent">内容巡查</p>
                    <p className="text-text-muted text-sm">审核平台内容安全</p>
                  </div>
                </div>
              </Link>
            </div>
          </section>

          {/* 待处理任务列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">待处理任务</h2>
              <Link 
                to="/content-moderation" 
                className="text-secondary hover:text-accent text-sm font-medium transition-colors"
              >
                查看全部 <i className="fas fa-arrow-right ml-1"></i>
              </Link>
            </div>
            
            <div className="overflow-x-auto">
              <table className={`w-full ${styles.tableGlass} rounded-xl overflow-hidden`}>
                <thead className="bg-white/10">
                  <tr>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">任务ID</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">任务类型</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">相关用户</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">提交时间</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">紧急程度</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingTasks.map((task, index) => (
                    <tr 
                      key={task.id}
                      onClick={() => handleTaskRowClick(task)}
                      className={`${styles.tableRow} ${index < pendingTasks.length - 1 ? 'border-b border-white/10' : ''} cursor-pointer`}
                    >
                      <td className="px-4 py-3 text-text-primary font-medium">#{task.id}</td>
                      <td className="px-4 py-3 text-text-secondary">
                        {task.type === 'qualification' ? '资质审核' : '内容投诉'}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <img 
                            src={task.user.avatar} 
                            alt={task.user.name} 
                            className="w-8 h-8 rounded-full"
                          />
                          <span className="text-text-primary">{task.user.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-text-secondary">{task.submitTime}</td>
                      <td className="px-4 py-3">
                        {getPriorityLabel(task.priority)}
                      </td>
                      <td className="px-4 py-3">
                        <button className="text-secondary hover:text-accent text-sm font-medium">处理</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* AI预测概览 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">AI预测概览</h2>
              <div className="flex items-center space-x-2 text-text-muted">
                <i className="fas fa-robot"></i>
                <span className="text-sm">基于机器学习的智能预测</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gradient-to-r from-secondary/10 to-accent/10 p-4 rounded-xl border border-secondary/20">
                <h3 className="font-medium text-accent mb-4">未来7日订单峰值预测</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-text-secondary text-sm">今日</span>
                    <span className="font-medium text-accent">23单</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-text-secondary text-sm">明日</span>
                    <span className="font-medium text-accent">28单 (+22%)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-text-secondary text-sm">后日</span>
                    <span className="font-medium text-accent">35单 (+25%)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-text-secondary text-sm">周末峰值</span>
                    <span className="font-medium text-red-500">42单 (+20%)</span>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-white/20 rounded-lg">
                  <p className="text-sm text-text-secondary">
                    <i className="fas fa-lightbulb text-yellow-500 mr-2"></i>
                    建议：提前准备充足的托管资源，预计周末将迎来订单高峰
                  </p>
                </div>
              </div>

              <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-4 rounded-xl border border-blue-500/20">
                <h3 className="font-medium text-accent mb-4">用户增长趋势</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-text-secondary">用户增长率</span>
                      <span className="font-medium text-accent">12.5%</span>
                    </div>
                    <div className="w-full bg-white/30 rounded-full h-2">
                      <div className={`${styles.progressBar} w-3/4`}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-text-secondary">服务商活跃度</span>
                      <span className="font-medium text-accent">89%</span>
                    </div>
                    <div className="w-full bg-white/30 rounded-full h-2">
                      <div className={`${styles.progressBar} w-11/12`}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-text-secondary">订单完成率</span>
                      <span className="font-medium text-accent">96.8%</span>
                    </div>
                    <div className="w-full bg-white/30 rounded-full h-2">
                      <div className={`${styles.progressBar} w-full`}></div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-white/20 rounded-lg">
                  <p className="text-sm text-text-secondary">
                    <i className="fas fa-chart-line text-blue-500 mr-2"></i>
                    用户增长稳定，建议加强服务商招募以满足日益增长的需求
                  </p>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiCustomerServiceClick}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default AdminDashboard;

