

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';

interface Pet {
  id: string;
  name: string;
  type: string;
  age: number;
  location: string;
  status: string;
  avatar: string;
}

interface MediaItem {
  id: string;
  type: 'photo' | 'video';
  url: string;
  title: string;
  time: string;
  uploader: string;
  thumbnail?: string;
}

const CloudViewPage: React.FC = () => {
  const [selectedPetId, setSelectedPetId] = useState<string>('doudou');
  const [isVideoPlaying, setIsVideoPlaying] = useState<boolean>(false);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [selectedMediaItem, setSelectedMediaItem] = useState<MediaItem | null>(null);
  const [mediaFilter, setMediaFilter] = useState<string>('all');
  const [isLoadingMore, setIsLoadingMore] = useState<boolean>(false);
  const [liveDuration, setLiveDuration] = useState<string>('00:15:32');

  const pets: Pet[] = [
    {
      id: 'doudou',
      name: '豆豆',
      type: '金毛犬',
      age: 7,
      location: '李阿姨家托管中',
      status: '托管中',
      avatar: 'https://s.coze.cn/image/HV8dXlM-y9w/'
    },
    {
      id: 'mimi',
      name: '咪咪',
      type: '布偶猫',
      age: 3,
      location: '在家',
      status: '在家',
      avatar: 'https://s.coze.cn/image/opKhqULO0DE/'
    }
  ];

  const mediaItems: MediaItem[] = [
    {
      id: '1',
      type: 'photo',
      url: 'https://s.coze.cn/image/nWo1bGjyG1Q/',
      title: '豆豆在院子里玩耍',
      time: '2分钟前',
      uploader: '李阿姨上传'
    },
    {
      id: '2',
      type: 'photo',
      url: 'https://s.coze.cn/image/noyy6j6q5pA/',
      title: '豆豆正在享用午餐',
      time: '15分钟前',
      uploader: '李阿姨上传'
    },
    {
      id: '3',
      type: 'video',
      url: '#',
      thumbnail: 'https://s.coze.cn/image/WWI8vCc3RbQ/',
      title: '豆豆在公园散步',
      time: '1小时前',
      uploader: '李阿姨上传'
    },
    {
      id: '4',
      type: 'photo',
      url: 'https://s.coze.cn/image/GcL462PRiX0/',
      title: '豆豆在垫子上休息',
      time: '2小时前',
      uploader: '李阿姨上传'
    },
    {
      id: '5',
      type: 'photo',
      url: 'https://s.coze.cn/image/FlFVR-O_ui0/',
      title: '豆豆在喝水',
      time: '3小时前',
      uploader: '李阿姨上传'
    },
    {
      id: '6',
      type: 'video',
      url: '#',
      thumbnail: 'https://s.coze.cn/image/6--hwWXj9jo/',
      title: '豆豆和小伙伴们玩耍',
      time: '4小时前',
      uploader: '李阿姨上传'
    }
  ];

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 云看宠';
    return () => { document.title = originalTitle; };
  }, []);

  useEffect(() => {
    let seconds = 932; // 15:32 in seconds
    
    const timer = setInterval(() => {
      seconds++;
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const secs = seconds % 60;
      
      const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
      setLiveDuration(formattedTime);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handlePetSelect = (petId: string) => {
    setSelectedPetId(petId);
    console.log('切换到宠物:', petId);
  };

  const handleRefresh = () => {
    console.log('刷新内容');
  };

  const handlePlayVideo = () => {
    console.log('需要调用第三方接口实现视频播放功能');
    setIsVideoPlaying(true);
  };

  const handlePauseVideo = () => {
    console.log('暂停视频播放');
  };

  const handleFullscreenVideo = () => {
    console.log('视频全屏');
  };

  const handleMediaItemClick = (item: MediaItem) => {
    if (item.type === 'photo') {
      setSelectedMediaItem(item);
      setIsModalOpen(true);
    } else if (item.type === 'video') {
      console.log('需要调用第三方接口实现视频播放功能');
      alert('视频播放功能开发中...');
    }
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedMediaItem(null);
  };

  const handleMediaFilter = (filterType: string) => {
    setMediaFilter(filterType);
    console.log('筛选类型:', filterType);
  };

  const handleLoadMore = () => {
    setIsLoadingMore(true);
    console.log('加载更多动态');
    
    setTimeout(() => {
      setIsLoadingMore(false);
    }, 2000);
  };

  const handleAICustomerService = () => {
    console.log('打开AI客服');
    alert('AI客服功能开发中...');
  };

  const filteredMediaItems = mediaItems.filter(item => {
    if (mediaFilter === 'all') return true;
    return item.type === mediaFilter;
  });

  const selectedPet = pets.find(pet => pet.id === selectedPetId);

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img 
              src="https://s.coze.cn/image/h3LLC2uS6kg/" 
              alt="用户头像" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-text-primary font-medium hidden md:block">张小明</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link 
              to="/owner-dashboard" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link 
              to="/pet-profile" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-paw text-lg"></i>
              <span className="font-medium">我的宠物</span>
            </Link>
            <Link 
              to="/service-discovery" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-search text-lg"></i>
              <span className="font-medium">寻找服务</span>
            </Link>
            <Link 
              to="/owner-calendar" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-calendar-alt text-lg"></i>
              <span className="font-medium">托管日历</span>
            </Link>
            <div className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-video text-lg"></i>
              <span className="font-medium">云看宠</span>
            </div>
            <Link 
              to="/user-profile" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">云看宠</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">云看宠</h1>
                <p className="text-text-secondary mt-1">实时查看您的爱宠状态，让托管更安心</p>
              </div>
              <button 
                onClick={handleRefresh}
                className={`${styles.btnSecondary} px-4 py-2 rounded-lg flex items-center space-x-2 hover:shadow-lg transition-all`}
              >
                <i className="fas fa-sync-alt text-accent"></i>
                <span className="text-accent font-medium">刷新</span>
              </button>
            </div>
          </header>

          {/* 宠物选择器 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-4">选择宠物</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {pets.map(pet => (
                <div 
                  key={pet.id}
                  onClick={() => handlePetSelect(pet.id)}
                  className={`${styles.petSelector} ${selectedPetId === pet.id ? 'active' : ''} flex items-center space-x-3 p-4 rounded-xl`}
                >
                  <img 
                    src={pet.avatar} 
                    alt={`${pet.type}${pet.name}`} 
                    className="w-12 h-12 rounded-full"
                  />
                  <div>
                    <p className="font-medium text-accent">{pet.name}</p>
                    <p className="text-text-muted text-sm">{pet.type} · {pet.age}岁</p>
                    <p className={`text-xs mt-1 ${pet.status === '托管中' ? 'text-secondary' : 'text-green-600'}`}>
                      {pet.location}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* 实时视频流 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">实时视频</h2>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-green-600 text-sm font-medium">直播中</span>
              </div>
            </div>
            
            <div className={`${styles.videoContainer} ${!isVideoPlaying ? styles.videoPlaceholder : ''} aspect-video flex items-center justify-center`}>
              {!isVideoPlaying ? (
                <div className="text-center">
                  <i className="fas fa-video text-6xl text-text-muted mb-4"></i>
                  <p className="text-text-secondary font-medium mb-2">李阿姨的托管环境</p>
                  <p className="text-text-muted text-sm">点击播放按钮查看实时画面</p>
                  <button 
                    onClick={handlePlayVideo}
                    className={`${styles.btnPrimary} px-6 py-2 rounded-lg mt-4 hover:shadow-lg transition-all`}
                  >
                    <i className="fas fa-play mr-2"></i>
                    播放实时视频
                  </button>
                </div>
              ) : (
                <>
                  <img 
                    src="https://s.coze.cn/image/vBPMocc8Ark/" 
                    alt="实时视频流" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <div className="bg-black/50 text-white px-4 py-2 rounded-lg">
                      <i className="fas fa-circle text-green-500 mr-2"></i>
                      直播中
                    </div>
                  </div>
                </>
              )}
            </div>
            
            {isVideoPlaying && (
              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center space-x-4">
                  <button 
                    onClick={handlePauseVideo}
                    className={`${styles.btnSecondary} px-4 py-2 rounded-lg flex items-center space-x-2`}
                  >
                    <i className="fas fa-pause text-accent"></i>
                    <span className="text-accent">暂停</span>
                  </button>
                  <button 
                    onClick={handleFullscreenVideo}
                    className={`${styles.btnSecondary} px-4 py-2 rounded-lg flex items-center space-x-2`}
                  >
                    <i className="fas fa-expand text-accent"></i>
                    <span className="text-accent">全屏</span>
                  </button>
                </div>
                <div className="text-text-muted text-sm">
                  直播时长: <span>{liveDuration}</span>
                </div>
              </div>
            )}
          </section>

          {/* 照片/短视频列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">最新动态</h2>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => handleMediaFilter('all')}
                  className={`px-3 py-1 text-sm rounded-full ${mediaFilter === 'all' ? 'bg-secondary text-white' : 'bg-white/20 text-accent hover:bg-white/30 transition-colors'}`}
                >
                  全部
                </button>
                <button 
                  onClick={() => handleMediaFilter('photo')}
                  className={`px-3 py-1 text-sm rounded-full ${mediaFilter === 'photo' ? 'bg-secondary text-white' : 'bg-white/20 text-accent hover:bg-white/30 transition-colors'}`}
                >
                  照片
                </button>
                <button 
                  onClick={() => handleMediaFilter('video')}
                  className={`px-3 py-1 text-sm rounded-full ${mediaFilter === 'video' ? 'bg-secondary text-white' : 'bg-white/20 text-accent hover:bg-white/30 transition-colors'}`}
                >
                  视频
                </button>
              </div>
            </div>
            
            <div className={styles.photoGrid}>
              {filteredMediaItems.map(item => (
                <div 
                  key={item.id}
                  onClick={() => handleMediaItemClick(item)}
                  className={styles.photoItem}
                >
                  {item.type === 'photo' ? (
                    <img 
                      src={item.url} 
                      alt={item.title} 
                      className="w-full h-40 object-cover"
                    />
                  ) : (
                    <div className="relative">
                      <img 
                        src={item.thumbnail} 
                        alt={item.title} 
                        className="w-full h-40 object-cover"
                      />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <i className="fas fa-play text-white text-2xl"></i>
                      </div>
                      <span className="absolute top-2 right-2 bg-red-500 text-white text-xs px-2 py-1 rounded">视频</span>
                    </div>
                  )}
                  <div className="p-3">
                    <p className="text-text-primary font-medium text-sm">{item.title}</p>
                    <p className="text-text-muted text-xs mt-1">{item.time} · {item.uploader}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-6">
              <button 
                onClick={handleLoadMore}
                disabled={isLoadingMore}
                className={`${styles.btnSecondary} px-6 py-2 rounded-lg hover:shadow-lg transition-all`}
              >
                {isLoadingMore ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    加载中...
                  </>
                ) : (
                  <>
                    <i className="fas fa-arrow-down mr-2"></i>
                    加载更多动态
                  </>
                )}
              </button>
            </div>
          </section>
        </main>
      </div>

      {/* 照片查看模态框 */}
      {isModalOpen && selectedMediaItem && (
        <div 
          className={`${styles.photoModal} fixed inset-0 z-50 flex items-center justify-center p-4`}
          onClick={handleCloseModal}
        >
          <div className="relative max-w-4xl max-h-screen">
            <button 
              onClick={handleCloseModal}
              className="absolute top-4 right-4 w-10 h-10 bg-black/50 text-white rounded-full flex items-center justify-center hover:bg-black/70 transition-colors z-10"
            >
              <i className="fas fa-times"></i>
            </button>
            <img 
              src={selectedMediaItem.url} 
              alt={selectedMediaItem.title} 
              className="max-w-full max-h-full object-contain rounded-lg"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAICustomerService}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default CloudViewPage;

