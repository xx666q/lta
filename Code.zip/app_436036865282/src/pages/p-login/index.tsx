

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface LoginFormData {
  phone: string;
  password: string;
  rememberMe: boolean;
}

interface RegisterFormData {
  phone: string;
  code: string;
  password: string;
  confirm: string;
}

interface ForgotFormData {
  phone: string;
  code: string;
}

interface FormErrors {
  phone?: string;
  password?: string;
  code?: string;
  confirm?: string;
}

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 状态管理
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  const [showForgotModal, setShowForgotModal] = useState(false);
  
  // 表单数据
  const [loginForm, setLoginForm] = useState<LoginFormData>({
    phone: '',
    password: '',
    rememberMe: false
  });
  
  const [registerForm, setRegisterForm] = useState<RegisterFormData>({
    phone: '',
    code: '',
    password: '',
    confirm: ''
  });
  
  const [forgotForm, setForgotForm] = useState<ForgotFormData>({
    phone: '',
    code: ''
  });
  
  // 密码可见性
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // 验证码倒计时
  const [registerCodeCountdown, setRegisterCodeCountdown] = useState(0);
  const [forgotCodeCountdown, setForgotCodeCountdown] = useState(0);
  
  // 错误信息
  const [loginErrors, setLoginErrors] = useState<FormErrors>({});
  const [registerErrors, setRegisterErrors] = useState<FormErrors>({});
  const [forgotErrors, setForgotErrors] = useState<FormErrors>({});
  
  // 提交状态
  const [isLoginSubmitting, setIsLoginSubmitting] = useState(false);
  const [isRegisterSubmitting, setIsRegisterSubmitting] = useState(false);
  
  // 消息
  const [loginMessage, setLoginMessage] = useState('');
  const [registerMessage, setRegisterMessage] = useState('');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 登录注册';
    return () => { document.title = originalTitle; };
  }, []);

  // 验证函数
  const validatePhone = (phone: string): boolean => {
    const phoneRegex = /^1[3-9]\d{9}$/;
    return phoneRegex.test(phone);
  };

  const validatePassword = (password: string): boolean => {
    return password.length >= 6 && password.length <= 20;
  };

  const validateCode = (code: string): boolean => {
    return code.length === 6 && /^\d{6}$/.test(code);
  };

  // 清除所有消息和错误
  const clearMessages = () => {
    setLoginMessage('');
    setRegisterMessage('');
    setLoginErrors({});
    setRegisterErrors({});
    setForgotErrors({});
  };

  // 标签切换
  const handleTabSwitch = (tab: 'login' | 'register') => {
    setActiveTab(tab);
    clearMessages();
  };

  // 验证码倒计时
  useEffect(() => {
    let timer: number;
    if (registerCodeCountdown > 0) {
      timer = window.setTimeout(() => {
        setRegisterCodeCountdown(registerCodeCountdown - 1);
      }, 1000);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [registerCodeCountdown]);

  useEffect(() => {
    let timer: number;
    if (forgotCodeCountdown > 0) {
      timer = window.setTimeout(() => {
        setForgotCodeCountdown(forgotCodeCountdown - 1);
      }, 1000);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [forgotCodeCountdown]);

  // 发送验证码
  const handleSendCode = (type: 'register' | 'forgot') => {
    const phone = type === 'register' ? registerForm.phone : forgotForm.phone;
    
    if (!validatePhone(phone)) {
      alert('请输入正确的手机号');
      return;
    }
    
    if (type === 'register') {
      setRegisterCodeCountdown(60);
    } else {
      setForgotCodeCountdown(60);
    }
    
    console.log('发送验证码到手机号:', phone);
  };

  // 登录表单提交
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    clearMessages();
    
    const errors: FormErrors = {};
    
    // 验证手机号
    if (!validatePhone(loginForm.phone)) {
      errors.phone = '请输入正确的手机号';
    }
    
    // 验证密码
    if (!loginForm.password) {
      errors.password = '请输入密码';
    }
    
    setLoginErrors(errors);
    
    if (Object.keys(errors).length > 0) return;
    
    setIsLoginSubmitting(true);
    
    try {
      // 模拟登录请求
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // 登录成功，跳转到宠物主人工作台
      navigate('/owner-dashboard');
    } catch (error) {
      setLoginMessage('登录失败，请重试');
    } finally {
      setIsLoginSubmitting(false);
    }
  };

  // 注册表单提交
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    clearMessages();
    
    const errors: FormErrors = {};
    
    // 验证手机号
    if (!validatePhone(registerForm.phone)) {
      errors.phone = '请输入正确的手机号';
    }
    
    // 验证验证码
    if (!validateCode(registerForm.code)) {
      errors.code = '请输入6位数字验证码';
    }
    
    // 验证密码
    if (!validatePassword(registerForm.password)) {
      errors.password = '密码长度应为6-20位';
    }
    
    // 验证确认密码
    if (registerForm.password !== registerForm.confirm) {
      errors.confirm = '两次输入的密码不一致';
    } else if (!registerForm.confirm) {
      errors.confirm = '请确认密码';
    }
    
    setRegisterErrors(errors);
    
    if (Object.keys(errors).length > 0) return;
    
    setIsRegisterSubmitting(true);
    
    try {
      // 模拟注册请求
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // 注册成功，跳转到身份选择页
      navigate('/identity-select');
    } catch (error) {
      setRegisterMessage('注册失败，请重试');
    } finally {
      setIsRegisterSubmitting(false);
    }
  };

  // 找回密码表单提交
  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePhone(forgotForm.phone) || !validateCode(forgotForm.code)) {
      alert('请输入正确的手机号和验证码');
      return;
    }
    
    // 模拟重置密码成功
    alert('密码重置链接已发送到您的手机，请查收');
    setShowForgotModal(false);
  };

  // 第三方登录
  const handleSocialLogin = (type: 'wechat' | 'qq' | 'apple') => {
    const platform = type === 'wechat' ? '微信' : type === 'qq' ? 'QQ' : 'Apple ID';
    console.log(`${platform}登录功能开发中...`);
    alert(`${platform}登录功能开发中...`);
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 主容器 */}
      <div className="min-h-screen flex items-center justify-center p-4">
        {/* 登录注册卡片 */}
        <div className={`${styles.glassCard} w-full max-w-md rounded-2xl p-8`}>
          {/* Logo区域 */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <i className="fas fa-paw text-4xl text-accent"></i>
              <span className="text-3xl font-bold text-accent">宠托帮</span>
            </div>
            <p className="text-text-secondary">让宠物托管更安心</p>
          </div>

          {/* 标签切换 */}
          <div className="flex mb-6 bg-white/10 rounded-lg p-1">
            <button 
              onClick={() => handleTabSwitch('login')}
              className={`${activeTab === 'login' ? styles.tabActive : styles.tabInactive} flex-1 py-2 px-4 text-center font-medium rounded-md transition-all`}
            >
              登录
            </button>
            <button 
              onClick={() => handleTabSwitch('register')}
              className={`${activeTab === 'register' ? styles.tabActive : styles.tabInactive} flex-1 py-2 px-4 text-center font-medium rounded-md transition-all`}
            >
              注册
            </button>
          </div>

          {/* 登录表单 */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="login-phone" className="block text-sm font-medium text-text-primary">手机号</label>
                <input 
                  type="tel" 
                  id="login-phone" 
                  value={loginForm.phone}
                  onChange={(e) => setLoginForm({...loginForm, phone: e.target.value})}
                  className={`${styles.glassInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted`}
                  placeholder="请输入手机号" 
                  maxLength={11} 
                  required 
                />
                {loginErrors.phone && <div className={styles.errorMessage}>{loginErrors.phone}</div>}
              </div>

              <div className="space-y-2">
                <label htmlFor="login-password" className="block text-sm font-medium text-text-primary">密码</label>
                <div className="relative">
                  <input 
                    type={showLoginPassword ? 'text' : 'password'} 
                    id="login-password" 
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                    className={`${styles.glassInput} w-full px-4 py-3 pr-12 rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请输入密码" 
                    required 
                  />
                  <button 
                    type="button" 
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-muted hover:text-accent"
                  >
                    <i className={`fas ${showLoginPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                  </button>
                </div>
                {loginErrors.password && <div className={styles.errorMessage}>{loginErrors.password}</div>}
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center space-x-2">
                  <input 
                    type="checkbox" 
                    checked={loginForm.rememberMe}
                    onChange={(e) => setLoginForm({...loginForm, rememberMe: e.target.checked})}
                    className="rounded border-white/30 bg-white/20 text-secondary focus:ring-secondary" 
                  />
                  <span className="text-sm text-text-secondary">记住我</span>
                </label>
                <button 
                  type="button" 
                  onClick={() => setShowForgotModal(true)}
                  className="text-sm text-secondary hover:text-accent transition-colors"
                >
                  忘记密码？
                </button>
              </div>

              <button 
                type="submit" 
                disabled={isLoginSubmitting}
                className={`${styles.btnPrimary} w-full py-3 rounded-lg font-medium`}
              >
                {isLoginSubmitting ? '登录中...' : '登录'}
              </button>

              {loginMessage && (
                <div className="text-center">
                  <div className={styles.errorMessage}>{loginMessage}</div>
                </div>
              )}
            </form>
          )}

          {/* 注册表单 */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="register-phone" className="block text-sm font-medium text-text-primary">手机号</label>
                <input 
                  type="tel" 
                  id="register-phone" 
                  value={registerForm.phone}
                  onChange={(e) => setRegisterForm({...registerForm, phone: e.target.value})}
                  className={`${styles.glassInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted`}
                  placeholder="请输入手机号" 
                  maxLength={11} 
                  required 
                />
                {registerErrors.phone && <div className={styles.errorMessage}>{registerErrors.phone}</div>}
              </div>

              <div className="space-y-2">
                <label htmlFor="register-code" className="block text-sm font-medium text-text-primary">验证码</label>
                <div className="flex space-x-3">
                  <input 
                    type="text" 
                    id="register-code" 
                    value={registerForm.code}
                    onChange={(e) => setRegisterForm({...registerForm, code: e.target.value})}
                    className={`${styles.glassInput} flex-1 px-4 py-3 rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请输入验证码" 
                    maxLength={6} 
                    required 
                  />
                  <button 
                    type="button" 
                    onClick={() => handleSendCode('register')}
                    disabled={registerCodeCountdown > 0}
                    className={`${styles.btnSecondary} px-4 py-3 rounded-lg font-medium whitespace-nowrap`}
                  >
                    {registerCodeCountdown > 0 ? `${registerCodeCountdown}秒后重发` : '发送验证码'}
                  </button>
                </div>
                {registerErrors.code && <div className={styles.errorMessage}>{registerErrors.code}</div>}
              </div>

              <div className="space-y-2">
                <label htmlFor="register-password" className="block text-sm font-medium text-text-primary">设置密码</label>
                <div className="relative">
                  <input 
                    type={showRegisterPassword ? 'text' : 'password'} 
                    id="register-password" 
                    value={registerForm.password}
                    onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
                    className={`${styles.glassInput} w-full px-4 py-3 pr-12 rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请设置6-20位密码" 
                    minLength={6} 
                    maxLength={20} 
                    required 
                  />
                  <button 
                    type="button" 
                    onClick={() => setShowRegisterPassword(!showRegisterPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-muted hover:text-accent"
                  >
                    <i className={`fas ${showRegisterPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                  </button>
                </div>
                {registerErrors.password && <div className={styles.errorMessage}>{registerErrors.password}</div>}
              </div>

              <div className="space-y-2">
                <label htmlFor="register-confirm" className="block text-sm font-medium text-text-primary">确认密码</label>
                <div className="relative">
                  <input 
                    type={showConfirmPassword ? 'text' : 'password'} 
                    id="register-confirm" 
                    value={registerForm.confirm}
                    onChange={(e) => setRegisterForm({...registerForm, confirm: e.target.value})}
                    className={`${styles.glassInput} w-full px-4 py-3 pr-12 rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请再次输入密码" 
                    required 
                  />
                  <button 
                    type="button" 
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-muted hover:text-accent"
                  >
                    <i className={`fas ${showConfirmPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                  </button>
                </div>
                {registerErrors.confirm && <div className={styles.errorMessage}>{registerErrors.confirm}</div>}
              </div>

              <button 
                type="submit" 
                disabled={isRegisterSubmitting}
                className={`${styles.btnPrimary} w-full py-3 rounded-lg font-medium`}
              >
                {isRegisterSubmitting ? '注册中...' : '注册'}
              </button>

              {registerMessage && (
                <div className="text-center">
                  <div className={styles.errorMessage}>{registerMessage}</div>
                </div>
              )}
            </form>
          )}

          {/* 分割线 */}
          <div className="flex items-center my-6">
            <div className="flex-1 h-px bg-white/30"></div>
            <span className="px-4 text-text-muted text-sm">或</span>
            <div className="flex-1 h-px bg-white/30"></div>
          </div>

          {/* 第三方登录 */}
          <div className="space-y-3">
            <button 
              onClick={() => handleSocialLogin('wechat')}
              className={`${styles.socialBtn} w-full py-3 rounded-lg flex items-center justify-center space-x-3`}
            >
              <i className="fab fa-weixin text-green-500 text-xl"></i>
              <span className="text-text-primary font-medium">微信登录</span>
            </button>
            <button 
              onClick={() => handleSocialLogin('qq')}
              className={`${styles.socialBtn} w-full py-3 rounded-lg flex items-center justify-center space-x-3`}
            >
              <i className="fab fa-qq text-blue-500 text-xl"></i>
              <span className="text-text-primary font-medium">QQ登录</span>
            </button>
            <button 
              onClick={() => handleSocialLogin('apple')}
              className={`${styles.socialBtn} w-full py-3 rounded-lg flex items-center justify-center space-x-3`}
            >
              <i className="fab fa-apple text-gray-800 text-xl"></i>
              <span className="text-text-primary font-medium">Apple ID登录</span>
            </button>
          </div>

          {/* 底部链接 */}
          <div className="text-center mt-6 space-y-2">
            <p className="text-sm text-text-muted">
              登录即表示同意
              <button type="button" className="text-secondary hover:text-accent">《用户协议》</button>
              和
              <button type="button" className="text-secondary hover:text-accent">《隐私政策》</button>
            </p>
          </div>
        </div>
      </div>

      {/* 找回密码弹窗 */}
      {showForgotModal && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setShowForgotModal(false);
            }
          }}
        >
          <div className={`${styles.glassCard} w-full max-w-md rounded-2xl p-6`}>
            <div className="text-center mb-6">
              <i className="fas fa-lock text-3xl text-accent mb-2"></i>
              <h3 className="text-xl font-semibold text-accent">找回密码</h3>
            </div>
            
            <form onSubmit={handleForgotSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="forgot-phone" className="block text-sm font-medium text-text-primary">手机号</label>
                <input 
                  type="tel" 
                  id="forgot-phone" 
                  value={forgotForm.phone}
                  onChange={(e) => setForgotForm({...forgotForm, phone: e.target.value})}
                  className={`${styles.glassInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted`}
                  placeholder="请输入注册手机号" 
                  maxLength={11} 
                  required 
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="forgot-code" className="block text-sm font-medium text-text-primary">验证码</label>
                <div className="flex space-x-3">
                  <input 
                    type="text" 
                    id="forgot-code" 
                    value={forgotForm.code}
                    onChange={(e) => setForgotForm({...forgotForm, code: e.target.value})}
                    className={`${styles.glassInput} flex-1 px-4 py-3 rounded-lg text-text-primary placeholder-text-muted`}
                    placeholder="请输入验证码" 
                    maxLength={6} 
                    required 
                  />
                  <button 
                    type="button" 
                    onClick={() => handleSendCode('forgot')}
                    disabled={forgotCodeCountdown > 0}
                    className={`${styles.btnSecondary} px-4 py-3 rounded-lg font-medium whitespace-nowrap`}
                  >
                    {forgotCodeCountdown > 0 ? `${forgotCodeCountdown}秒后重发` : '发送验证码'}
                  </button>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <button 
                  type="button" 
                  onClick={() => setShowForgotModal(false)}
                  className={`${styles.btnSecondary} flex-1 py-3 rounded-lg font-medium`}
                >
                  取消
                </button>
                <button 
                  type="submit" 
                  className={`${styles.btnPrimary} flex-1 py-3 rounded-lg font-medium`}
                >
                  重置密码
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginPage;

