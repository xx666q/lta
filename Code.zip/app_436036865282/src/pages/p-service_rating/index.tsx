

import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface OrderInfo {
  orderNumber: string;
  serviceType: string;
  serviceTime: string;
  providerName: string;
  providerAvatar: string;
  petName: string;
  petAvatar: string;
}

interface UploadedPhoto {
  id: number;
  src: string;
  name: string;
}

const ServiceRatingPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // 状态管理
  const [currentRating, setCurrentRating] = useState<number>(0);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [reviewContent, setReviewContent] = useState<string>('');
  const [uploadedPhotos, setUploadedPhotos] = useState<UploadedPhoto[]>([]);
  const [showSuccessModal, setShowSuccessModal] = useState<boolean>(false);
  const [orderInfo, setOrderInfo] = useState<OrderInfo>({
    orderNumber: '#20240312001',
    serviceType: '小时陪遛',
    serviceTime: '3月12日 15:00-17:00',
    providerName: '张先生',
    providerAvatar: 'https://s.coze.cn/image/Crh9YR6QM2M/',
    petName: '豆豆',
    petAvatar: 'https://s.coze.cn/image/oTnJzu2GLFQ/'
  });

  // Refs
  const photoInputRef = useRef<HTMLInputElement>(null);
  const ratingTexts = ['', '很差', '较差', '一般', '满意', '非常满意'];
  const aiTagsList = ['耐心', '环境好', '按时喂药', '沟通及时', '责任心强', '专业', '有爱心', '准时', '细心', '服务周到'];

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 服务评价';
    return () => { document.title = originalTitle; };
  }, []);

  // 加载订单信息
  useEffect(() => {
    const orderId = searchParams.get('orderId') || 'order1';
    
    // 模拟订单数据
    const mockOrders: Record<string, OrderInfo> = {
      'order1': {
        orderNumber: '#20240312001',
        serviceType: '小时陪遛',
        serviceTime: '3月12日 15:00-17:00',
        providerName: '张先生',
        providerAvatar: 'https://s.coze.cn/image/Crh9YR6QM2M/',
        petName: '豆豆',
        petAvatar: 'https://s.coze.cn/image/oTnJzu2GLFQ/'
      },
      'order2': {
        orderNumber: '#20240310002',
        serviceType: '日托服务',
        serviceTime: '3月10日 09:00-18:00',
        providerName: '李阿姨',
        providerAvatar: 'https://s.coze.cn/image/HqB8rByMuEY/',
        petName: '咪咪',
        petAvatar: 'https://s.coze.cn/image/sYTW9MtEvxA/'
      }
    };

    const order = mockOrders[orderId] || mockOrders['order1'];
    setOrderInfo(order);
  }, [searchParams]);

  // 星级评分处理
  const handleStarClick = (rating: number) => {
    setCurrentRating(rating);
  };

  // AI标签处理
  const handleTagClick = (tag: string) => {
    setSelectedTags(prevTags => {
      if (prevTags.includes(tag)) {
        return prevTags.filter(t => t !== tag);
      } else {
        return [...prevTags, tag];
      }
    });
  };

  // 照片上传处理
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    files.forEach(file => {
      if (uploadedPhotos.length >= 6) {
        alert('最多只能上传6张照片');
        return;
      }
      
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const photoId = Date.now() + Math.random();
          const newPhoto: UploadedPhoto = {
            id: photoId,
            src: e.target?.result as string,
            name: file.name
          };
          setUploadedPhotos(prev => [...prev, newPhoto]);
        };
        reader.readAsDataURL(file);
      }
    });
    
    // 清空input值，允许重复选择相同文件
    if (photoInputRef.current) {
      photoInputRef.current.value = '';
    }
  };

  // 删除照片
  const handleRemovePhoto = (photoId: number) => {
    setUploadedPhotos(prev => prev.filter(photo => photo.id !== photoId));
  };

  // 提交评价
  const handleSubmitReview = () => {
    if (currentRating === 0) {
      alert('请先选择评分');
      return;
    }
    
    const reviewData = {
      orderId: searchParams.get('orderId') || 'order1',
      rating: currentRating,
      tags: selectedTags,
      content: reviewContent,
      photos: uploadedPhotos
    };
    
    console.log('提交评价数据:', reviewData);
    setShowSuccessModal(true);
  };

  // 关闭弹窗/返回
  const handleCloseModal = () => {
    navigate(-1);
  };

  // 键盘事件处理
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCloseModal();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <div className={styles.pageWrapper}>
      {/* 模态弹窗遮罩 */}
      <div 
        className={`${styles.modalOverlay} fixed inset-0 z-50 flex items-center justify-center p-4`}
        onClick={(e) => e.target === e.currentTarget && handleCloseModal()}
      >
        {/* 评价弹窗 */}
        <div className={`${styles.glassCard} w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl`}>
          {/* 弹窗头部 */}
          <div className="flex items-center justify-between p-6 border-b border-white/10">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
                <i className="fas fa-star text-secondary text-xl"></i>
              </div>
              <div>
                <h2 className="text-xl font-bold text-accent">评价服务</h2>
                <p className="text-text-muted text-sm">您的评价将帮助其他宠物主人做出更好的选择</p>
              </div>
            </div>
            <button 
              onClick={handleCloseModal}
              className="w-8 h-8 flex items-center justify-center text-text-muted hover:text-accent transition-colors"
            >
              <i className="fas fa-times text-lg"></i>
            </button>
          </div>

          {/* 弹窗内容 */}
          <div className="p-6 space-y-6">
            {/* 订单信息 */}
            <div className="bg-white/10 rounded-xl p-4 border border-white/20">
              <h3 className="font-medium text-accent mb-3">订单信息</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-text-secondary">订单号：</span>
                  <span className="text-text-primary font-medium">{orderInfo.orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">服务类型：</span>
                  <span className="text-text-primary">{orderInfo.serviceType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">服务时间：</span>
                  <span className="text-text-primary">{orderInfo.serviceTime}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">服务商：</span>
                  <div className="flex items-center space-x-2">
                    <img 
                      src={orderInfo.providerAvatar}
                      alt={orderInfo.providerName} 
                      className="w-6 h-6 rounded-full"
                    />
                    <span className="text-text-primary">{orderInfo.providerName}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">宠物：</span>
                  <div className="flex items-center space-x-2">
                    <img 
                      src={orderInfo.petAvatar}
                      alt={orderInfo.petName} 
                      className="w-6 h-6 rounded-full"
                    />
                    <span className="text-text-primary">{orderInfo.petName}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 星级评分 */}
            <div>
              <h3 className="font-medium text-accent mb-4">整体评分</h3>
              <div className="flex items-center space-x-4">
                <div className={styles.starRating}>
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <i
                      key={rating}
                      className={`fas fa-star ${styles.star} ${rating <= currentRating ? styles.active : ''}`}
                      onClick={() => handleStarClick(rating)}
                    ></i>
                  ))}
                </div>
                <span className="text-text-muted">
                  {currentRating > 0 ? ratingTexts[currentRating] : '请选择评分'}
                </span>
              </div>
            </div>

            {/* AI智能标签 */}
            <div>
              <h3 className="font-medium text-accent mb-4">选择标签（可选）</h3>
              <p className="text-text-muted text-sm mb-3">基于您的评分，AI为您推荐以下标签</p>
              <div className={styles.aiTags}>
                {aiTagsList.map((tag) => (
                  <span
                    key={tag}
                    className={`${styles.aiTag} ${selectedTags.includes(tag) ? styles.selected : ''}`}
                    style={{
                      opacity: currentRating > 0 ? '1' : '0.5',
                      pointerEvents: currentRating > 0 ? 'auto' : 'none'
                    }}
                    onClick={() => handleTagClick(tag)}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* 评价内容 */}
            <div>
              <h3 className="font-medium text-accent mb-4">详细评价</h3>
              <textarea
                value={reviewContent}
                onChange={(e) => setReviewContent(e.target.value)}
                placeholder="分享您的托管体验，帮助其他宠物主人了解服务质量..."
                className="w-full h-32 px-4 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50 resize-none"
                maxLength={500}
              />
              <div className="flex justify-between items-center mt-2">
                <span className="text-text-muted text-sm">详细的评价能帮助其他宠物主人做出更好的选择</span>
                <span className={`text-sm ${reviewContent.length > 450 ? 'text-yellow-600' : 'text-text-muted'}`}>
                  {reviewContent.length}/500
                </span>
              </div>
            </div>

            {/* 照片上传 */}
            <div>
              <h3 className="font-medium text-accent mb-4">上传照片（可选）</h3>
              <p className="text-text-muted text-sm mb-3">分享托管过程中的精彩瞬间</p>
              
              {/* 上传区域 */}
              <div 
                className={`${styles.photoUploadArea} rounded-xl p-6 text-center cursor-pointer`}
                onClick={() => photoInputRef.current?.click()}
              >
                <input
                  ref={photoInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handlePhotoUpload}
                />
                <div className="space-y-2">
                  <i className="fas fa-cloud-upload-alt text-3xl text-text-muted"></i>
                  <p className="text-text-secondary">点击上传照片</p>
                  <p className="text-text-muted text-sm">支持 JPG、PNG 格式，最多上传6张</p>
                </div>
              </div>

              {/* 照片预览 */}
              {uploadedPhotos.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                  {uploadedPhotos.map((photo) => (
                    <div key={photo.id} className={styles.photoPreview}>
                      <img 
                        src={photo.src} 
                        alt={photo.name} 
                        className="w-full h-24 object-cover rounded-lg"
                      />
                      <button 
                        className={styles.removePhoto}
                        onClick={() => handleRemovePhoto(photo.id)}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* 弹窗底部 */}
          <div className="flex items-center justify-end space-x-3 p-6 border-t border-white/10">
            <button 
              onClick={handleCloseModal}
              className={`${styles.btnSecondary} px-6 py-2 rounded-lg font-medium`}
            >
              取消
            </button>
            <button 
              onClick={handleSubmitReview}
              disabled={currentRating === 0}
              className={`${styles.btnPrimary} px-8 py-2 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              提交评价
            </button>
          </div>
        </div>
      </div>

      {/* 成功提示弹窗 */}
      {showSuccessModal && (
        <div 
          className={`${styles.modalOverlay} fixed inset-0 z-60 flex items-center justify-center p-4`}
          onClick={(e) => e.target === e.currentTarget && handleCloseModal()}
        >
          <div className={`${styles.glassCard} w-full max-w-md rounded-2xl p-6 text-center`}>
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-check text-green-500 text-2xl"></i>
            </div>
            <h3 className="text-lg font-bold text-accent mb-2">评价提交成功！</h3>
            <p className="text-text-secondary mb-6">感谢您的评价，这将帮助其他宠物主人做出更好的选择</p>
            <button 
              onClick={handleCloseModal}
              className={`${styles.btnPrimary} w-full py-2 rounded-lg font-medium`}
            >
              确定
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceRatingPage;

