

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface WithdrawalRecord {
  id: string;
  amount: string;
  applyTime: string;
  arrivalTime: string;
  status: 'completed' | 'pending' | 'rejected';
  statusText: string;
}

const WithdrawalPage: React.FC = () => {
  const navigate = useNavigate();
  const [isWithdrawalModalVisible, setIsWithdrawalModalVisible] = useState(false);
  const [withdrawalAmount, setWithdrawalAmount] = useState('');
  const [selectedBankAccount, setSelectedBankAccount] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const withdrawalRecords: WithdrawalRecord[] = [
    {
      id: '#WD20240315001',
      amount: '¥1,200.00',
      applyTime: '2024-03-15 14:30',
      arrivalTime: '2024-03-16 10:15',
      status: 'completed',
      statusText: '已完成'
    },
    {
      id: '#WD20240310002',
      amount: '¥850.00',
      applyTime: '2024-03-10 09:45',
      arrivalTime: '2024-03-11 15:20',
      status: 'completed',
      statusText: '已完成'
    },
    {
      id: '#WD20240305001',
      amount: '¥2,100.00',
      applyTime: '2024-03-05 16:20',
      arrivalTime: '-',
      status: 'pending',
      statusText: '申请中'
    },
    {
      id: '#WD20240228001',
      amount: '¥680.00',
      applyTime: '2024-02-28 11:15',
      arrivalTime: '2024-02-29 14:30',
      status: 'completed',
      statusText: '已完成'
    }
  ];

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 收入提现';
    return () => { document.title = originalTitle; };
  }, []);

  const handleApplyWithdrawal = () => {
    setIsWithdrawalModalVisible(true);
  };

  const closeModal = () => {
    setIsWithdrawalModalVisible(false);
    setWithdrawalAmount('');
    setSelectedBankAccount('');
  };

  const handleConfirmWithdrawal = () => {
    if (!withdrawalAmount || parseFloat(withdrawalAmount) <= 0) {
      alert('请输入有效的提现金额');
      return;
    }
    
    if (!selectedBankAccount) {
      alert('请选择收款账户');
      return;
    }
    
    alert(`提现申请已提交，金额：¥${withdrawalAmount}，预计T+1个工作日到账`);
    closeModal();
  };

  const handleExportBill = () => {
    console.log('需要调用第三方接口实现账单导出功能');
    alert('账单导出功能开发中...');
  };

  const handleStatusFilterChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setStatusFilter(event.target.value);
  };

  const handleViewDetail = (recordId: string) => {
    alert(`查看提现详情：${recordId}`);
    console.log('查看提现详情:', recordId);
  };

  const handleAiCustomerService = () => {
    console.log('需要调用第三方接口实现AI客服功能');
    alert('AI客服功能开发中...');
  };

  const handleSearchKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      const searchTerm = (event.target as HTMLInputElement).value;
      console.log('搜索:', searchTerm);
    }
  };

  const handleAmountInput = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(event.target.value);
    const maxAmount = 2850;
    
    if (value > maxAmount) {
      setWithdrawalAmount(maxAmount.toString());
    } else {
      setWithdrawalAmount(event.target.value);
    }
  };

  const filteredRecords = statusFilter 
    ? withdrawalRecords.filter(record => record.status === statusFilter)
    : withdrawalRecords;

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'px-2 py-1 bg-green-500/20 text-green-600 text-xs rounded-full';
      case 'pending':
        return 'px-2 py-1 bg-yellow-500/20 text-yellow-600 text-xs rounded-full';
      case 'rejected':
        return 'px-2 py-1 bg-red-500/20 text-red-600 text-xs rounded-full';
      default:
        return '';
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
                onKeyPress={handleSearchKeyPress}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img src="https://s.coze.cn/image/UJbQQPCvid0/" 
                 alt="用户头像" className="w-8 h-8 rounded-full" />
            <span className="text-text-primary font-medium hidden md:block">李阿姨</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link to="/provider-dashboard" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link to="/qualification-audit" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-certificate text-lg"></i>
              <span className="font-medium">资质审核</span>
            </Link>
            <Link to="/service-publish" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-plus-circle text-lg"></i>
              <span className="font-medium">服务发布</span>
            </Link>
            <Link to="/order-hall" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-bell text-lg"></i>
              <span className="font-medium">接单大厅</span>
            </Link>
            <Link to="/provider-order-manage" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-list-alt text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <div className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-money-bill-wave text-lg"></i>
              <span className="font-medium">收入提现</span>
            </div>
            <Link to="/growth-system" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-trophy text-lg"></i>
              <span className="font-medium">成长体系</span>
            </Link>
            <Link to="/user-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">收入提现</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">收入提现</h1>
                <p className="text-text-secondary mt-1">管理您的收入和提现记录</p>
              </div>
            </div>
          </header>

          {/* 收入概览区 */}
          <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">可提现余额</p>
                  <p className="text-3xl font-bold text-accent mt-2">¥2,850.00</p>
                  <p className="text-green-600 text-sm mt-1">
                    <i className="fas fa-arrow-up"></i> +¥350 今日收入
                  </p>
                </div>
                <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-wallet text-secondary text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">累计收入</p>
                  <p className="text-3xl font-bold text-accent mt-2">¥15,680.00</p>
                  <p className="text-blue-600 text-sm mt-1">
                    <i className="fas fa-chart-line"></i> 本月收入 ¥4,200
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-chart-bar text-green-500 text-xl"></i>
                </div>
              </div>
            </div>

            <div className={`${styles.dataCard} p-6 rounded-2xl`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-text-muted text-sm font-medium">平台抽成</p>
                  <p className="text-3xl font-bold text-accent mt-2">10%</p>
                  <p className="text-purple-600 text-sm mt-1">
                    <i className="fas fa-info-circle"></i> 行业标准费率
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                  <i className="fas fa-percentage text-purple-500 text-xl"></i>
                </div>
              </div>
            </div>
          </section>

          {/* 提现操作区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">提现操作</h2>
              <div className="text-text-muted text-sm">
                <i className="fas fa-clock mr-1"></i>
                T+1到账，支持各大银行
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={handleApplyWithdrawal}
                className={`${styles.btnPrimary} px-8 py-3 rounded-xl font-medium hover:shadow-lg transition-all`}
              >
                <i className="fas fa-plus mr-2"></i>
                申请提现
              </button>
              <button 
                onClick={handleExportBill}
                className={`${styles.btnSecondary} px-8 py-3 rounded-xl font-medium hover:shadow-lg transition-all`}
              >
                <i className="fas fa-download mr-2"></i>
                导出账单
              </button>
            </div>
          </section>

          {/* 提现记录列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">提现记录</h2>
              <div className="flex items-center space-x-2">
                <select 
                  value={statusFilter}
                  onChange={handleStatusFilterChange}
                  className="px-3 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary text-sm focus:outline-none focus:ring-2 focus:ring-secondary/50"
                >
                  <option value="">全部状态</option>
                  <option value="pending">申请中</option>
                  <option value="completed">已完成</option>
                  <option value="rejected">已拒绝</option>
                </select>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className={`w-full ${styles.tableGlass} rounded-xl overflow-hidden`}>
                <thead className="bg-white/10">
                  <tr>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">提现单号</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">提现金额</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">申请时间</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">到账时间</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">状态</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredRecords.map((record, index) => (
                    <tr key={record.id} className={`${styles.tableRow} ${index < filteredRecords.length - 1 ? 'border-b border-white/10' : ''}`}>
                      <td className="px-4 py-3 text-text-primary font-medium">{record.id}</td>
                      <td className="px-4 py-3 text-accent font-semibold">{record.amount}</td>
                      <td className="px-4 py-3 text-text-secondary">{record.applyTime}</td>
                      <td className="px-4 py-3 text-text-secondary">{record.arrivalTime}</td>
                      <td className="px-4 py-3">
                        <span className={getStatusBadgeClass(record.status)}>{record.statusText}</span>
                      </td>
                      <td className="px-4 py-3">
                        {record.status === 'pending' ? (
                          <button className="text-text-muted text-sm">处理中...</button>
                        ) : (
                          <button 
                            onClick={() => handleViewDetail(record.id)}
                            className="text-secondary hover:text-accent text-sm font-medium"
                          >
                            查看详情
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* 分页控件 */}
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-text-muted">
                显示 1-4 条，共 12 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-secondary text-sm hover:bg-white/30 transition-colors">
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button className="px-3 py-1 bg-secondary text-white rounded-lg text-sm">1</button>
                <button className="px-3 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-secondary text-sm hover:bg-white/30 transition-colors">2</button>
                <button className="px-3 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-secondary text-sm hover:bg-white/30 transition-colors">3</button>
                <button className="px-3 py-1 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-secondary text-sm hover:bg-white/30 transition-colors">
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* 申请提现模态弹窗 */}
      {isWithdrawalModalVisible && (
        <div 
          className={`${styles.modalOverlay} fixed inset-0 z-50 flex items-center justify-center p-4`}
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              closeModal();
            }
          }}
        >
          <div className={`${styles.modalContent} w-full max-w-md rounded-2xl p-6`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-accent">申请提现</h3>
              <button 
                onClick={closeModal}
                className="text-text-muted hover:text-accent transition-colors"
              >
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="bg-secondary/10 p-3 rounded-lg">
                <p className="text-sm text-text-muted">可提现余额</p>
                <p className="text-xl font-bold text-accent">¥2,850.00</p>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="withdrawal-amount" className="block text-sm font-medium text-text-primary mb-2">提现金额</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted">¥</span>
                    <input 
                      type="number" 
                      id="withdrawal-amount"
                      value={withdrawalAmount}
                      onChange={handleAmountInput}
                      className="w-full pl-8 pr-4 py-3 bg-white/50 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-secondary/50"
                      placeholder="请输入提现金额" 
                      min="1" 
                      max="2850" 
                      step="0.01"
                    />
                  </div>
                  <p className="text-xs text-text-muted mt-1">最低提现金额：¥1.00，最高：¥2,850.00</p>
                </div>
                
                <div>
                  <label htmlFor="bank-account" className="block text-sm font-medium text-text-primary mb-2">收款账户</label>
                  <select 
                    id="bank-account"
                    value={selectedBankAccount}
                    onChange={(e) => setSelectedBankAccount(e.target.value)}
                    className="w-full px-4 py-3 bg-white/50 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-secondary/50"
                  >
                    <option value="">请选择收款账户</option>
                    <option value="bank1">招商银行 ****1234</option>
                    <option value="bank2">工商银行 ****5678</option>
                  </select>
                </div>
                
                <div className="bg-blue-500/10 p-3 rounded-lg border border-blue-500/20">
                  <div className="flex items-start space-x-2">
                    <i className="fas fa-info-circle text-blue-500 mt-0.5"></i>
                    <div className="text-sm text-blue-600">
                      <p>提现说明：</p>
                      <ul className="mt-1 space-y-1">
                        <li>• 提现申请将在T+1个工作日内到账</li>
                        <li>• 平台将收取10%的服务费</li>
                        <li>• 请确保收款账户信息正确</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button 
                onClick={closeModal}
                className="flex-1 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-secondary font-medium hover:bg-white/30 transition-colors"
              >
                取消
              </button>
              <button 
                onClick={handleConfirmWithdrawal}
                className={`flex-1 ${styles.btnPrimary} py-3 rounded-lg font-medium`}
              >
                确认提现
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiCustomerService}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default WithdrawalPage;

