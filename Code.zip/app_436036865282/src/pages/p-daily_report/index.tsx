

import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface OrderInfo {
  orderNumber: string;
  petName: string;
  petAvatar: string;
  reportDate: string;
}

interface PhotoData {
  src: string;
  name: string;
}

const DailyReportPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // 表单状态
  const [feedingLog, setFeedingLog] = useState('上午9:00 - 狗粮 200g，精神状态良好\n中午12:00 - 零食小饼干 2块\n下午16:00 - 狗粮 150g，喝水正常\n晚上19:00 - 水果小番茄 3个');
  const [toiletLog, setToiletLog] = useState('上午10:30 - 大便1次，成型正常\n下午14:00 - 小便1次，正常\n下午17:30 - 大便1次，成型正常\n晚上20:00 - 小便1次，正常');
  const [exerciseLog, setExerciseLog] = useState('上午11:00 - 户外散步 30分钟，活泼好动\n下午15:00 - 室内玩耍 20分钟，与玩具互动良好\n傍晚18:00 - 户外散步 25分钟，遇到其他小狗友好互动');
  
  // UI状态
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [orderInfo, setOrderInfo] = useState<OrderInfo>({
    orderNumber: '#20240315001',
    petName: '豆豆',
    petAvatar: 'https://s.coze.cn/image/0CWcJXBkZnY/',
    reportDate: '2024年3月15日'
  });
  
  // 照片状态
  const [photos, setPhotos] = useState<PhotoData[]>([
    { src: 'https://s.coze.cn/image/cNIl1IBQBZQ/', name: '豆豆吃饭' },
    { src: 'https://s.coze.cn/image/vucLCUrbY98/', name: '豆豆散步' },
    { src: 'https://s.coze.cn/image/qAIaWer8HSA/', name: '豆豆玩耍' }
  ]);
  
  // Refs
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 填写托管日报';
    return () => { document.title = originalTitle; };
  }, []);

  // 加载订单信息
  useEffect(() => {
    const orderId = searchParams.get('orderId');
    if (orderId) {
      loadOrderInfo(orderId);
    }
  }, [searchParams]);

  // 从localStorage加载表单数据
  useEffect(() => {
    const savedFeedingLog = localStorage.getItem('daily_report_feeding-log');
    const savedToiletLog = localStorage.getItem('daily_report_toilet-log');
    const savedExerciseLog = localStorage.getItem('daily_report_exercise-log');
    
    if (savedFeedingLog) setFeedingLog(savedFeedingLog);
    if (savedToiletLog) setToiletLog(savedToiletLog);
    if (savedExerciseLog) setExerciseLog(savedExerciseLog);
  }, []);

  // 保存表单数据到localStorage
  const handleFormInputChange = (field: string, value: string) => {
    switch (field) {
      case 'feeding-log':
        setFeedingLog(value);
        localStorage.setItem('daily_report_feeding-log', value);
        break;
      case 'toilet-log':
        setToiletLog(value);
        localStorage.setItem('daily_report_toilet-log', value);
        break;
      case 'exercise-log':
        setExerciseLog(value);
        localStorage.setItem('daily_report_exercise-log', value);
        break;
    }
  };

  // 模拟加载订单信息
  const loadOrderInfo = (orderId: string) => {
    const mockOrders: Record<string, OrderInfo> = {
      'order1': { 
        orderNumber: '#20240315001', 
        petName: '豆豆', 
        petAvatar: 'https://s.coze.cn/image/4vUCsW0dqw8/',
        reportDate: '2024年3月15日'
      },
      'order2': { 
        orderNumber: '#20240315002', 
        petName: '咪咪', 
        petAvatar: 'https://s.coze.cn/image/L6hKUNaKm7A/',
        reportDate: '2024年3月15日'
      }
    };
    
    const order = mockOrders[orderId] || mockOrders['order1'];
    setOrderInfo(order);
  };

  // 关闭弹窗
  const closeModal = () => {
    navigate('/provider-order-manage');
  };

  // 处理键盘事件
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        closeModal();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // 处理文件上传
  const handleFiles = (files: FileList) => {
    const maxPhotos = 6;
    const remainingSlots = maxPhotos - photos.length;
    
    if (remainingSlots <= 0) {
      alert('最多只能上传6张照片');
      return;
    }

    for (let i = 0; i < Math.min(files.length, remainingSlots); i++) {
      const file = files[i];
      
      if (!file.type.startsWith('image/')) {
        alert('请选择图片文件');
        continue;
      }

      if (file.size > 5 * 1024 * 1024) {
        alert('图片大小不能超过5MB');
        continue;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setPhotos(prev => [...prev, { src: e.target?.result as string, name: file.name }]);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // 点击上传区域
  const handleUploadAreaClick = () => {
    fileInputRef.current?.click();
  };

  // 文件选择事件
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files);
    }
  };

  // 拖拽事件
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files) {
      handleFiles(e.dataTransfer.files);
    }
  };

  // 删除照片
  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  // 表单提交
  const handleSubmit = () => {
    if (!feedingLog.trim() || !toiletLog.trim() || !exerciseLog.trim()) {
      alert('请填写完整的托管记录');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      setShowSuccessToast(true);
      
      // 清除本地存储
      localStorage.removeItem('daily_report_feeding-log');
      localStorage.removeItem('daily_report_toilet-log');
      localStorage.removeItem('daily_report_exercise-log');
      
      setTimeout(() => {
        setShowSuccessToast(false);
        setTimeout(() => {
          closeModal();
        }, 300);
      }, 2000);
    }, 1500);
  };

  // 点击遮罩关闭
  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      closeModal();
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 模态弹窗遮罩 */}
      <div 
        className={`${styles.modalOverlay} fixed inset-0 z-50 flex items-center justify-center p-4`}
        onClick={handleOverlayClick}
      >
        {/* 模态弹窗主体 */}
        <div className={`${styles.glassModal} ${styles.modalEnter} w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl`}>
          {/* 弹窗头部 */}
          <div className="flex items-center justify-between p-6 border-b border-white/20">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
                <i className="fas fa-file-alt text-secondary text-lg"></i>
              </div>
              <div>
                <h2 className="text-xl font-bold text-accent">填写托管日报</h2>
                <p className="text-text-muted text-sm">记录宠物的美好一天</p>
              </div>
            </div>
            <button 
              onClick={closeModal}
              className="p-2 text-text-muted hover:text-accent transition-colors rounded-lg hover:bg-white/10"
            >
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>

          {/* 弹窗内容 */}
          <div className="p-6">
            {/* 订单信息 */}
            <div className={`${styles.glassModal} p-4 rounded-xl mb-6`}>
              <h3 className="text-lg font-semibold text-accent mb-3">订单信息</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <i className="fas fa-hashtag text-secondary"></i>
                  <span className="text-text-primary font-medium">订单号:</span>
                  <span className="text-text-secondary">{orderInfo.orderNumber}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-paw text-secondary"></i>
                  <span className="text-text-primary font-medium">宠物:</span>
                  <div className="flex items-center space-x-2">
                    <img 
                      src={orderInfo.petAvatar}
                      alt="宠物头像" 
                      className="w-6 h-6 rounded-full"
                    />
                    <span className="text-text-secondary">{orderInfo.petName}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-calendar text-secondary"></i>
                  <span className="text-text-primary font-medium">日期:</span>
                  <span className="text-text-secondary">{orderInfo.reportDate}</span>
                </div>
              </div>
            </div>

            {/* 托管日报表单 */}
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              {/* 喂食记录 */}
              <div className="space-y-2">
                <label htmlFor="feeding-log" className="block text-sm font-medium text-accent">
                  <i className="fas fa-utensils text-secondary mr-2"></i>喂食记录
                </label>
                <textarea 
                  id="feeding-log" 
                  rows={4}
                  value={feedingLog}
                  onChange={(e) => handleFormInputChange('feeding-log', e.target.value)}
                  className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted resize-none`}
                  placeholder="请详细记录今天的喂食情况，包括喂食时间、食物种类、食量等..."
                />
              </div>

              {/* 排便记录 */}
              <div className="space-y-2">
                <label htmlFor="toilet-log" className="block text-sm font-medium text-accent">
                  <i className="fas fa-toilet-paper text-secondary mr-2"></i>排便记录
                </label>
                <textarea 
                  id="toilet-log" 
                  rows={4}
                  value={toiletLog}
                  onChange={(e) => handleFormInputChange('toilet-log', e.target.value)}
                  className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted resize-none`}
                  placeholder="请记录今天的排便情况，包括次数、状态、是否正常等..."
                />
              </div>

              {/* 运动记录 */}
              <div className="space-y-2">
                <label htmlFor="exercise-log" className="block text-sm font-medium text-accent">
                  <i className="fas fa-running text-secondary mr-2"></i>运动记录
                </label>
                <textarea 
                  id="exercise-log" 
                  rows={4}
                  value={exerciseLog}
                  onChange={(e) => handleFormInputChange('exercise-log', e.target.value)}
                  className={`${styles.formInput} w-full px-4 py-3 rounded-lg text-text-primary placeholder-text-muted resize-none`}
                  placeholder="请记录今天的运动情况，包括运动时间、项目、宠物状态等..."
                />
              </div>

              {/* 照片上传 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-accent">
                  <i className="fas fa-camera text-secondary mr-2"></i>今日照片
                  <span className="text-text-muted text-xs ml-2">(最多上传6张照片)</span>
                </label>
                
                {/* 上传区域 */}
                <div 
                  onClick={handleUploadAreaClick}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`${styles.uploadArea} ${isDragOver ? styles.uploadAreaDragover : ''} p-6 rounded-xl text-center cursor-pointer`}
                >
                  <input 
                    ref={fileInputRef}
                    type="file" 
                    multiple 
                    accept="image/*" 
                    onChange={handleFileInputChange}
                    className="hidden"
                  />
                  <i className="fas fa-cloud-upload-alt text-3xl text-text-muted mb-3"></i>
                  <p className="text-text-primary font-medium mb-1">点击或拖拽上传照片</p>
                  <p className="text-text-muted text-sm">支持 JPG、PNG 格式，单张不超过 5MB</p>
                </div>

                {/* 照片预览区域 */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-4">
                  {photos.map((photo, index) => (
                    <div key={index} className={styles.photoPreview}>
                      <img 
                        src={photo.src}
                        alt={photo.name} 
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      <button 
                        className={styles.removeBtn}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemovePhoto(index);
                        }}
                      >
                        <i className="fas fa-times text-sm"></i>
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI智能建议 */}
              <div className={`${styles.glassModal} p-4 rounded-xl`}>
                <div className="flex items-center space-x-2 mb-3">
                  <i className="fas fa-robot text-secondary"></i>
                  <span className="text-sm font-medium text-accent">AI智能建议</span>
                </div>
                <div className="bg-gradient-to-r from-secondary/10 to-accent/10 p-3 rounded-lg border border-secondary/20">
                  <p className="text-text-secondary text-sm">
                    <i className="fas fa-lightbulb text-secondary mr-2"></i>
                    根据您的记录，豆豆今天状态非常好！建议继续保持这样的喂食和运动节奏。
                  </p>
                </div>
              </div>
            </form>
          </div>

          {/* 弹窗底部 */}
          <div className="flex items-center justify-end space-x-4 p-6 border-t border-white/20">
            <button 
              onClick={closeModal}
              className={`${styles.btnSecondary} px-6 py-3 rounded-lg font-medium`}
            >
              <i className="fas fa-times mr-2"></i>取消
            </button>
            <button 
              onClick={handleSubmit}
              disabled={isSubmitting}
              className={`${styles.btnPrimary} px-6 py-3 rounded-lg font-medium`}
            >
              {isSubmitting ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>提交中...
                </>
              ) : (
                <>
                  <i className="fas fa-paper-plane mr-2"></i>提交日报
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 成功提示弹窗 */}
      <div className={`fixed top-4 right-4 ${styles.glassModal} p-4 rounded-xl shadow-lg z-60 ${styles.successToast} ${showSuccessToast ? styles.successToastVisible : ''}`}>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center">
            <i className="fas fa-check text-green-500"></i>
          </div>
          <div>
            <p className="text-accent font-medium">提交成功</p>
            <p className="text-text-muted text-sm">托管日报已成功提交</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DailyReportPage;

