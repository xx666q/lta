

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.css';

interface BadgeData {
  title: string;
  description: string;
  icon: string;
  iconColor: string;
  bgColor: string;
  requirements: string[];
}

const GrowthSystemPage: React.FC = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedBadge, setSelectedBadge] = useState<BadgeData | null>(null);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 成长体系';
    return () => { document.title = originalTitle; };
  }, []);

  // 徽章数据
  const badgeData: Record<string, BadgeData> = {
    newbie: {
      title: '新手托管师',
      description: '完成首次托管服务，开启您的托管师之旅',
      icon: 'fas fa-seedling',
      iconColor: 'text-secondary',
      bgColor: 'bg-secondary/20',
      requirements: [
        '完成至少1个托管订单',
        '服务评价达到4星以上'
      ]
    },
    gold: {
      title: '金牌托管师',
      description: '连续30天无违规记录，服务质量优秀，获得平台认证',
      icon: 'fas fa-trophy',
      iconColor: 'text-yellow-500',
      bgColor: 'bg-yellow-500/20',
      requirements: [
        '连续30天无违规记录',
        '好评率保持在95%以上',
        '完成至少20个托管订单'
      ]
    },
    fast: {
      title: '闪电响应',
      description: '平均响应时间小于5分钟，为宠物主人提供快速服务',
      icon: 'fas fa-bolt',
      iconColor: 'text-blue-500',
      bgColor: 'bg-blue-500/20',
      requirements: [
        '连续7天平均响应时间<5分钟',
        '接单率达到80%以上'
      ]
    },
    caring: {
      title: '爱心托管师',
      description: '获得50个5星好评，用爱心和专业赢得宠物主人的信任',
      icon: 'fas fa-heart',
      iconColor: 'text-pink-500',
      bgColor: 'bg-pink-500/20',
      requirements: [
        '累计获得50个5星好评',
        '无任何投诉记录'
      ]
    },
    experienced: {
      title: '资深托管师',
      description: '完成100个托管订单，经验丰富，技术娴熟',
      icon: 'fas fa-star',
      iconColor: 'text-purple-500',
      bgColor: 'bg-purple-500/20',
      requirements: [
        '累计完成100个托管订单',
        '服务时长超过3个月'
      ]
    },
    crown: {
      title: '皇冠托管师',
      description: '连续100天无差评，是平台最高荣誉的托管师',
      icon: 'fas fa-crown',
      iconColor: 'text-yellow-500',
      bgColor: 'bg-yellow-500/20',
      requirements: [
        '连续100天无差评记录',
        '好评率保持在98%以上',
        '完成至少50个托管订单'
      ]
    },
    specialist: {
      title: '专业托管师',
      description: '通过专业技能认证，在特定领域有专业知识',
      icon: 'fas fa-graduation-cap',
      iconColor: 'text-blue-600',
      bgColor: 'bg-blue-600/20',
      requirements: [
        '完成宠物护理专业培训',
        '通过平台技能认证考试',
        '获得相关专业证书'
      ]
    },
    popular: {
      title: '人气托管师',
      description: '月接单量排名前10%，深受宠物主人喜爱',
      icon: 'fas fa-fire',
      iconColor: 'text-red-500',
      bgColor: 'bg-red-500/20',
      requirements: [
        '连续3个月月接单量前10%',
        '收藏数排名前20%',
        '复购率达到60%以上'
      ]
    }
  };

  const handleBadgeClick = (badgeId: string) => {
    const badge = badgeData[badgeId];
    if (badge) {
      setSelectedBadge(badge);
      setIsModalVisible(true);
    }
  };

  const handleCloseModal = () => {
    setIsModalVisible(false);
    setSelectedBadge(null);
  };

  const handleModalOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleCloseModal();
    }
  };

  const handleAiCustomerServiceClick = () => {
    console.log('打开AI客服');
    alert('AI客服功能开发中...');
  };

  const handleNotificationClick = () => {
    console.log('查看通知');
  };

  const handleUserMenuClick = () => {
    console.log('打开用户菜单');
  };

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const searchTerm = (e.target as HTMLInputElement).value;
      console.log('搜索:', searchTerm);
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
                onKeyPress={handleSearchKeyPress}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            className="relative p-2 text-text-secondary hover:text-accent transition-colors"
            onClick={handleNotificationClick}
          >
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div 
            className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors"
            onClick={handleUserMenuClick}
          >
            <img 
              src="https://s.coze.cn/image/M_fN8hiDdI8/" 
              alt="李阿姨头像" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-text-primary font-medium hidden md:block">李阿姨</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link 
              to="/provider-dashboard" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link 
              to="/qualification-audit" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-certificate text-lg"></i>
              <span className="font-medium">资质审核</span>
            </Link>
            <Link 
              to="/service-publish" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-plus-circle text-lg"></i>
              <span className="font-medium">服务发布</span>
            </Link>
            <Link 
              to="/order-hall" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-bell text-lg"></i>
              <span className="font-medium">接单大厅</span>
            </Link>
            <Link 
              to="/provider-order-manage" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-list-alt text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <Link 
              to="/withdrawal" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-money-bill-wave text-lg"></i>
              <span className="font-medium">收入提现</span>
            </Link>
            <Link 
              to="/growth-system" 
              className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}
            >
              <i className="fas fa-trophy text-lg"></i>
              <span className="font-medium">成长体系</span>
            </Link>
            <Link 
              to="/user-profile" 
              className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}
            >
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">成长体系</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">成长体系</h1>
                <p className="text-text-secondary mt-1">查看您的托管师成长数据和获得的徽章</p>
              </div>
            </div>
          </header>

          {/* 综合评分区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-6">综合评分</h2>
            
            <div className="flex items-center justify-between mb-6">
              <div className="text-center">
                <div className="relative inline-block">
                  <div className={styles.achievementBadge}>
                    <span className="text-3xl font-bold">4.8</span>
                  </div>
                  <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                    <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">金牌托管师</span>
                  </div>
                </div>
                <p className="text-text-muted mt-4">您的综合评分在所有托管师中排名前10%</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-1 ml-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent mb-2">98%</div>
                  <div className={`${styles.progressBar} h-2 mb-2`}>
                    <div className={styles.progressFill} style={{width: '98%'}}></div>
                  </div>
                  <p className="text-text-secondary text-sm">好评率</p>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent mb-2">156</div>
                  <div className={`${styles.progressBar} h-2 mb-2`}>
                    <div className={styles.progressFill} style={{width: '85%'}}></div>
                  </div>
                  <p className="text-text-secondary text-sm">接单量</p>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent mb-2">2分钟</div>
                  <div className={`${styles.progressBar} h-2 mb-2`}>
                    <div className={styles.progressFill} style={{width: '92%'}}></div>
                  </div>
                  <p className="text-text-secondary text-sm">响应速度</p>
                </div>
              </div>
            </div>
          </section>

          {/* 成长进度区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-6">成长进度</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className={`${styles.dataCard} p-4 rounded-xl`}>
                <h3 className="font-medium text-accent mb-4">等级提升进度</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-text-secondary">当前等级</span>
                    <span className="font-medium text-accent">金牌托管师 Lv.3</span>
                  </div>
                  <div className={`${styles.progressBar} h-3`}>
                    <div className={styles.progressFill} style={{width: '75%'}}></div>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-text-muted">750/1000 经验值</span>
                    <span className="text-secondary">距离下一级还需 250 经验</span>
                  </div>
                </div>
              </div>
              
              <div className={`${styles.dataCard} p-4 rounded-xl`}>
                <h3 className="font-medium text-accent mb-4">下一个徽章</h3>
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center">
                    <i className="fas fa-crown text-yellow-500 text-2xl"></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-accent">皇冠托管师</h4>
                    <p className="text-text-secondary text-sm mb-2">连续100天无差评</p>
                    <div className={`${styles.progressBar} h-2`}>
                      <div className={`${styles.progressFill} bg-yellow-500`} style={{width: '78%'}}></div>
                    </div>
                    <p className="text-text-muted text-xs mt-1">78/100 天</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* 已获得徽章区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-accent">我的徽章</h2>
              <span className="text-text-muted text-sm">已获得 5/8 个徽章</span>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {/* 已获得徽章 */}
              <div 
                className={`${styles.badgeCard} ${styles.badgeCardEarned} p-4 rounded-xl text-center`}
                onClick={() => handleBadgeClick('newbie')}
              >
                <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-seedling text-secondary text-2xl"></i>
                </div>
                <h3 className="font-medium text-accent text-sm mb-1">新手托管师</h3>
                <p className="text-text-muted text-xs">完成首次托管服务</p>
              </div>
              
              <div 
                className={`${styles.badgeCard} ${styles.badgeCardEarned} p-4 rounded-xl text-center`}
                onClick={() => handleBadgeClick('gold')}
              >
                <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-trophy text-yellow-500 text-2xl"></i>
                </div>
                <h3 className="font-medium text-accent text-sm mb-1">金牌托管师</h3>
                <p className="text-text-muted text-xs">连续30天无违规</p>
              </div>
              
              <div 
                className={`${styles.badgeCard} ${styles.badgeCardEarned} p-4 rounded-xl text-center`}
                onClick={() => handleBadgeClick('fast')}
              >
                <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-bolt text-blue-500 text-2xl"></i>
                </div>
                <h3 className="font-medium text-accent text-sm mb-1">闪电响应</h3>
                <p className="text-text-muted text-xs">平均响应时间{'<'}5分钟</p>
              </div>
              
              <div 
                className={`${styles.badgeCard} ${styles.badgeCardEarned} p-4 rounded-xl text-center`}
                onClick={() => handleBadgeClick('caring')}
              >
                <div className="w-16 h-16 bg-pink-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-heart text-pink-500 text-2xl"></i>
                </div>
                <h3 className="font-medium text-accent text-sm mb-1">爱心托管师</h3>
                <p className="text-text-muted text-xs">获得50个5星好评</p>
              </div>
              
              <div 
                className={`${styles.badgeCard} ${styles.badgeCardEarned} p-4 rounded-xl text-center`}
                onClick={() => handleBadgeClick('experienced')}
              >
                <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-star text-purple-500 text-2xl"></i>
                </div>
                <h3 className="font-medium text-accent text-sm mb-1">资深托管师</h3>
                <p className="text-text-muted text-xs">完成100个托管订单</p>
              </div>
              
              {/* 未获得徽章 */}
              <div 
                className={`${styles.badgeCard} ${styles.badgeCardLocked} p-4 rounded-xl text-center`}
                onClick={() => handleBadgeClick('crown')}
              >
                <div className="w-16 h-16 bg-gray-400/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-crown text-gray-400 text-2xl"></i>
                </div>
                <h3 className="font-medium text-text-muted text-sm mb-1">皇冠托管师</h3>
                <p className="text-text-muted text-xs">连续100天无差评</p>
              </div>
              
              <div 
                className={`${styles.badgeCard} ${styles.badgeCardLocked} p-4 rounded-xl text-center`}
                onClick={() => handleBadgeClick('specialist')}
              >
                <div className="w-16 h-16 bg-gray-400/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-graduation-cap text-gray-400 text-2xl"></i>
                </div>
                <h3 className="font-medium text-text-muted text-sm mb-1">专业托管师</h3>
                <p className="text-text-muted text-xs">通过专业技能认证</p>
              </div>
              
              <div 
                className={`${styles.badgeCard} ${styles.badgeCardLocked} p-4 rounded-xl text-center`}
                onClick={() => handleBadgeClick('popular')}
              >
                <div className="w-16 h-16 bg-gray-400/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-fire text-gray-400 text-2xl"></i>
                </div>
                <h3 className="font-medium text-text-muted text-sm mb-1">人气托管师</h3>
                <p className="text-text-muted text-xs">月接单量前10%</p>
              </div>
            </div>
          </section>

          {/* 提升建议区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-6">个性化提升建议</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gradient-to-r from-secondary/10 to-accent/10 p-4 rounded-xl border border-secondary/20">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="fas fa-chart-line text-secondary"></i>
                  </div>
                  <div>
                    <h3 className="font-medium text-accent mb-2">提升接单量</h3>
                    <p className="text-text-secondary text-sm mb-3">您的接单量距离下一个徽章还差44单，建议：</p>
                    <ul className="space-y-1 text-text-secondary text-sm">
                      <li className="flex items-center space-x-2">
                        <i className="fas fa-check text-green-500 text-xs"></i>
                        <span>优化服务描述，突出您的优势</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <i className="fas fa-check text-green-500 text-xs"></i>
                        <span>保持在线状态，及时响应订单</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <i className="fas fa-check text-green-500 text-xs"></i>
                        <span>提供差异化服务，如特殊宠物护理</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-4 rounded-xl border border-blue-500/20">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="fas fa-clock text-blue-500"></i>
                  </div>
                  <div>
                    <h3 className="font-medium text-accent mb-2">皇冠徽章冲刺</h3>
                    <p className="text-text-secondary text-sm mb-3">距离皇冠托管师徽章还差22天，建议：</p>
                    <ul className="space-y-1 text-text-secondary text-sm">
                      <li className="flex items-center space-x-2">
                        <i className="fas fa-check text-green-500 text-xs"></i>
                        <span>保持优质服务，避免差评</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <i className="fas fa-check text-green-500 text-xs"></i>
                        <span>及时与宠物主人沟通</span>
                      </li>
                      <li className="flex items-center space-x-2">
                        <i className="fas fa-check text-green-500 text-xs"></i>
                        <span>定期更新托管环境照片</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* 徽章详情模态框 */}
      {isModalVisible && selectedBadge && (
        <div 
          className={`fixed inset-0 ${styles.modalOverlay} flex items-center justify-center z-50`}
          onClick={handleModalOverlayClick}
        >
          <div className={`${styles.modalContent} w-full max-w-md mx-4 p-6 rounded-2xl`}>
            <div className="text-center">
              <div className={`w-20 h-20 ${selectedBadge.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <i className={`${selectedBadge.icon} ${selectedBadge.iconColor} text-3xl`}></i>
              </div>
              <h3 className="text-xl font-bold text-accent mb-2">{selectedBadge.title}</h3>
              <p className="text-text-secondary mb-4">{selectedBadge.description}</p>
              <div className="bg-gray-50/50 rounded-lg p-4 mb-6">
                <h4 className="font-medium text-accent mb-2">获得条件：</h4>
                <ul className="space-y-1 text-text-secondary text-sm">
                  {selectedBadge.requirements.map((requirement, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <i className="fas fa-check text-green-500 text-xs"></i>
                      <span>{requirement}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <button 
                className={`${styles.btnPrimary} w-full py-3 rounded-lg font-medium`}
                onClick={handleCloseModal}
              >
                确定
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI客服悬浮按钮 */}
      <button 
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
        onClick={handleAiCustomerServiceClick}
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default GrowthSystemPage;

