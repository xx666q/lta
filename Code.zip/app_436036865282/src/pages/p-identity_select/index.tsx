

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

type IdentityType = 'owner' | 'provider' | 'admin' | null;

interface IdentityCardProps {
  identity: IdentityType;
  icon: string;
  iconColor: string;
  title: string;
  description: string;
  features: string[];
  isSelected: boolean;
  onSelect: (identity: IdentityType) => void;
}

const IdentityCard: React.FC<IdentityCardProps> = ({
  identity,
  icon,
  iconColor,
  title,
  description,
  features,
  isSelected,
  onSelect
}) => {
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onSelect(identity);
    }
  };

  const handleMouseEnter = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isSelected) {
      e.currentTarget.style.transform = 'translateY(-8px) scale(1.02)';
    }
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isSelected) {
      e.currentTarget.style.transform = 'translateY(0) scale(1)';
    }
  };

  return (
    <div
      className={`${styles.glassCard} ${isSelected ? styles.selected : ''} p-8 rounded-3xl cursor-pointer text-center`}
      onClick={() => onSelect(identity)}
      onKeyDown={handleKeyDown}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      tabIndex={0}
      role="button"
      aria-label={`选择${title}身份`}
    >
      <div className="relative mb-6">
        <div className={`${styles.identityIcon} w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4`}>
          <i className={`${icon} text-4xl ${iconColor}`}></i>
        </div>
        <div className={`absolute inset-0 w-20 h-20 rounded-full ${iconColor.replace('text-', 'bg-').replace('500', '500/20')} ${styles.pulseRing}`}></div>
      </div>
      <h3 className="text-2xl font-bold text-accent mb-3">{title}</h3>
      <p className="text-text-secondary mb-4 leading-relaxed">
        {description}
      </p>
      <div className="space-y-2 text-sm text-text-muted">
        {features.map((feature, index) => (
          <div key={index} className="flex items-center justify-center space-x-2">
            <i className="fas fa-check text-green-500"></i>
            <span>{feature}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const IdentitySelectPage: React.FC = () => {
  const [selectedIdentity, setSelectedIdentity] = useState<IdentityType>(null);
  const [isConfirmLoading, setIsConfirmLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 选择身份';
    return () => { document.title = originalTitle; };
  }, []);

  const handleIdentitySelect = (identity: IdentityType) => {
    setSelectedIdentity(identity);
  };

  const handleConfirm = () => {
    if (!selectedIdentity) return;

    setIsConfirmLoading(true);

    setTimeout(() => {
      switch(selectedIdentity) {
        case 'owner':
          navigate('/owner-dashboard');
          break;
        case 'provider':
          navigate('/qualification-audit');
          break;
        case 'admin':
          navigate('/admin-dashboard');
          break;
        default:
          alert('选择身份失败，请重试');
          window.location.reload();
      }
    }, 1000);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && selectedIdentity && !isConfirmLoading) {
      handleConfirm();
    }
  };

  const identityOptions = [
    {
      identity: 'owner' as IdentityType,
      icon: 'fas fa-home',
      iconColor: 'text-pink-500',
      title: '宠物主人',
      description: '为您的爱宠寻找专业、可靠的托管服务，享受安心的托管体验',
      features: ['寻找附近托管服务', '管理宠物档案', '实时查看宠物状态']
    },
    {
      identity: 'provider' as IdentityType,
      icon: 'fas fa-heart',
      iconColor: 'text-secondary',
      title: '托管服务商',
      description: '分享您的爱心和专业，为宠物提供优质托管服务，获得稳定收入',
      features: ['发布托管服务', '接收托管订单', '建立口碑品牌']
    },
    {
      identity: 'admin' as IdentityType,
      icon: 'fas fa-shield-alt',
      iconColor: 'text-blue-500',
      title: '管理员',
      description: '管理平台运营，确保服务质量，为用户提供安全可靠的托管环境',
      features: ['用户资质审核', '内容巡查管理', '数据监控分析']
    }
  ];

  return (
    <div className={styles.pageWrapper} onKeyDown={handleKeyDown}>
      {/* 顶部Logo区域 */}
      <header className="flex justify-center pt-12 pb-8">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
            <i className="fas fa-paw text-2xl text-accent"></i>
          </div>
          <span className="text-3xl font-bold text-accent">宠托帮</span>
        </div>
      </header>

      {/* 主内容区域 */}
      <main className="flex flex-col items-center justify-center px-6 py-8 min-h-[calc(100vh-140px)]">
        {/* 页面标题 */}
        <div className={`text-center mb-12 ${styles.fadeIn}`}>
          <h1 className="text-4xl font-bold text-accent mb-4">请选择您的身份</h1>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            选择最符合您需求的身份，开始在宠托帮的美好旅程
          </p>
        </div>

        {/* 身份选择卡片组 */}
        <div className={`grid grid-cols-1 md:grid-cols-3 gap-8 mb-12 w-full max-w-6xl ${styles.fadeIn}`}>
          {identityOptions.map((option) => (
            <IdentityCard
              key={option.identity}
              identity={option.identity}
              icon={option.icon}
              iconColor={option.iconColor}
              title={option.title}
              description={option.description}
              features={option.features}
              isSelected={selectedIdentity === option.identity}
              onSelect={handleIdentitySelect}
            />
          ))}
        </div>

        {/* 确认按钮 */}
        <div className={`w-full max-w-md ${styles.fadeIn}`}>
          <button
            className={`${styles.btnPrimary} w-full py-4 px-8 rounded-2xl text-lg font-semibold disabled:opacity-50 ${selectedIdentity && !isConfirmLoading ? 'animate-pulse' : ''}`}
            disabled={!selectedIdentity || isConfirmLoading}
            onClick={handleConfirm}
          >
            {isConfirmLoading ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                正在跳转...
              </>
            ) : (
              <>
                <i className="fas fa-arrow-right mr-2"></i>
                确认选择
              </>
            )}
          </button>
          <p className="text-center text-text-muted text-sm mt-4">
            选择后可在个人中心修改身份
          </p>
        </div>
      </main>

      {/* 装饰元素 */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-20 left-10 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-secondary/10 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-pink-500/10 rounded-full blur-2xl"></div>
      </div>
    </div>
  );
};

export default IdentitySelectPage;

