

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface FilterState {
  distance: number;
  priceMin: string;
  priceMax: string;
  petDog: boolean;
  petCat: boolean;
  petSmall: boolean;
  rating45: boolean;
  pickup: boolean;
  camera: boolean;
}

const ServiceDiscoveryPage: React.FC = () => {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState<'list' | 'map'>('list');
  const [filterState, setFilterState] = useState<FilterState>({
    distance: 3,
    priceMin: '',
    priceMax: '',
    petDog: false,
    petCat: false,
    petSmall: false,
    rating45: false,
    pickup: false,
    camera: false,
  });

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 寻找服务';
    return () => { document.title = originalTitle; };
  }, []);

  const handleViewToggle = (view: 'list' | 'map') => {
    setCurrentView(view);
  };

  const handleDistanceChange = (value: number) => {
    setFilterState(prev => ({ ...prev, distance: value }));
  };

  const handleFilterChange = (field: keyof FilterState, value: string | boolean) => {
    setFilterState(prev => ({ ...prev, [field]: value }));
  };

  const handleApplyFilters = () => {
    console.log('应用筛选条件:', filterState);
    alert('筛选条件已应用！');
  };

  const handleResetFilters = () => {
    setFilterState({
      distance: 3,
      priceMin: '',
      priceMax: '',
      petDog: false,
      petCat: false,
      petSmall: false,
      rating45: false,
      pickup: false,
      camera: false,
    });
  };

  const handleServiceCardClick = (serviceId: string) => {
    navigate(`/service-detail?serviceId=${serviceId}`);
  };

  const handleSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const searchTerm = (e.target as HTMLInputElement).value;
      console.log('搜索服务:', searchTerm);
    }
  };

  const handleAiCustomerService = () => {
    console.log('打开AI客服');
    alert('AI客服功能开发中...');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索服务、服务商..." 
                onKeyPress={handleSearch}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img src="https://s.coze.cn/image/2AA_oOVOWog/" 
                 alt="用户头像" className="w-8 h-8 rounded-full" />
            <span className="text-text-primary font-medium hidden md:block">张小明</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link to="/owner-dashboard" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link to="/pet-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-paw text-lg"></i>
              <span className="font-medium">我的宠物</span>
            </Link>
            <Link to="/service-discovery" className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-search text-lg"></i>
              <span className="font-medium">寻找服务</span>
            </Link>
            <Link to="/owner-calendar" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-calendar-alt text-lg"></i>
              <span className="font-medium">托管日历</span>
            </Link>
            <Link to="/cloud-view" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-video text-lg"></i>
              <span className="font-medium">云看宠</span>
            </Link>
            <Link to="/user-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">寻找服务</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">寻找托管服务</h1>
                <p className="text-text-secondary mt-1">为您的爱宠找到最适合的托管服务</p>
              </div>
              <div className="flex bg-white/20 rounded-lg p-1">
                <button 
                  onClick={() => handleViewToggle('list')}
                  className={`px-4 py-2 rounded-md text-sm font-medium ${
                    currentView === 'list' 
                      ? 'bg-secondary text-white' 
                      : 'text-text-secondary hover:bg-white/10 transition-colors'
                  }`}
                >
                  <i className="fas fa-list mr-2"></i>列表
                </button>
                <button 
                  onClick={() => handleViewToggle('map')}
                  className={`px-4 py-2 rounded-md text-sm font-medium ${
                    currentView === 'map' 
                      ? 'bg-secondary text-white' 
                      : 'text-text-secondary hover:bg-white/10 transition-colors'
                  }`}
                >
                  <i className="fas fa-map mr-2"></i>地图
                </button>
              </div>
            </div>
          </header>

          {/* 筛选条件区 */}
          <section className={`${styles.filterPanel} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">筛选条件</h2>
              <button 
                onClick={handleResetFilters}
                className="text-secondary hover:text-accent text-sm font-medium transition-colors"
              >
                <i className="fas fa-times mr-1"></i>清除筛选
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* 距离筛选 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-text-primary">距离范围</label>
                <div className="space-y-2">
                  <input 
                    type="range" 
                    className={`${styles.rangeSlider} w-full`} 
                    min="1" 
                    max="10" 
                    value={filterState.distance}
                    onChange={(e) => handleDistanceChange(parseInt(e.target.value))}
                  />
                  <div className="flex justify-between text-sm text-text-muted">
                    <span>1km</span>
                    <span>{filterState.distance}km</span>
                    <span>10km</span>
                  </div>
                </div>
              </div>

              {/* 价格区间 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-text-primary">价格区间</label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-text-muted">¥</span>
                    <input 
                      type="number" 
                      placeholder="最低" 
                      value={filterState.priceMin}
                      onChange={(e) => handleFilterChange('priceMin', e.target.value)}
                      className="flex-1 px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
                    />
                    <span className="text-sm text-text-muted">-</span>
                    <input 
                      type="number" 
                      placeholder="最高" 
                      value={filterState.priceMax}
                      onChange={(e) => handleFilterChange('priceMax', e.target.value)}
                      className="flex-1 px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
                    />
                    <span className="text-sm text-text-muted">/天</span>
                  </div>
                </div>
              </div>

              {/* 宠物类型 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-text-primary">宠物类型</label>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={filterState.petDog}
                      onChange={(e) => handleFilterChange('petDog', e.target.checked)}
                      className="rounded text-secondary focus:ring-secondary/50"
                    />
                    <span className="text-sm text-text-primary">狗狗</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={filterState.petCat}
                      onChange={(e) => handleFilterChange('petCat', e.target.checked)}
                      className="rounded text-secondary focus:ring-secondary/50"
                    />
                    <span className="text-sm text-text-primary">猫咪</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={filterState.petSmall}
                      onChange={(e) => handleFilterChange('petSmall', e.target.checked)}
                      className="rounded text-secondary focus:ring-secondary/50"
                    />
                    <span className="text-sm text-text-primary">小型宠物</span>
                  </label>
                </div>
              </div>

              {/* 评分和特色 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium text-text-primary">评分和特色</label>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={filterState.rating45}
                      onChange={(e) => handleFilterChange('rating45', e.target.checked)}
                      className="rounded text-secondary focus:ring-secondary/50"
                    />
                    <span className="text-sm text-text-primary">评分≥4.5</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={filterState.pickup}
                      onChange={(e) => handleFilterChange('pickup', e.target.checked)}
                      className="rounded text-secondary focus:ring-secondary/50"
                    />
                    <span className="text-sm text-text-primary">可接送</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      checked={filterState.camera}
                      onChange={(e) => handleFilterChange('camera', e.target.checked)}
                      className="rounded text-secondary focus:ring-secondary/50"
                    />
                    <span className="text-sm text-text-primary">24h监控</span>
                  </label>
                </div>
              </div>
            </div>

            {/* 筛选按钮 */}
            <div className="flex items-center justify-center space-x-4 mt-6">
              <button 
                onClick={handleApplyFilters}
                className={`${styles.btnPrimary} px-6 py-2 rounded-lg font-medium`}
              >
                <i className="fas fa-filter mr-2"></i>应用筛选
              </button>
              <button 
                onClick={handleResetFilters}
                className={`${styles.btnSecondary} px-6 py-2 rounded-lg font-medium`}
              >
                <i className="fas fa-undo mr-2"></i>重置
              </button>
            </div>
          </section>

          {/* 服务列表视图 */}
          {currentView === 'list' && (
            <section className="space-y-4">
              {/* 服务卡片 1 */}
              <div 
                className={`${styles.serviceCard} p-6 rounded-2xl`} 
                onClick={() => handleServiceCardClick('service-001')}
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <img src="https://s.coze.cn/image/LLvheeIpVNo/" 
                         alt="李阿姨头像" className="w-16 h-16 rounded-full" />
                    <div className="flex items-center mt-2">
                      <div className="flex text-yellow-400">
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                      </div>
                      <span className="text-sm text-text-muted ml-1">4.9</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-accent">李阿姨的温馨日托</h3>
                      <span className="text-2xl font-bold text-secondary">¥80<span className="text-sm font-normal">/天</span></span>
                    </div>
                    <div className="flex items-center space-x-4 mb-3">
                      <span className="px-2 py-1 bg-green-500/20 text-green-600 text-xs rounded-full">日托服务</span>
                      <span className="px-2 py-1 bg-blue-500/20 text-blue-600 text-xs rounded-full">可接送</span>
                      <span className="px-2 py-1 bg-purple-500/20 text-purple-600 text-xs rounded-full">24h监控</span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-text-muted mb-3">
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-map-marker-alt"></i>
                        <span>距离您 1.2km</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-home"></i>
                        <span>家庭式托管</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-paw"></i>
                        <span>可托管: 狗狗、猫咪</span>
                      </div>
                    </div>
                    <p className="text-text-secondary text-sm mb-3">
                      10年养宠经验，爱心满满！提供专业的宠物日托服务，环境干净舒适，每天定时遛狗、喂食、玩耍。
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-text-muted">
                        <span>已完成订单: 156</span>
                        <span>接单率: 98%</span>
                      </div>
                      <button className={`${styles.btnPrimary} px-4 py-2 rounded-lg text-sm font-medium`}>
                        查看详情
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 服务卡片 2 */}
              <div 
                className={`${styles.serviceCard} p-6 rounded-2xl`} 
                onClick={() => handleServiceCardClick('service-002')}
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <img src="https://s.coze.cn/image/LOtYkrvPjp0/" 
                         alt="王小姐头像" className="w-16 h-16 rounded-full" />
                    <div className="flex items-center mt-2">
                      <div className="flex text-yellow-400">
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                      </div>
                      <span className="text-sm text-text-muted ml-1">4.8</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-accent">王小姐的专业托管</h3>
                      <span className="text-2xl font-bold text-secondary">¥120<span className="text-sm font-normal">/天</span></span>
                    </div>
                    <div className="flex items-center space-x-4 mb-3">
                      <span className="px-2 py-1 bg-orange-500/20 text-orange-600 text-xs rounded-full">周托服务</span>
                      <span className="px-2 py-1 bg-purple-500/20 text-purple-600 text-xs rounded-full">24h监控</span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-text-muted mb-3">
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-map-marker-alt"></i>
                        <span>距离您 2.1km</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-building"></i>
                        <span>专业门店</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-paw"></i>
                        <span>可托管: 狗狗、猫咪、小型宠物</span>
                      </div>
                    </div>
                    <p className="text-text-secondary text-sm mb-3">
                      专业宠物托管门店，设施齐全，有专业的护理人员。提供长期托管服务，环境安全舒适。
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-text-muted">
                        <span>已完成订单: 89</span>
                        <span>接单率: 95%</span>
                      </div>
                      <button className={`${styles.btnPrimary} px-4 py-2 rounded-lg text-sm font-medium`}>
                        查看详情
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 服务卡片 3 */}
              <div 
                className={`${styles.serviceCard} p-6 rounded-2xl`} 
                onClick={() => handleServiceCardClick('service-003')}
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <img src="https://s.coze.cn/image/AIkmN5URTqw/" 
                         alt="张先生头像" className="w-16 h-16 rounded-full" />
                    <div className="flex items-center mt-2">
                      <div className="flex text-yellow-400">
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="far fa-star text-xs"></i>
                      </div>
                      <span className="text-sm text-text-muted ml-1">4.6</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-accent">张先生的陪遛服务</h3>
                      <span className="text-2xl font-bold text-secondary">¥50<span className="text-sm font-normal">/小时</span></span>
                    </div>
                    <div className="flex items-center space-x-4 mb-3">
                      <span className="px-2 py-1 bg-blue-500/20 text-blue-600 text-xs rounded-full">小时陪遛</span>
                      <span className="px-2 py-1 bg-green-500/20 text-green-600 text-xs rounded-full">可接送</span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-text-muted mb-3">
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-map-marker-alt"></i>
                        <span>距离您 0.8km</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-running"></i>
                        <span>专业陪遛</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-paw"></i>
                        <span>可托管: 狗狗</span>
                      </div>
                    </div>
                    <p className="text-text-secondary text-sm mb-3">
                      专业的狗狗陪遛服务，熟悉各种犬种习性，保证狗狗的安全和快乐。
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-text-muted">
                        <span>已完成订单: 203</span>
                        <span>接单率: 99%</span>
                      </div>
                      <button className={`${styles.btnPrimary} px-4 py-2 rounded-lg text-sm font-medium`}>
                        查看详情
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 服务卡片 4 */}
              <div 
                className={`${styles.serviceCard} p-6 rounded-2xl`} 
                onClick={() => handleServiceCardClick('service-004')}
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <img src="https://s.coze.cn/image/QwCaK6jr0JY/" 
                         alt="陈阿姨头像" className="w-16 h-16 rounded-full" />
                    <div className="flex items-center mt-2">
                      <div className="flex text-yellow-400">
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                        <i className="fas fa-star text-xs"></i>
                      </div>
                      <span className="text-sm text-text-muted ml-1">4.9</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-accent">陈阿姨的猫咪乐园</h3>
                      <span className="text-2xl font-bold text-secondary">¥60<span className="text-sm font-normal">/天</span></span>
                    </div>
                    <div className="flex items-center space-x-4 mb-3">
                      <span className="px-2 py-1 bg-pink-500/20 text-pink-600 text-xs rounded-full">猫咪专护</span>
                      <span className="px-2 py-1 bg-purple-500/20 text-purple-600 text-xs rounded-full">24h监控</span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-text-muted mb-3">
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-map-marker-alt"></i>
                        <span>距离您 2.8km</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-home"></i>
                        <span>家庭式托管</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <i className="fas fa-paw"></i>
                        <span>可托管: 猫咪</span>
                      </div>
                    </div>
                    <p className="text-text-secondary text-sm mb-3">
                      猫咪专属托管服务，有丰富的猫咪照顾经验，提供舒适的猫咪生活环境。
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-text-muted">
                        <span>已完成订单: 76</span>
                        <span>接单率: 96%</span>
                      </div>
                      <button className={`${styles.btnPrimary} px-4 py-2 rounded-lg text-sm font-medium`}>
                        查看详情
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* 地图视图 */}
          {currentView === 'map' && (
            <section>
              <div className={`${styles.mapContainer} p-6 rounded-2xl h-96 flex items-center justify-center`}>
                <div className="text-center">
                  <i className="fas fa-map-marked-alt text-4xl text-text-muted mb-4"></i>
                  <h3 className="text-lg font-semibold text-accent mb-2">地图模式</h3>
                  <p className="text-text-secondary">显示周边托管服务位置</p>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <span className="text-sm text-text-muted">李阿姨的温馨日托 (1.2km)</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-text-muted">王小姐的专业托管 (2.1km)</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span className="text-sm text-text-muted">张先生的陪遛服务 (0.8km)</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-3 h-3 bg-pink-500 rounded-full"></div>
                      <span className="text-sm text-text-muted">陈阿姨的猫咪乐园 (2.8km)</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* 分页控件 */}
          <section className="flex items-center justify-between">
            <div className="text-sm text-text-muted">
              显示 1-4 条，共 16 条结果
            </div>
            <div className="flex items-center space-x-2">
              <button className="px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-muted hover:text-accent transition-colors" disabled>
                <i className="fas fa-chevron-left"></i>
              </button>
              <button className="px-3 py-2 bg-secondary text-white rounded-lg text-sm font-medium">1</button>
              <button className="px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-muted hover:text-accent transition-colors">2</button>
              <button className="px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-muted hover:text-accent transition-colors">3</button>
              <span className="px-3 py-2 text-text-muted">...</span>
              <button className="px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-muted hover:text-accent transition-colors">4</button>
              <button className="px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-muted hover:text-accent transition-colors">
                <i className="fas fa-chevron-right"></i>
              </button>
            </div>
          </section>
        </main>
      </div>

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiCustomerService}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default ServiceDiscoveryPage;

