

export interface Order {
  id: string;
  orderNumber: string;
  ownerName: string;
  ownerAvatar: string;
  ownerRating: number;
  ownerCompletedOrders: number;
  petName: string;
  petAvatar: string;
  petType: string;
  petAge: number;
  serviceType: 'daycare' | 'weekcare' | 'hourcare';
  serviceDate: string;
  serviceTime: string;
  specialRequirements: string;
  aiConvertedText: string;
  price: number;
  status: 'pending' | 'accepted' | 'rejected';
}

export interface FilterOptions {
  serviceType: string;
  petType: string;
  distance: string;
  price: string;
}

export type RejectReason = 'time-conflict' | 'pet-type-not-allowed' | 'distance-too-far' | 'special-requirements' | 'other';

