

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';
import { Order, FilterOptions, RejectReason } from './types';

const OrderHallPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 状态管理
  const [searchKeyword, setSearchKeyword] = useState('');
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    serviceType: '',
    petType: '',
    distance: '',
    price: ''
  });
  const [isRejectModalVisible, setIsRejectModalVisible] = useState(false);
  const [currentRejectOrderId, setCurrentRejectOrderId] = useState<string | null>(null);
  const [selectedRejectReason, setSelectedRejectReason] = useState<RejectReason | ''>('');
  const [lastUpdateTime, setLastUpdateTime] = useState('刚刚');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // 订单数据
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'ORD20240315001',
      orderNumber: '#ORD20240315001',
      ownerName: '张小明',
      ownerAvatar: 'https://s.coze.cn/image/Pxx7Hq-JTGI/',
      ownerRating: 4.8,
      ownerCompletedOrders: 15,
      petName: '豆豆',
      petAvatar: 'https://s.coze.cn/image/MdQO0InFAQ0/',
      petType: '金毛犬',
      petAge: 7,
      serviceType: 'daycare',
      serviceDate: '3月18日',
      serviceTime: '09:00 - 18:00',
      specialRequirements: '宠物性格温顺，需要按时喂食，喜欢户外活动',
      aiConvertedText: '您的宠物性格温顺，我们会按时喂食并安排适当的户外活动时间。',
      price: 80,
      status: 'pending'
    },
    {
      id: 'ORD20240315002',
      orderNumber: '#ORD20240315002',
      ownerName: '王小姐',
      ownerAvatar: 'https://s.coze.cn/image/or2OxVL6X28/',
      ownerRating: 4.9,
      ownerCompletedOrders: 28,
      petName: '咪咪',
      petAvatar: 'https://s.coze.cn/image/f_spavMJt8c/',
      petType: '布偶猫',
      petAge: 3,
      serviceType: 'weekcare',
      serviceDate: '3月20日-27日',
      serviceTime: '全天托管',
      specialRequirements: '猫咪比较胆小，需要安静环境，有特殊饮食要求',
      aiConvertedText: '您的猫咪比较胆小，我们会提供安静的环境并严格按照您的要求进行喂食。',
      price: 560,
      status: 'pending'
    },
    {
      id: 'ORD20240315003',
      orderNumber: '#ORD20240315003',
      ownerName: '李先生',
      ownerAvatar: 'https://s.coze.cn/image/3tuq_j-xNI4/',
      ownerRating: 4.7,
      ownerCompletedOrders: 8,
      petName: '小白',
      petAvatar: 'https://s.coze.cn/image/QfS1zFjG07c/',
      petType: '柴犬',
      petAge: 2,
      serviceType: 'hourcare',
      serviceDate: '3月16日',
      serviceTime: '15:00 - 17:00',
      specialRequirements: '狗狗活泼好动，需要牵绳遛弯，喜欢球类游戏',
      aiConvertedText: '您的狗狗活泼可爱，我们会使用牵引绳确保安全，并陪它玩喜欢的球类游戏。',
      price: 40,
      status: 'pending'
    },
    {
      id: 'ORD20240315004',
      orderNumber: '#ORD20240315004',
      ownerName: '陈女士',
      ownerAvatar: 'https://s.coze.cn/image/ATzCOp6MiAs/',
      ownerRating: 4.6,
      ownerCompletedOrders: 12,
      petName: '花花',
      petAvatar: 'https://s.coze.cn/image/hTgmZ_1_JZ0/',
      petType: '英短猫',
      petAge: 5,
      serviceType: 'daycare',
      serviceDate: '3月17日',
      serviceTime: '10:00 - 19:00',
      specialRequirements: '猫咪比较独立，按时喂食即可，不需要太多陪伴',
      aiConvertedText: '您的猫咪比较独立，我们会按时喂食并确保它的舒适。',
      price: 60,
      status: 'pending'
    },
    {
      id: 'ORD20240315005',
      orderNumber: '#ORD20240315005',
      ownerName: '刘先生',
      ownerAvatar: 'https://s.coze.cn/image/CztkkPWqBFo/',
      ownerRating: 4.8,
      ownerCompletedOrders: 20,
      petName: '乐乐',
      petAvatar: 'https://s.coze.cn/image/ezjKMpjBxLg/',
      petType: '萨摩耶',
      petAge: 4,
      serviceType: 'weekcare',
      serviceDate: '3月22日-29日',
      serviceTime: '全天托管',
      specialRequirements: '狗狗很友好，需要每天梳毛，有轻微皮肤过敏',
      aiConvertedText: '您的狗狗非常友好，我们会每天为它梳毛，并特别注意它的皮肤状况。',
      price: 520,
      status: 'pending'
    }
  ]);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '宠托帮 - 接单大厅';
    return () => { document.title = originalTitle; };
  }, []);

  // 更新最后更新时间
  const updateLastUpdateTime = () => {
    const now = new Date();
    const timeString = now.toLocaleTimeString('zh-CN', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    setLastUpdateTime(timeString);
  };

  // 初始化页面
  useEffect(() => {
    updateLastUpdateTime();
  }, []);

  // 处理搜索
  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      console.log('搜索:', searchKeyword);
      // 这里可以实现搜索功能
    }
  };

  // 处理筛选条件变化
  const handleFilterChange = (field: keyof FilterOptions, value: string) => {
    setFilterOptions(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // 应用筛选
  const handleApplyFilter = () => {
    console.log('应用筛选条件:', filterOptions);
    updateLastUpdateTime();
  };

  // 重置筛选
  const handleResetFilter = () => {
    setFilterOptions({
      serviceType: '',
      petType: '',
      distance: '',
      price: ''
    });
    console.log('重置筛选条件');
    updateLastUpdateTime();
  };

  // 刷新订单列表
  const handleRefreshOrders = () => {
    console.log('刷新订单列表');
    setIsRefreshing(true);
    updateLastUpdateTime();
    
    // 添加刷新动画
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1000);
  };

  // 接单处理
  const handleAcceptOrder = (orderId: string) => {
    console.log('接单:', orderId);
    
    setOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, status: 'accepted' } : order
    ));
    
    // 2秒后跳转到订单管理页面
    setTimeout(() => {
      navigate(`/provider-order-manage?orderId=${orderId}`);
    }, 1500);
  };

  // 拒单处理
  const handleRejectOrder = (orderId: string) => {
    setCurrentRejectOrderId(orderId);
    setIsRejectModalVisible(true);
  };

  // 确认拒单
  const handleConfirmReject = () => {
    if (!selectedRejectReason) {
      alert('请选择拒单理由');
      return;
    }
    
    console.log('拒单:', currentRejectOrderId, '理由:', selectedRejectReason);
    
    if (currentRejectOrderId) {
      setOrders(prev => prev.map(order => 
        order.id === currentRejectOrderId ? { ...order, status: 'rejected' } : order
      ));
    }
    
    setIsRejectModalVisible(false);
    setCurrentRejectOrderId(null);
    setSelectedRejectReason('');
  };

  // 取消拒单
  const handleCancelReject = () => {
    setIsRejectModalVisible(false);
    setCurrentRejectOrderId(null);
    setSelectedRejectReason('');
  };

  // 点击弹窗外部关闭
  const handleModalOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleCancelReject();
    }
  };

  // AI客服按钮点击
  const handleAiCustomerService = () => {
    console.log('打开AI客服');
    alert('AI客服功能开发中...');
  };

  // 获取服务类型显示文本和样式
  const getServiceTypeInfo = (serviceType: string) => {
    switch (serviceType) {
      case 'daycare':
        return { text: '日托服务', className: 'bg-blue-500/20 text-blue-600' };
      case 'weekcare':
        return { text: '周托服务', className: 'bg-green-500/20 text-green-600' };
      case 'hourcare':
        return { text: '小时陪遛', className: 'bg-yellow-500/20 text-yellow-600' };
      default:
        return { text: '未知服务', className: 'bg-gray-500/20 text-gray-600' };
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <nav className={`${styles.glassNav} fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50`}>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <i className="fas fa-paw text-2xl text-accent"></i>
            <span className="text-xl font-bold text-accent">宠托帮</span>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input 
                type="text" 
                placeholder="搜索订单、宠物主人..." 
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                onKeyPress={handleSearchKeyPress}
                className="w-80 px-4 py-2 pl-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-secondary/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-muted"></i>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="relative p-2 text-text-secondary hover:text-accent transition-colors">
            <i className="fas fa-bell text-xl"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full"></span>
          </button>
          <div className="flex items-center space-x-2 cursor-pointer hover:bg-white/10 rounded-lg p-2 transition-colors">
            <img src="https://s.coze.cn/image/Vqrh-y-FrTQ/" 
                 alt="托管服务商头像" className="w-8 h-8 rounded-full" />
            <span className="text-text-primary font-medium hidden md:block">李阿姨</span>
            <i className="fas fa-chevron-down text-text-muted text-sm"></i>
          </div>
        </div>
      </nav>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`${styles.glassSidebar} w-64 min-h-screen p-4`}>
          <nav className="space-y-2">
            <Link to="/provider-dashboard" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-home text-lg"></i>
              <span className="font-medium">工作台</span>
            </Link>
            <Link to="/qualification-audit" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-certificate text-lg"></i>
              <span className="font-medium">资质审核</span>
            </Link>
            <Link to="/service-publish" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-plus-circle text-lg"></i>
              <span className="font-medium">服务发布</span>
            </Link>
            <Link to="/order-hall" className={`${styles.navItem} ${styles.navItemActive} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all`}>
              <i className="fas fa-clipboard-list text-lg"></i>
              <span className="font-medium">接单大厅</span>
            </Link>
            <Link to="/provider-order-manage" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-tasks text-lg"></i>
              <span className="font-medium">订单管理</span>
            </Link>
            <Link to="/withdrawal" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-money-bill-wave text-lg"></i>
              <span className="font-medium">收入提现</span>
            </Link>
            <Link to="/growth-system" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-star text-lg"></i>
              <span className="font-medium">成长体系</span>
            </Link>
            <Link to="/user-profile" className={`${styles.navItem} flex items-center space-x-3 px-4 py-3 rounded-lg transition-all text-text-secondary`}>
              <i className="fas fa-user text-lg"></i>
              <span className="font-medium">个人中心</span>
            </Link>
          </nav>
        </aside>

        {/* 主内容区 */}
        <main className="flex-1 p-6 space-y-6">
          {/* 页面头部 */}
          <header className="space-y-2">
            <div className="text-sm text-text-muted">
              <span>首页</span>
              <i className="fas fa-chevron-right mx-2"></i>
              <span className="text-accent">接单大厅</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-accent">接单大厅</h1>
                <p className="text-text-secondary mt-1">实时查看和处理新的托管订单</p>
              </div>
              <div className="hidden lg:flex items-center space-x-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-accent">5</p>
                  <p className="text-text-muted text-sm">待处理订单</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-secondary">12</p>
                  <p className="text-text-muted text-sm">今日新增</p>
                </div>
              </div>
            </div>
          </header>

          {/* 筛选条件区 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <h2 className="text-lg font-semibold text-accent mb-4">筛选条件</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-text-secondary">服务类型</label>
                <select 
                  value={filterOptions.serviceType}
                  onChange={(e) => handleFilterChange('serviceType', e.target.value)}
                  className="w-full px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-secondary/50"
                >
                  <option value="">全部类型</option>
                  <option value="daycare">日托服务</option>
                  <option value="weekcare">周托服务</option>
                  <option value="hourcare">小时陪遛</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-text-secondary">宠物类型</label>
                <select 
                  value={filterOptions.petType}
                  onChange={(e) => handleFilterChange('petType', e.target.value)}
                  className="w-full px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-secondary/50"
                >
                  <option value="">全部宠物</option>
                  <option value="dog">狗狗</option>
                  <option value="cat">猫咪</option>
                  <option value="other">其他</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-text-secondary">距离范围</label>
                <select 
                  value={filterOptions.distance}
                  onChange={(e) => handleFilterChange('distance', e.target.value)}
                  className="w-full px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-secondary/50"
                >
                  <option value="">不限距离</option>
                  <option value="1">1公里内</option>
                  <option value="3">3公里内</option>
                  <option value="5">5公里内</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-text-secondary">价格范围</label>
                <select 
                  value={filterOptions.price}
                  onChange={(e) => handleFilterChange('price', e.target.value)}
                  className="w-full px-3 py-2 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-secondary/50"
                >
                  <option value="">不限价格</option>
                  <option value="0-50">50元以下</option>
                  <option value="50-100">50-100元</option>
                  <option value="100+">100元以上</option>
                </select>
              </div>
              
              <div className="flex items-end space-x-2">
                <button 
                  onClick={handleApplyFilter}
                  className={`${styles.btnPrimary} px-4 py-2 rounded-lg text-sm font-medium`}
                >
                  <i className="fas fa-filter mr-2"></i>筛选
                </button>
                <button 
                  onClick={handleResetFilter}
                  className={`${styles.btnSecondary} px-4 py-2 rounded-lg text-sm font-medium`}
                >
                  <i className="fas fa-undo mr-2"></i>重置
                </button>
              </div>
            </div>
          </section>

          {/* 订单列表 */}
          <section className={`${styles.glassCard} p-6 rounded-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-accent">待处理订单</h2>
              <div className="flex items-center space-x-2">
                <span className="text-text-muted text-sm">最后更新：</span>
                <span className="text-text-primary text-sm font-medium">{lastUpdateTime}</span>
                <button 
                  onClick={handleRefreshOrders}
                  className="text-secondary hover:text-accent text-sm transition-colors"
                >
                  <i className={`fas fa-sync-alt mr-1 ${isRefreshing ? 'animate-spin' : ''}`}></i>刷新
                </button>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className={`w-full ${styles.tableGlass} rounded-xl overflow-hidden`}>
                <thead className="bg-white/10">
                  <tr>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">订单号</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">宠物主人</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">宠物信息</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务类型</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">服务时段</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">特殊需求</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">价格</th>
                    <th className="px-4 py-3 text-left text-text-secondary font-medium text-sm">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => {
                    const serviceTypeInfo = getServiceTypeInfo(order.serviceType);
                    
                    return (
                      <tr key={order.id} className={`${styles.tableRow} ${order.id !== orders[orders.length - 1].id ? 'border-b border-white/10' : ''}`}>
                        <td className="px-4 py-3 text-text-primary font-medium">{order.orderNumber}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-2">
                            <img 
                              src={order.ownerAvatar} 
                              alt={`${order.ownerName}头像`} 
                              className="w-8 h-8 rounded-full" 
                            />
                            <div>
                              <p className="text-text-primary font-medium">{order.ownerName}</p>
                              <p className="text-text-muted text-xs">{order.ownerRating}分 · 完成{order.ownerCompletedOrders}单</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-2">
                            <img 
                              src={order.petAvatar} 
                              alt={`${order.petName}`} 
                              className="w-8 h-8 rounded-full" 
                            />
                            <div>
                              <p className="text-text-primary font-medium">{order.petName}</p>
                              <p className="text-text-muted text-xs">{order.petType} · {order.petAge}岁</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 ${serviceTypeInfo.className} text-xs rounded-full`}>
                            {serviceTypeInfo.text}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-text-secondary">
                          <p className="font-medium">{order.serviceDate}</p>
                          <p className="text-sm">{order.serviceTime}</p>
                        </td>
                        <td className="px-4 py-3">
                          <div className="relative group">
                            <p className="text-text-secondary text-sm max-w-xs truncate">
                              <i className="fas fa-robot text-secondary text-xs mr-1"></i>
                              {order.specialRequirements}
                            </p>
                            <div className="absolute bottom-full left-0 mb-2 w-64 bg-white/95 backdrop-blur-sm border border-white/30 rounded-lg p-3 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity z-10">
                              <p className="text-text-primary text-sm font-medium mb-1">AI话术转换：</p>
                              <p className="text-text-secondary text-sm">{order.aiConvertedText}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-accent font-semibold">¥{order.price}</td>
                        <td className="px-4 py-3">
                          {order.status === 'pending' ? (
                            <div className="flex space-x-2">
                              <button 
                                onClick={() => handleAcceptOrder(order.id)}
                                className={`${styles.btnPrimary} px-3 py-1 rounded-lg text-xs font-medium`}
                              >
                                <i className="fas fa-check mr-1"></i>接单
                              </button>
                              <button 
                                onClick={() => handleRejectOrder(order.id)}
                                className={`${styles.btnDanger} px-3 py-1 rounded-lg text-xs font-medium`}
                              >
                                <i className="fas fa-times mr-1"></i>拒单
                              </button>
                            </div>
                          ) : order.status === 'accepted' ? (
                            <span className="px-2 py-1 bg-green-500/20 text-green-600 text-xs rounded-full">已接单</span>
                          ) : (
                            <span className="px-2 py-1 bg-gray-500/20 text-gray-600 text-xs rounded-full">已拒单</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            
            {/* 分页 */}
            <div className="flex items-center justify-between mt-6">
              <div className="text-text-muted text-sm">
                显示 1-5 条，共 5 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  className="px-3 py-1 bg-white/20 border border-white/30 rounded-lg text-text-secondary text-sm hover:bg-white/30 transition-colors" 
                  disabled
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button className="px-3 py-1 bg-secondary text-white rounded-lg text-sm">1</button>
                <button 
                  className="px-3 py-1 bg-white/20 border border-white/30 rounded-lg text-text-secondary text-sm hover:bg-white/30 transition-colors" 
                  disabled
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* 拒单理由选择弹窗 */}
      {isRejectModalVisible && (
        <div 
          className={`${styles.modalOverlay} fixed inset-0 z-50 flex items-center justify-center p-4`}
          onClick={handleModalOverlayClick}
        >
          <div className={`${styles.modalContent} w-full max-w-md rounded-2xl p-6 shadow-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-accent">选择拒单理由</h3>
              <button 
                onClick={handleCancelReject}
                className="text-text-muted hover:text-accent transition-colors"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            
            <div className="space-y-3 mb-6">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="time-conflict" 
                  checked={selectedRejectReason === 'time-conflict'}
                  onChange={(e) => setSelectedRejectReason(e.target.value as RejectReason)}
                  className="text-secondary focus:ring-secondary"
                />
                <span className="text-text-primary">时间冲突</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="pet-type-not-allowed" 
                  checked={selectedRejectReason === 'pet-type-not-allowed'}
                  onChange={(e) => setSelectedRejectReason(e.target.value as RejectReason)}
                  className="text-secondary focus:ring-secondary"
                />
                <span className="text-text-primary">不提供该类型宠物托管</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="distance-too-far" 
                  checked={selectedRejectReason === 'distance-too-far'}
                  onChange={(e) => setSelectedRejectReason(e.target.value as RejectReason)}
                  className="text-secondary focus:ring-secondary"
                />
                <span className="text-text-primary">距离太远</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="special-requirements" 
                  checked={selectedRejectReason === 'special-requirements'}
                  onChange={(e) => setSelectedRejectReason(e.target.value as RejectReason)}
                  className="text-secondary focus:ring-secondary"
                />
                <span className="text-text-primary">无法满足特殊需求</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="radio" 
                  name="reject-reason" 
                  value="other" 
                  checked={selectedRejectReason === 'other'}
                  onChange={(e) => setSelectedRejectReason(e.target.value as RejectReason)}
                  className="text-secondary focus:ring-secondary"
                />
                <span className="text-text-primary">其他原因</span>
              </label>
            </div>
            
            <div className="flex space-x-3">
              <button 
                onClick={handleConfirmReject}
                className={`${styles.btnDanger} flex-1 py-2 rounded-lg font-medium`}
              >
                确认拒单
              </button>
              <button 
                onClick={handleCancelReject}
                className={`${styles.btnSecondary} flex-1 py-2 rounded-lg font-medium`}
              >
                取消
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI客服悬浮按钮 */}
      <button 
        onClick={handleAiCustomerService}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-secondary to-accent rounded-full shadow-lg flex items-center justify-center text-white hover:shadow-xl transition-all hover:scale-110 z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>
    </div>
  );
};

export default OrderHallPage;

